#create_clock -period 6.250 -name SYSCLK_P -waveform {0.000 3.125} [get_ports SYSCLK_P]
#create_clock -period 6.250 -name SYSCLK_P -waveform {0.000 3.125} [get_ports clk_i]




