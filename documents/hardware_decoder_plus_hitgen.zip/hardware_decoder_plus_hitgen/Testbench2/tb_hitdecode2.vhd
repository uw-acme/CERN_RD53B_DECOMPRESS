-------------------------------------------------------------------------------
-- Author      : Gjones
-------------------------------------------------------------------------------
-- Simple testbench for hitdecode2.sv
-------------------------------------------------------------------------------
library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     std.textio.all;

entity tb_hitdecode2 is
end tb_hitdecode2;

architecture struct of tb_hitdecode2 is

-- Clock freq expressed in MHz
constant CLK_FREQ_MHZ       : real      := 100.0;
-- Clock period
constant CLK_PER_MHZ        : time      := integer(1.0E+6/(CLK_FREQ_MHZ)) * 1 ps;

signal sim_done             : boolean   := false;
signal busy                 : std_logic := '0';

signal clk                  : std_logic := '0';             
signal reset                : std_logic := '1';           
signal err_decode           : std_logic := '0';

signal reg_en_encode        : std_logic := '1';


-- Raw hit data
signal din                  : std_logic_vector(15 downto 0);    -- Input data, 8x2 hitmap
signal din_reversed         : std_logic_vector(15 downto 0);    -- Input data, 8x2 hitmap
signal din_eos              : std_logic := '0';                 -- Input data end-of-stream. Used to flush hits
signal din_dv               : std_logic := '0';                 -- Input data valid

-- Encoded hit data 
signal hit_encode_dout      : std_logic_vector(29 downto 0);
signal hit_encode_chan      : std_logic_vector( 3 downto 0) := X"4";
signal hit_encode_dout_size      : std_logic_vector( 4 downto 0);
signal hit_encode_dout_dv   : std_logic;
signal hit_encode_dout_eos  : std_logic;
signal hit_encode_nchan     : std_logic_vector( 3 downto 0);  -- Channel number of input hitmap data

-- Decoded output hit data
signal hitmap_out           : std_logic_vector(15 downto 0);  -- Decoded hitmap
signal hitmap_length        : std_logic_vector( 4 downto 0);  -- Actual length of the compressed input hitmap (4 to 30)
signal hitmap_nbits         : std_logic_vector( 4 downto 0);  -- Number of bits set in the decoded hitmap. (1 to 16)
signal hitmap_out_chan      : std_logic_vector( 3 downto 0);  -- Channel number of output hitmap
signal hitmap_out_dv        : std_logic;                      -- Output data valid
                         
-- Checker 
signal checker_err_dv       : std_logic;           
signal checker_errs         : std_logic_vector( 7 downto 0)  ;           
signal checker_err_count    : std_logic_vector( 7 downto 0)  ;           

signal fail_msg0                : std_logic := '0';

---------------------------------------------------------------
-- Procedure : clk_delay
-------------------------------------------------------------
procedure clk_delay(
    constant nclks  : in  integer
) is
begin
    for I in 1 to nclks loop
        wait until clk'event and clk='0';
    end loop;
end;

----------------------------------------------------------------
-- Print a string with no time or instance path.
----------------------------------------------------------------
procedure cpu_print_msg(
    constant msg    : in    string
) is
variable line_out   : line;
begin
    write(line_out, msg);
    writeline(output, line_out);
end procedure cpu_print_msg;

-------------------------------------------------------------
-- Procedure to drive hitmap input data to encoder
-- Input value is an integer
-------------------------------------------------------------
procedure gen_din( 
    signal clk          : in  std_logic;
    constant data       : in  integer;
    constant eos        : in  std_logic;

    signal data_in      : out std_logic_vector(15 downto 0);
    signal data_eos     : out std_logic;
    signal data_in_dv   : out std_logic
) is
begin
    wait until clk'event and clk='0';
    data_in         <= std_logic_vector(to_unsigned(data, 16));   
    data_eos        <= eos;
    data_in_dv      <= '1';
    wait until clk'event and clk='0';
    data_in         <= (others=>'0');
    data_eos        <= '0';
    data_in_dv      <= '0';
end;


-------------------------------------------------------------
-- Procedure to drive decode_hitmap input data
-------------------------------------------------------------
procedure decode_din( 
    signal clk          : in  std_logic;
    constant data       : in  std_logic_vector(31 downto 0);
    constant data_chan  : in  std_logic_vector( 3 downto 0);

    signal data_in      : out std_logic_vector(29 downto 0);
    signal data_in_chan : out std_logic_vector( 3 downto 0);
    signal data_in_dv   : out std_logic
) is
begin
    wait until clk'event and clk='0';
    data_in         <= data(29 downto 0);   
    data_in_chan    <= data_chan( 3 downto 0);   
    data_in_dv      <= '1';
    wait until clk'event and clk='0';
    data_in         <= (others=>'0');
    data_in_chan    <= (others=>'0');
    data_in_dv      <= '0';
end;


begin
    
    reg_en_encode   <= '1';

    
    -------------------------------------------------------------
    -- We are processing a 2x8 region of pixels
    --
    -- Hit locations:
    --  |----|----|----|----|----|----|----|----|
    --  |  0 |  1 |  2 |  3 |  4 |  5 |  6 |  7 | Row 0 -> enc8_dout0
    --  |----|----|----|----|----|----|----|----|
    --  |  8 |  9 | 10 | 11 | 12 | 13 | 14 | 15 | Row 1 -> enc8_dout1
    --  |----|----|----|----|----|----|----|----|
    --
    --  Note : Bit 0 of the din input bus is the top-left pixel
    -------------------------------------------------------------
    u_hit_encode : entity work.hit_encode
    port map(
        clk                 => clk                  ,  -- input   logic           
        reset               => reset                ,  -- input   logic           
        en_encode           => reg_en_encode        ,  -- input   logic            // '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)

        din                 => din                  ,  -- input   logic   [15:0]   // Input data, 8x2 hitmap
        din_eos             => din_eos              ,  -- input   logic            // Input data end-of-stream. Used to flush hits
        din_dv              => din_dv               ,  -- input   logic            // Input data valid

        dout                => hit_encode_dout      ,  -- output  logic   [29:0]   // Output data. Encoded hitmap (in MSBs)
        dout_size           => hit_encode_dout_size ,  -- output  logic   [ 4:0]   // Number of bits in encoded hitmap
        dout_eos            => hit_encode_dout_eos  ,  -- output  logic            // Output data end-of-stream
        dout_dv             => hit_encode_dout_dv      -- output  logic            // Output data valid
    );

    ---------------------------------------------------------------------
    -- Decoder that takes 30-bit encoded hit field and converts to 16-bit
    -- un-encoded hitmap. Additional output is number of bits set in the 
    -- output hitmap and the size of the encoded hitmap within the 30-bit field.
    ---------------------------------------------------------------------
    u_hitdecode2 : entity work.hitdecode2
    port map(
        clk                 => clk                  , -- input   logic           
        reset               => reset                , -- input   logic           

        reg_en_encode       => reg_en_encode        , -- input   logic           

        data_in             => hit_encode_dout      , -- input   [29:0]     contains input hitmap in MSBs. Actual size is unknown. 5 bits min, 30 bits max
        data_in_chan        => hit_encode_nchan     , -- input   [ 3:0]     Channel number of input hitmap data
        data_in_dv          => hit_encode_dout_dv   , -- input              Input data valid

        hitmap_out          => hitmap_out           , -- output  reg [15:0] Decoded hitmap
        hitmap_length       => hitmap_length        , -- output  reg [ 4:0] Actual length of the compressed input hitmap (4 to 30)
        hitmap_nbits        => hitmap_nbits         , -- output  reg [ 4:0] Number of bits set in the decoded hitmap. (1 to 16)
        hitmap_out_chan     => hitmap_out_chan      , -- output  reg [ 3:0] Channel number of output hitmap
        hitmap_out_dv       => hitmap_out_dv          -- output  reg        Output data valid
    );


    -------------------------------------------------------------
    -- Generate logic clock
    -------------------------------------------------------------
    pr_clk : process
    begin
        clk  <= '0';
        wait for (CLK_PER_MHZ/2);
        clk  <= '1';
        wait for (CLK_PER_MHZ-CLK_PER_MHZ/2);
        if (sim_done=true) then
            wait;
        end if;
    end process;


    -------------------------------------------------------------
    -- Main stimulus 
    -------------------------------------------------------------
    pr_gen : process
    begin
        -- Reset
        reset           <= '1';
        din             <= (others=>'0');
        din_dv          <= '0';
        din_eos         <= '0';

        clk_delay(10);
        reset           <= '0';
        clk_delay(10);

        for I in 1 to (64*1024)-1 loop
            
            if (I < (64*1024)-1) then
                gen_din(clk, I , '0', din, din_eos, din_dv);
            else
                gen_din(clk, I , '1', din, din_eos, din_dv);
            end if;
            
        end loop;
        
        --decode_din     (clk,   X"00000000", x"1",    data_in, data_in_chan, data_in_dv);
        --clk_delay(2);
        --decode_din     (clk,   X"00000000", x"1",    data_in, data_in_chan, data_in_dv);
        --clk_delay(2);
        --decode_din     (clk,   X"3FFFFFFF", x"2",    data_in, data_in_chan, data_in_dv);
        --clk_delay(2);

        clk_delay(10);
        sim_done    <= true;
        wait;

    end process;

    din_reversed(0)     <= din(15);
    din_reversed(1)     <= din(14);
    din_reversed(2)     <= din(13);
    din_reversed(3)     <= din(12);
    din_reversed(4)     <= din(11);
    din_reversed(5)     <= din(10);
    din_reversed(6)     <= din(9);
    din_reversed(7)     <= din(8);
    din_reversed(8)     <= din(7);
    din_reversed(9)     <= din(6);
    din_reversed(10)    <= din(5);
    din_reversed(11)    <= din(4);
    din_reversed(12)    <= din(3);
    din_reversed(13)    <= din(2);
    din_reversed(14)    <= din(1);
    din_reversed(15)    <= din(0);

    -------------------------------------------------------
    -- Generate an incrementing channel number
    -------------------------------------------------------
    pr_nchan : process (reset, clk)
    begin

        if (reset = '1') then
            hit_encode_nchan    <= (others=>'0');

        elsif rising_edge(clk) then

            if (hit_encode_dout_dv = '1') then
                hit_encode_nchan    <= std_logic_vector(unsigned(hit_encode_nchan)+1);
            end if;

        end if;

    end process;


    -------------------------------------------------------------
    -- Main checker 
    -------------------------------------------------------------
    -- Stores generated hit data in a FIFO. Reads it out and 
    -- compares expected value agains actual decoded value.
    -- Also compares length of encoded hitmap and number of bits set.
    -------------------------------------------------------------
    -- checker_errs bits
    -------------------------------------------------------------
    -- Bit    Failure type
    --  0        hitmap
    --  1        nbits set
    --  2        enc_size
    -------------------------------------------------------------
    u_hitdecode2_checker : entity work.hitdecode2_checker
    port map (
        clk                     => clk                      ,  
        reset                   => reset                    ,  

        -- Generated data
        exp_hitmap              => din_reversed             , -- input   [15:0]   
        exp_hitmap_dv           => din_dv                   , -- input   expected data valid

        exp_enc_size            => hit_encode_dout_size     , -- input   [ 4:0]   
        exp_enc_size_dv         => hit_encode_dout_dv       , -- input   expected data valid

        -- Actual data from decoder 
        act_decode_hitmap       => hitmap_out               , -- input [15:0]
        act_decode_nbits        => hitmap_nbits             , -- input
        act_enc_size            => hitmap_length            , -- input 
        act_dv                  => hitmap_out_dv            , -- input data valid           

        dout_err_dv             => checker_err_dv           , -- output result valid
        dout_errs               => checker_errs             , -- output fail bus [7:0]
        dout_err_count          => checker_err_count          -- output result error count [7:0]
    );

    -- Assertion to print message and stop sim when a checker error occurs
    fail_msg0           <= '1' when (checker_errs /= X"00") and (checker_err_dv = '1') else '0';
    assert (fail_msg0 = '0') report "checker_errs" severity FAILURE;

end struct;

