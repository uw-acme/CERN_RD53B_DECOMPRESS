-------------------------------------------------------------------------------
-- Author      : Gjones
-------------------------------------------------------------------------------
-- Testbench for testing RD53B output Aurora bus decoding.
-- Uses hitmaker block to generate patterns and compressed data.
-- Contains a single decoder.
-- Testbench compares decoded data against original data.
-------------------------------------------------------------------------------
library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     std.textio.all;

entity  tb_decode_engine_2 is
end     tb_decode_engine_2;

architecture struct of tb_decode_engine_2 is

-- Clock freq expressed in MHz
constant CLK_FREQ_MHZ           : real      := 100.0;
-- Clock period
constant CLK_PER_MHZ            : time      := integer(1.0E+6/(CLK_FREQ_MHZ)) * 1 ps;

signal sim_done                 : boolean   := false;

signal clk                      : std_logic := '0';             
signal reset                    : std_logic := '1';           

signal hitmaker_enable          : std_logic ;                       -- Allow stream generation
signal hitmaker_start           : std_logic ;                       -- Begin stream generation
signal hitmaker_ready           : std_logic ;                       -- Normally high. Goes low when any internal FIFO is over-threshold
signal hitmaker_busy            : std_logic ;                       -- Set low when din_dv=1 then high after last dout of an event   

-- Control parameters
signal reg_mode_evgen           : std_logic_vector( 1 downto  0) ;  -- Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
signal reg_seed                 : std_logic_vector(31 downto  0) ;  -- Seed to initialize the pseudo-random number generator
signal reg_hits_per_stream      : std_logic_vector(15 downto  0) ;  -- 
signal reg_words_per_stream     : std_logic_vector(15 downto  0) ;  -- 
signal reg_lv_density           : std_logic_vector( 4 downto  0) ;  -- Parameter to set the probability of a vertical line of hits occurring. Can be zero
signal reg_lv_maxlen            : std_logic_vector( 4 downto  0) ;  -- Parameter to set the max length of a v-line of hits occurring
signal reg_cl_density           : std_logic_vector(11 downto  0) ;  -- Parameter to set the range of the increment in x,y from one cluster to the next.
signal reg_cl_max               : std_logic_vector(11 downto  0) ;  -- Parameter to set the max number of clusters+lines to generate.
signal reg_restart              : std_logic                      ;  -- 
signal reg_en_encode            : std_logic                      ;  -- '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
signal reg_en_tot               : std_logic                      ;  -- '1' = ToT enabled, '0'= No ToT data
signal reg_mode_tot             : std_logic                      ;  -- '0' = Constant (tot_value), '1' = Incrementing
signal reg_tot_value            : std_logic_vector( 3 downto  0) ;  -- ToT value for constant mode
signal reg_tag_init             : std_logic_vector( 7 downto  0) ;  -- Tag to start output stream. Subsequent tags (internal) will be 11-bit
signal reg_chip_id              : std_logic_vector( 1 downto  0) ;  --  
signal reg_en_chip_id           : std_logic                      ;  -- Enable chip ID[1:0]
signal reg_en_eos               : std_logic                      ;  -- Enable min 6 zeros output to mark end of stream

-- Hitmaker output of raw event generator data, for comparison with resulting data after encoding then decoding 
-- 'Expected' data
signal exp_hit_eos              : std_logic                      ;              
signal exp_hit_eoe              : std_logic                      ;             
signal exp_hit_qrow             : std_logic_vector( 7 downto  0) ;    
signal exp_hit_ccol             : std_logic_vector( 5 downto  0) ;    
signal exp_hit_hitmap           : std_logic_vector(15 downto  0) ;    
signal exp_hit_dv               : std_logic                      ;             
signal exp_hit_tot              : std_logic_vector(63 downto  0) ; -- hitmaker ToT data
signal exp_hit_tot_size         : std_logic_vector( 6 downto  0) ; -- hitmaker ToT data size
signal exp_hit_tot_eos          : std_logic                      ; -- ToT end-of-stream
signal exp_hit_tot_dv           : std_logic                      ; -- expected tot data valid
signal exp_hitmap_reversed      : std_logic_vector(15 downto 0);    -- Input data, 8x2 hitmap

-- Output of encoded data                  
signal hitmaker_ready_in        : std_logic;
signal hitmaker_dout            : std_logic_vector( 63 downto 0);   --  Stim data 
signal hitmaker_dout63          : std_logic_vector( 62 downto 0);   --  Stim data clipped to 63 bits
signal hitmaker_dout_eos        : std_logic;                        --  
signal hitmaker_dout_eoe        : std_logic;                        --  
signal hitmaker_dout_ns         : std_logic;                        --  
signal hitmaker_dout_dv         : std_logic;                        --  Output data valid
                         
-- Decoder output of decoded hit data fields
signal decoder_chip_id          : std_logic_vector( 1 downto  0) ;   
signal decoder_tag              : std_logic_vector( 7 downto  0) ;   
signal decoder_eos              : std_logic                      ;              
signal decoder_eoe              : std_logic                      ;         
signal decoder_qrow             : std_logic_vector( 7 downto  0) ;   
signal decoder_ccol             : std_logic_vector( 5 downto  0) ;   
signal decoder_hitmap           : std_logic_vector(15 downto  0) ;   
signal decoder_tot              : std_logic_vector(63 downto  0) ;  -- ToT data packed into MSBs of bus. Lower bits zero
signal decoder_dv               : std_logic                      ;       

signal decoder_busy             : std_logic;           
signal decoder_ready            : std_logic;           
signal decoder_errors           : std_logic_vector( 2 downto 0)  ;           

-- Checker 
signal checker_status           : std_logic_vector( 7 downto 0)  ;           
signal checker_err_dv           : std_logic;           
signal checker_ready_out        : std_logic;           
signal checker_errs             : std_logic_vector( 7 downto 0)  ;           
signal checker_err_count        : std_logic_vector( 7 downto 0)  ;

signal fail_msg                 : std_logic := '0';

---------------------------------------------------------------
-- Delay
-------------------------------------------------------------
procedure clk_delay(
    constant nclks  : in  integer
) is
begin
    for I in 1 to nclks loop
        wait until clk'event and clk='0';
    end loop;
end;

----------------------------------------------------------------
-- Print a string with no time or instance path.
----------------------------------------------------------------
procedure cpu_print_msg(
    constant msg    : in    string
) is
variable line_out   : line;
begin
    write(line_out, msg);
    writeline(output, line_out);
end procedure cpu_print_msg;


begin
    

    -------------------------------------------------------------
    -- Hit decoder to convert 64-bit 'Aurora-formatted' words 
    -- back into uncompressed, separate fields.
    -------------------------------------------------------------
    u_decode_engine_2 : entity work.decode_engine_2
    port map (
        clk                     => clk                      , -- 
        reset                   => reset                    , -- 

        busy                    => decoder_busy             , -- 
        ready                   => decoder_ready            , -- When the engine is ready to recieve raw stream data
        errors                  => decoder_errors           , -- 

        -- Control settings (may, or may not be implemented)
        reg_en_encode           => reg_en_encode            , -- input  '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
        reg_en_tot              => reg_en_tot               , -- input  '1' = ToT enabled, '0'= No ToT data
        reg_en_chip_id          => reg_en_chip_id           , -- input  Enable chip ID[1:0]
        reg_en_eos              => reg_en_eos               , -- input  Enable min 6 zeros output to mark end of stream

        din                     => hitmaker_dout63          , -- Raw data from the data stream
        din_ns                  => hitmaker_dout_ns         , -- Set on first word of a new stream
        din_chan                => "000"                    , -- Encoded data channel number (0-7)
        din_dv                  => hitmaker_dout_dv         , -- The stream data that is being advertised is valid

        -- Decoded hit data 
        dout_chip_id            => decoder_chip_id          , -- output current chip_id [1:0]            
        dout_tag                => decoder_tag              , -- output current tag     [7:0]  
        dout_eos                => decoder_eos              , -- output end-of-stream            
        dout_eoe                => decoder_eoe              , -- output end-of-event           
        dout_qrow               => decoder_qrow             , -- output qrow    [ 7:0]   
        dout_ccol               => decoder_ccol             , -- output ccol    [ 5:0]   
        dout_hitmap             => decoder_hitmap           , -- output hitmap  [15:0]   
        dout_tot                => decoder_tot              , -- output tot     [63:0] ToT data packed into MSBs of bus
        dout_dv                 => decoder_dv                 -- output data valid           
    );



    -------------------------------------------------------------
    -- Generate logic clock
    -------------------------------------------------------------
    pr_clk : process
    begin
        clk  <= '0';
        wait for (CLK_PER_MHZ/2);
        clk  <= '1';
        wait for (CLK_PER_MHZ-CLK_PER_MHZ/2);
        if (sim_done=true) then
            wait;
        end if;
    end process;


    -------------------------------------------------------------
    -- Main 
    -------------------------------------------------------------
    pr_gen : process
    variable v_hits_per_stream : integer := 16;
    begin
        -- Reset
        reset                   <= '1';
        hitmaker_enable         <= '0';
        hitmaker_start          <= '0';
        hitmaker_dout           <= (others=>'0');   -- Raw data from the data stream
        hitmaker_dout_ns        <= '0';             -- Set on first word of a new stream
        hitmaker_dout_dv        <= '0';             -- The stream data that is being advertised is valid

        -- Register setup
        reg_mode_evgen          <= "00"         ; -- [ 1:0]   Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
        reg_seed                <= X"FFFFFFFF"  ; -- [31:0]   Seed to initialize the pseudo-random number generator
        reg_hits_per_stream     <= X"0FFF"      ; -- [15:0]  
        reg_words_per_stream    <= X"0200"      ; -- [15:0]   32K bits, 64 bits/word = 512 = 0x200
        reg_lv_density          <= "00100"      ; -- [ 4:0]   Parameter to set the probability of a vertical line of hits occurring. Can be zero
        reg_lv_maxlen           <= "00100"      ; -- [ 4:0]   Parameter to set the max length of a v-line of hits occurring
        reg_cl_density          <= X"006"       ; -- [11:0]   Parameter to set the range of the increment in x,y from one cluster to the next.
        reg_cl_max              <= X"010"       ; -- [11:0]   Parameter to set the max number of clusters+lines to generate.
        reg_restart             <= '0'          ; --          
        reg_en_encode           <= '1'          ; --          '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
        reg_en_tot              <= '1'          ; --          '1' = ToT enabled, '0'= No ToT data
        reg_mode_tot            <= '0'          ; --          '0' = Constant (tot_value), '1' = Incrementing
        reg_tot_value           <= X"3"         ; -- [ 3:0]   ToT value for constant mode
        reg_tag_init            <= X"05"        ; -- [ 7:0]   Tag to start output stream. Subsequent tags (internal) will be 11-bit
        reg_chip_id             <= "01"         ; -- [ 1:0]    
        reg_en_chip_id          <= '1'          ; --          Enable chip ID[1:0]
        reg_en_eos              <= '1'          ; --          Enable min 6 zeros output to mark end of stream
        clk_delay(10);

        reset                   <= '0';
        clk_delay(10);

        --------------------------------------------------------------------
        -- Loop, driving a stream captured from logic analyzer.
        --------------------------------------------------------------------
        hitmaker_dout       <= X"20b5007fedfff666";
        hitmaker_dout_ns    <= '1';
        hitmaker_dout_dv    <= '1';
        clk_delay(1);

        hitmaker_dout       <= X"33333333333017ff"; 
        hitmaker_dout_ns    <= '0';
        clk_delay(1);

        hitmaker_dout       <= X"6fffb33333333333"; 
        clk_delay(1);
        hitmaker_dout       <= X"19980fbfffeccccc"; 
        clk_delay(1);
        hitmaker_dout       <= X"666666604fddfffd"; 
        clk_delay(1);
        hitmaker_dout       <= X"4cccccccccccdfb7"; 
        clk_delay(1);
        hitmaker_dout       <= X"7ffb333333333333"; 
        clk_delay(1);
        hitmaker_dout       <= X"019f7ffff6666666"; 
        clk_delay(1);
        hitmaker_dout       <= X"33333337ddfffd99"; 
        clk_delay(1);
        hitmaker_dout       <= X"4cccccccccc0fffa"; 
        clk_delay(1);
        hitmaker_dout       <= X"7fff666666666666"; 
        clk_delay(1);
        hitmaker_dout       <= X"337fd7fff6666666"; 
        clk_delay(1);
        hitmaker_dout       <= X"333333304bffbfff"; 
        clk_delay(1);
        hitmaker_dout       <= X"5999999999999998"; 
        clk_delay(1);
        hitmaker_dout       <= X"14f6fffecccccccc"; 
        clk_delay(1);
        hitmaker_dout       <= X"666660b7fcfffecc"; 
        clk_delay(1);
        hitmaker_dout       <= X"6666666666660c7f"; 
        clk_delay(1);
        hitmaker_dout       <= X"4fffeccccccccccc"; 
        clk_delay(1);
        hitmaker_dout       <= X"6660d7fefffecccc"; 
        clk_delay(1);
        hitmaker_dout       <= X"66666666666fbfff"; 
        clk_delay(1);
        hitmaker_dout       <= X"7d9999999999999b"; 
        clk_delay(1);
        hitmaker_dout       <= X"7fbfffeccccccccc"; 
        clk_delay(1);
        hitmaker_dout       <= X"666666ffbfffeccc"; 
        clk_delay(1);
        hitmaker_dout       <= X"6666666666670fff"; 
        clk_delay(1);
        hitmaker_dout       <= X"7ffffb3333333333"; 
        clk_delay(1);
        hitmaker_dout       <= X"19999d7009b33300"; 
        clk_delay(1);

        hitmaker_dout_dv    <= '0';
        hitmaker_dout       <= (others=>'0');   -- Raw data from the data stream
        clk_delay(100);
        wait;

        sim_done    <= true;    -- Set sim_done to stop clock generation and bring simulation to a halt
        wait;

    end process;

    hitmaker_dout63 <= hitmaker_dout(62 downto 0);

end struct;

