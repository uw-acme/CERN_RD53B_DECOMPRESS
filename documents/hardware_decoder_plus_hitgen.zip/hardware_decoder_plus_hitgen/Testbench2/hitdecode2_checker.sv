//----------------------------------------------------------------------------
// hitdecode2_checker. 
//
// Stores generated hitmap data in a FIFO. Reads it out and 
// compares expected value agains actual decoded value.
//----------------------------------------------------------------------------
`timescale 1ns / 1ps

module hitdecode2_checker
(
    input   logic           clk                 ,  
    input   logic           reset               ,  

    // Expected data from hitmaker
    input   logic   [15:0]  exp_hitmap          , 
    input   logic           exp_hitmap_dv       ,  // Expected data valid

    input   logic   [ 4:0]  exp_enc_size        ,  // Number of bits in encoded hitmap
    input   logic           exp_enc_size_dv     ,  // 

    // Data from decoder 
    input   logic   [15:0]  act_decode_hitmap   ,   // Hitmap
    input   logic   [ 4:0]  act_decode_nbits    ,   // Number of bits set in decoded hitmap
    input   logic   [ 4:0]  act_enc_size        ,   // Calculated size of encoded data
    input   logic           act_dv              ,   // Data valid           

    // Error reporting interface
    output  logic           dout_err_dv         ,   // result valid
    output  logic   [ 7:0]  dout_errs           ,   // error bus [7:0]
    output  logic   [ 7:0]  dout_err_count          // result error count [7:0]
);

    //-----------------------------------------------------------
    // Declarations
    //-----------------------------------------------------------

    // Expected data FIFO I/O signals
    logic   [15:0]  fexp_hmap_din, fexp_hmap_dout;      
    logic   [ 9:0]  fexp_hmap_level;
    logic           fexp_hmap_wr,  fexp_hmap_rd;
    logic           fexp_hmap_full, fexp_hmap_empty, fexp_hmap_overflow,  fexp_hmap_underflow;

    // Data FIFO I/O signals
    logic   [15:0]  fexp_enc_size_din, fexp_enc_size_dout;      
    logic   [ 9:0]  fexp_enc_size_level;
    logic           fexp_enc_size_wr,  fexp_enc_size_rd;
    logic           fexp_enc_size_full, fexp_enc_size_empty, fexp_enc_size_overflow,  fexp_enc_size_underflow;


    // Pipeline registers for actual data
    logic   [15:0]  act_decode_hitmap_d1     ;  // 
    logic   [ 4:0]  act_decode_nbits_d1      ;  // 
    logic   [ 4:0]  act_enc_size_d1;        // 
    logic           act_dv_d1;         // Data valid           

    logic   [ 4:0]  calc_nbits;  // 
    logic   [ 4:0]  calc_nbits_d1      ;  // 
    logic   [ 7:0]  status      ;  // 

    //-----------------------------------------------------------
    // Bit in err bus
    //-----------------------------------------------------------
    //              Failure type       Bit   
    //-----------------------------------------------------------
    logic           err_hitmap;    //  0   
    logic           err_nbits;     //  1   
    logic           err_enc_size;  //  2   


    assign  dout_errs   = {5'b0, err_enc_size, err_nbits, err_hitmap};


    //----------------------------------------------------------------------------
    // Write original, unencoded hitmap data into FIFO. 16 bits
    //----------------------------------------------------------------------------
    always_ff @(posedge clk) 
    begin: pr_fifo_hmap_wr
        
        if (reset) begin

            fexp_hmap_din    <= 0;
            fexp_hmap_wr     <= 1'b0;
            
        end else begin

            fexp_hmap_din    <= exp_hitmap;
            fexp_hmap_wr     <= exp_hitmap_dv;

        end

    end


    //----------------------------------------------------------------------------
    // Write original, encoded hitmap size into FIFO. i5 bits in LSB of 16 bits
    //----------------------------------------------------------------------------
    always_ff @(posedge clk) 
    begin: pr_fifo_enc_size_wr
        
        if (reset) begin

            fexp_enc_size_din    <= 0;
            fexp_enc_size_wr     <= 1'b0;
            
        end else begin

            fexp_enc_size_din    <= {11'b00000000000, exp_enc_size};
            fexp_enc_size_wr     <= exp_enc_size_dv;

        end

    end


    logic [4:0] ones_set;
    integer i;

    //----------------------------------------------------------------------------
    // Pipeline registers for decoded data fields
    // Also count number of bits set in decoded hitmap
    //----------------------------------------------------------------------------
    always_ff @(posedge clk or reset) 
    begin: pr_pipe_exp

        if (reset) begin

            act_decode_hitmap_d1    <= 0;
            act_decode_nbits_d1     <= 0;
            act_enc_size_d1         <= 0;
            calc_nbits_d1           <= 0;
            act_dv_d1               <= 1'b0;

        end else begin

            calc_nbits_d1           <= calc_nbits;
            act_decode_hitmap_d1    <= act_decode_hitmap;


            act_decode_nbits_d1     <= act_decode_nbits;
            act_enc_size_d1         <= act_enc_size;
            act_dv_d1               <= act_dv;

            ones_set = 0;

            // Count number of bits in decoded hitmap
            for (i=0 ; i < 16 ; i=i+1) begin
                if (act_decode_hitmap[i] == 1'b1)
                    ones_set = ones_set + 1;
              
            end
            calc_nbits <= ones_set;
        end

    end


    //----------------------------------------------------------------------------
    // FIFOs to store expected data until it is needed for comparison with actual
    // decoded data. 
    // FIFO depth must be greater than total encode-decode pipeline delay.
    // Both FIFOs are read at the same time.
    //----------------------------------------------------------------------------
    fifo_16x16b    u_fifo_exp_hmap         // RAM 16x16bit 
    (
        .clk        ( clk                       ),  // input  wire 
        .srst       ( reset                     ),  // input  wire 
        .din        ( fexp_hmap_din             ),  // input  wire [15:0] 
        .wr_en      ( fexp_hmap_wr              ),  // input  wire 
        .rd_en      ( fexp_hmap_rd              ),  // input  wire
        .dout       ( fexp_hmap_dout            ),  // output wire [15:0]
        .full       ( fexp_hmap_full            ),  // output wire
        .empty      ( fexp_hmap_empty           ),  // output wire
        .overflow   ( fexp_hmap_overflow        ),  // output wire
        .underflow  ( fexp_hmap_underflow       ),  // output wire
        .data_count ( fexp_hmap_level           )   // output wire [9:0]
    );

    fifo_16x16b   u_fifo_exp_enc_size    // RAM 16x16bit
    (
        .clk        ( clk                       ),  // input  wire 
        .srst       ( reset                     ),  // input  wire 
        .din        ( fexp_enc_size_din         ),  // input  wire [15:0] 
        .wr_en      ( fexp_enc_size_wr          ),  // input  wire 
        .rd_en      ( fexp_enc_size_rd          ),  // input  wire
        .dout       ( fexp_enc_size_dout        ),  // output wire [15:0]
        .full       ( fexp_enc_size_full        ),  // output wire
        .empty      ( fexp_enc_size_empty       ),  // output wire
        .overflow   ( fexp_enc_size_overflow    ),  // output wire
        .underflow  ( fexp_enc_size_underflow   ),  // output wire
        .data_count ( fexp_enc_size_level       )   // output wire [9:0]
    );

    assign  status  = {fexp_hmap_full,     fexp_hmap_empty,     fexp_hmap_overflow,     fexp_hmap_underflow, 
                       fexp_enc_size_full, fexp_enc_size_empty, fexp_enc_size_overflow, fexp_enc_size_underflow};

    // Read all FIFOs
    assign  fexp_hmap_rd        = act_dv_d1;
    assign  fexp_enc_size_rd    = act_dv_d1;

    assign  dout_err_dv         = 1'b0;
    assign  dout_err_count      = 8'b0;


    //----------------------------------------------------------------------------
    // Check actual hitmap against expected
    //----------------------------------------------------------------------------
    always_ff @(posedge clk) 
    begin : pr_err_hitmap

        if (reset == 1'b1) begin
            err_hitmap  <= 1'b0;

        end else begin

            if ((act_dv_d1 == 1'b1) && (act_decode_hitmap_d1 != fexp_hmap_dout)) begin
                err_hitmap  <= 1'b1;
            end else begin
                err_hitmap  <= 1'b0;
            end

        end

    end


    //----------------------------------------------------------------------------
    // Check decoder-calculated encoded hitmap size against encoder hitmap size
    //----------------------------------------------------------------------------
    always_ff @(posedge clk) 
    begin : pr_err_enc_size

        if (reset == 1'b1) begin
            err_enc_size    <= 1'b0;

        end else begin

            if ((act_dv_d1 == 1'b1) && (act_enc_size_d1 != fexp_enc_size_dout[4:0])) begin
                err_enc_size    <= 1'b1;
            end else begin
                err_enc_size    <= 1'b0;
            end

        end

    end


    //----------------------------------------------------------------------------
    // Check decoder-calculated nbits against decoded hitmap bit pattern
    //----------------------------------------------------------------------------
    always_ff @(posedge clk) 
    begin : pr_err_nbits

        if (reset == 1'b1) begin
            err_nbits   <= 1'b0;

        end else begin

            if ((act_dv_d1 == 1'b1) && (act_decode_nbits_d1 != calc_nbits)) begin
                err_nbits       <= 1'b1;
            end else begin
                err_nbits       <= 1'b0;
            end

        end

    end


endmodule

