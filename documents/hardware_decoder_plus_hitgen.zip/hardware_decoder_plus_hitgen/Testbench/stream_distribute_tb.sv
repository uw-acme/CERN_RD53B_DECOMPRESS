module stream_distribute_tb();

parameter ENGINE_NUM = 8;
parameter CLEAR_COUNT = 50;

logic                   clk_i;
logic                   rst_i;
logic  [ENGINE_NUM-1:0] ready_engine_i;
logic                   valid_raw_i;
logic  [63:0]           data_raw_i;
logic  [ENGINE_NUM-1:0] valid_stream_o;
logic  [63:0]           data_stream_o;
logic                   ready_raw_o;
logic  [ENGINE_NUM-1:0] end_of_stream_o;
logic                   reset_engine_ready;
 
stream_distribute #(ENGINE_NUM) dut
(
    .clk_i,
    .rst_i,
    .ready_engine_i,
    .valid_raw_i,
    .data_raw_i,
    .valid_stream_o,
    .data_stream_o,
    .ready_raw_o,
    .end_of_stream_o
);

    parameter ClockDelay = 1000;

    task clear_time();
        valid_raw_i <= 0;
        for(int j = 0; j < CLEAR_COUNT; j++) begin
            @(posedge clk_i);
        end
    endtask

    task reset_engines();
        reset_engine_ready <= 1'b1;
        @(posedge clk_i);
        reset_engine_ready <= 1'b0;
        @(posedge clk_i);
    endtask

    initial begin // Set up the clock
        clk_i <= 0;
        forever #(ClockDelay/2) clk_i <= ~clk_i;
    end

    initial begin
        forever begin
            if(dut.rd_raw_data_fifo_reg) begin
               $display("active engine is: %b", dut.active_engine_reg);
               $display("data is: %d", data_stream_o);
            end
            @(posedge clk_i);
        end
    end

    initial begin
        ready_engine_i <= {(ENGINE_NUM){1'b1}};
        @(posedge clk_i);
        forever begin
            for(int i = 0; i < ENGINE_NUM; i++) begin
                if (end_of_stream_o[i] == 1) begin
                    ready_engine_i[i] <= 1'b0;
                end else if (reset_engine_ready) begin
                    ready_engine_i[i] <= 1'b1;
                end
            end
            @(posedge clk_i);
        end
    end

    initial begin
        rst_i <= 1; valid_raw_i <= 0; data_raw_i <= 0; @(posedge clk_i);
        rst_i <= 0; @(posedge clk_i);
        for(int i = 0; i < ENGINE_NUM - 4; i++) begin
            valid_raw_i <= 1; data_raw_i <= 64'b1; @(posedge clk_i);
            data_raw_i <= 64'b10; @(posedge clk_i);
            data_raw_i <= 64'b110;  @(posedge clk_i);
        end

        clear_time();

        for(int k = (ENGINE_NUM - 4); k < ENGINE_NUM; k++) begin
            valid_raw_i <= 1; data_raw_i <= 64'b1; @(posedge clk_i);
        end

        clear_time();
        
        reset_engines();

        for(int l = 0; l < ENGINE_NUM; l++) begin
            valid_raw_i <= 1; data_raw_i <= 64'b1; @(posedge clk_i);
            data_raw_i <= 64'b10; @(posedge clk_i);
            data_raw_i <= 64'b110;  @(posedge clk_i);
        end

        clear_time();
        $stop;
    end

endmodule;