`timescale 1ps / 1ps
module tb_encode_decode_top();
    logic           SYSCLK_P        ; 
	logic           SYSCLK_N        ;

	logic           CPU_RESET       ; // reset
	logic           GPIO_SW_S       ; // start
	logic           GPIO_SW_N       ; // stop
	
	logic           GPIO_DIP_SW0    ; // for reg_hits_per_stream
    logic           GPIO_DIP_SW1    ;
    logic           GPIO_DIP_SW2    ;
    logic           GPIO_DIP_SW3    ;

	logic           GPIO_LED_0_LS   ;
	logic           GPIO_LED_1_LS   ;
	logic           GPIO_LED_2_LS   ;
	logic           GPIO_LED_3_LS   ;
	logic           GPIO_LED_4_LS   ;
	logic           GPIO_LED_5_LS   ;
	logic           GPIO_LED_6_LS   ;
	logic           GPIO_LED_7_LS   ;

	logic [ 6:0]	DEBUG_OUT		;
	logic [ 4:0] 	dip_sw			;
	assign {GPIO_DIP_SW3, GPIO_DIP_SW2, GPIO_DIP_SW1, GPIO_DIP_SW0} = dip_sw;
	
	encode_decode_top dut(
		.SYSCLK_P        , 
		.SYSCLK_N        ,
    
		.CPU_RESET       , // reset
		.GPIO_SW_S       , // start
		.GPIO_SW_N       , // stop
		
		.GPIO_DIP_SW0    , // for reg_hits_per_stream
		.GPIO_DIP_SW1    ,
		.GPIO_DIP_SW2    ,
		.GPIO_DIP_SW3    ,
    
		.GPIO_LED_0_LS   ,
		.GPIO_LED_1_LS   ,
		.GPIO_LED_2_LS   ,
		.GPIO_LED_3_LS   ,
		.GPIO_LED_4_LS   ,
		.GPIO_LED_5_LS   ,
		.GPIO_LED_6_LS   ,
		.GPIO_LED_7_LS   ,
    
		.DEBUG_OUT
	);
    
    parameter CLOCK_PERIOD=5000;
    initial begin
        SYSCLK_N<=0; 
		SYSCLK_P<=1;
        forever #(CLOCK_PERIOD/2) begin
            SYSCLK_N <= ~SYSCLK_N;
            SYSCLK_P <= ~SYSCLK_P;
        end
    end
    
	integer i;
    initial begin
        CPU_RESET <= 1;  
		GPIO_SW_S <= 0; 
		GPIO_SW_N <= 0;
		dip_sw <= 4'hF; 
		repeat(5) @(posedge SYSCLK_N);
		
		// test debouncing
//        CPU_RESET <= 0;  @(posedge SYSCLK_N);
//		@(posedge GPIO_LED_0_LS);
//		GPIO_SW_S <= 1;     repeat(50) @(posedge dut.clk);
//		GPIO_SW_S <= 0;		@(posedge dut.clk);
//		GPIO_SW_S <= 1; 	repeat(66000) @(posedge dut.clk);
//		GPIO_SW_S <= 0; 	repeat (300) @(posedge dut.clk);
//		GPIO_SW_N <= 1;     repeat(66000) @(posedge dut.clk);
//		GPIO_SW_N <= 0;     repeat (5) @(posedge dut.clk);
//		GPIO_SW_S <= 1; 	repeat(1000) @(posedge dut.clk);
//		for (int i = 0; i < 66000; i++) begin
//			GPIO_SW_S <= 0; 	@(posedge SYSCLK_N);
//			GPIO_SW_S <= 1; 	@(posedge SYSCLK_N);			
//		end
//		GPIO_SW_S <= 0; 	repeat (100) @(posedge dut.clk);
//		GPIO_SW_S <= 1; 	repeat(32000) @(posedge dut.clk);
//		GPIO_SW_S <= 0; 	repeat (100) @(posedge dut.clk);
//		GPIO_SW_S <= 1; 	repeat(11000) @(posedge dut.clk);
		// start
		//CPU_RESET		<= 1; 		repeat(5)@(posedge SYSCLK_N);
		CPU_RESET		<= 0; 		@(posedge SYSCLK_N);
		//@(posedge GPIO_LED_0_LS);
		dip_sw			<= 4'hF;	//repeat(25e4) 	@(posedge dut.clk);
		GPIO_SW_S	 	<= 1; 		repeat(100) 	@(posedge dut.clk);
		GPIO_SW_S 		<= 0; 		repeat(100) 	@(posedge dut.clk);
		
		// test switches change only in idle
		//dip_sw			<= 4'h1;	repeat(10)  	@(posedge dut.clk); 
		//GPIO_SW_S	 	<= 1; 		repeat(100) 	@(posedge dut.clk);
		//GPIO_SW_S 		<= 0; 		repeat(100) 	@(posedge dut.clk);
		
		// test switches change only in end_of_stream
		//dip_sw			<= 4'h2;	repeat(100)     @(posedge dut.clk);	
		//GPIO_SW_S	 	<= 1; 		repeat(100)  	@(posedge dut.clk);
		//GPIO_SW_S 		<= 0; 		repeat(100) 	@(posedge dut.clk);
		
        @(posedge DEBUG_OUT[6]);
        @(negedge DEBUG_OUT[6]);
		$stop;
    end
endmodule