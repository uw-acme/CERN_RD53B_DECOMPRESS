// Inputs control parameters to test_encode_decode to test RD53B data encoding and decoding

`timescale 1ps / 1ps
module tb_test_encode_decode();
    logic           clk                 ;    //             
    logic           reset               ;    //             

    logic           start               ;    //             Begin stream generation
    logic           ready               ;    //             Normally high. Goes low when any internal FIFO is over-threshold
    logic           busy                ;    //             Set low when din_dv=1 then high after last dout of an event   

    // Control parameters
    logic   [ 1:0]  reg_mode_evgen      ;    //     [ 1:0]   Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
    logic   [31:0]  reg_seed            ;    //     [31:0]   Seed to initialize the pseudo-random number generator
    logic   [15:0]  reg_hits_per_stream ;    //     [15:0]  
    logic   [ 4:0]  reg_lv_density      ;    //     [ 4:0]   Parameter to set the probability of a vertical line of hits occurring. Can be zero
    logic   [ 4:0]  reg_lv_maxlen       ;    //     [ 4:0]   Parameter to set the max length of a v-line of hits occurring
    logic   [11:0]  reg_cl_density      ;    //     [11:0]   Parameter to set the range of the increment in x,y from one cluster to the next.
    logic   [11:0]  reg_cl_max          ;    //     [11:0]   Parameter to set the max number of clusters+lines to generate.
    logic           reg_restart         ;    //              

    logic           reg_en_encode       ;    //              '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
    logic           reg_en_tot          ;    //              '1' = ToT enabled, '0'= No ToT data
    logic           reg_mode_tot        ;    //              '0' = Constant (tot_value), '1' = Incrementing
    logic   [ 3:0]  reg_tot_value       ;    //     [ 3:0]   ToT value for constant mode
    logic   [ 7:0]  reg_tag_init        ;    //     [ 7:0]   Tag to start  stream. Subsequent tags (internal) will be 11-bit
    logic   [ 1:0]  reg_chip_id         ;    //     [ 1:0]    
    logic           reg_en_chip_id      ;    //              Enable chip ID[1:0]
    logic           reg_en_eos          ;    //              Enable min 6 zeros  to mark end of stream

    //  from decoder 
    logic   [ 1:0]  decoder_chip_id     ;    //  current chip_id [ 1:0]           
    logic   [ 7:0]  decoder_tag         ;    //  current tag     [ 7:0]      
    logic           decoder_eos         ;    //  end-of-stream            
    logic           decoder_eoe         ;    //  end-of-event    Used to check incrementing tag
    logic   [ 7:0]  decoder_qrow        ;    //  qrow    [ 7:0]   
    logic   [ 5:0]  decoder_ccol        ;    //  ccol    [ 5:0]   
    logic   [15:0]  decoder_hitmap      ;    //  hitmap  [15:0]   
    logic   [63:0]  decoder_tot         ;    //  tot     [63:0] ToT data packed into MSBs of bus
    logic           decoder_dv          ;    //  data valid           
    
    //  from checker
    logic           dout_err_dv         ;    //  result valid
    logic   [ 7:0]  dout_errs           ;    //  fail bus [7:0]
    logic   [ 7:0]  dout_err_count      ;
    
    test_encode_decode dut
        (
        .clk                 ,    //             
        .reset               ,    //             

        .start               ,    //             Begin stream generation
        .ready               ,    //             Normally high. Goes low when any internal FIFO is over-threshold
        .busy                ,    //             Set low when din_dv=1 then high after last dout of an event   

        // Control parameters
        .reg_mode_evgen      ,    //     [ 1:0]   Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
        .reg_seed            ,    //     [31:0]   Seed to initialize the pseudo-random number generator
        .reg_hits_per_stream ,    //     [15:0]  
        .reg_lv_density      ,    //     [ 4:0]   Parameter to set the probability of a vertical line of hits occurring. Can be zero
        .reg_lv_maxlen       ,    //     [ 4:0]   Parameter to set the max length of a v-line of hits occurring
        .reg_cl_density      ,    //     [11:0]   Parameter to set the range of the increment in x,y from one cluster to the next.
        .reg_cl_max          ,    //     [11:0]   Parameter to set the max number of clusters+lines to generate.
        .reg_restart         ,    //              

        .reg_en_encode       ,    //              '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
        .reg_en_tot          ,    //              '1' = ToT enabled, '0'= No ToT data
        .reg_mode_tot        ,    //              '0' = Constant (tot_value), '1' = Incrementing
        .reg_tot_value       ,    //     [ 3:0]   ToT value for constant mode
        .reg_tag_init        ,    //     [ 7:0]   Tag to start  stream. Subsequent tags (internal) will be 11-bit
        .reg_chip_id         ,    //     [ 1:0]    
        .reg_en_chip_id      ,    //              Enable chip ID[1:0]
        .reg_en_eos          ,    //              Enable min 6 zeros  to mark end of stream

        // Output from decoder 
        .decoder_chip_id     ,    //  current chip_id [ 1:0]           
        .decoder_tag         ,    //  current tag     [ 7:0]      
        .decoder_eos         ,    //  end-of-stream            
        .decoder_eoe         ,    //  end-of-event    Used to check incrementing tag
        .decoder_qrow        ,    //  qrow    [ 7:0]   
        .decoder_ccol        ,    //  ccol    [ 5:0]   
        .decoder_hitmap      ,    //  hitmap  [15:0]   
        .decoder_tot         ,    //  tot     [63:0] ToT data packed into MSBs of bus
        .decoder_dv          ,    //  data valid           
        
        // Output from checker
        .dout_err_dv         ,    //  result valid
        .dout_errs           ,    //  fail bus [7:0]
        .dout_err_count           //  result error count [7:0]
        );
        
    // Simulated clock
    parameter CLOCK_PERIOD = 10000;
    initial begin 
        clk <= 0;
        forever #(CLOCK_PERIOD/2) clk <= ~clk;
    end
    
    initial begin
    
        // Reset
        reset                   <=1;    
        start                   <=0;    @(posedge clk);

        // Register setup
        reg_mode_evgen          <= 2'b00         ; // [ 1:0]   Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
        reg_seed                <= 32'hFFFFFFFF  ; // [31:0]   Seed to initialize the pseudo-random number generator
        reg_hits_per_stream     <= 16'hFFFF      ; // [15:0]  
        reg_lv_density          <= 5'b00100      ; // [ 4:0]   Parameter to set the probability of a vertical line of hits occurring. Can be zero
        reg_lv_maxlen           <= 5'b00100      ; // [ 4:0]   Parameter to set the max length of a v-line of hits occurring
        reg_cl_density          <= 12'h006       ; // [11:0]   Parameter to set the range of the increment in x,y from one cluster to the next.
        reg_cl_max              <= 12'h010       ; // [11:0]   Parameter to set the max number of clusters+lines to generate.
        reg_restart             <= 1'b0          ; //          
        reg_en_encode           <= 1'b1          ; //          '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
        reg_en_tot              <= 1'b1          ; //          '1' = ToT enabled, '0'= No ToT data
        reg_mode_tot            <= 1'b0          ; //          '0' = Constant (tot_value), '1' = Incrementing
        reg_tot_value           <= 4'h3          ; // [ 3:0]   ToT value for constant mode
        reg_tag_init            <= 8'h05         ; // [ 7:0]   Tag to start output stream. Subsequent tags (internal) will be 11-bit
        reg_chip_id             <= 2'b00         ; // [ 1:0]    
        reg_en_chip_id          <= 1'b0          ; //          Enable chip ID[1:0]
        reg_en_eos              <= 1'b1          ; //          Enable min 6 zeros output to mark end of stream
        @(posedge clk);

        reset                   <=0;
        repeat(25) @(posedge clk);

        // Set 'start' high to begin hit generation
        start                   <=1;    @(posedge clk);
        start                   <=0;    repeat(5) @(posedge clk);

        for (int i = 0; i < 2; i++) begin
            start <= 0; repeat(100) @(posedge clk);
            @(negedge busy);
            repeat(2000000) @(posedge clk);
            start <= 1; repeat (5) @(posedge clk);
        end



        $stop;
        
    end
endmodule 