`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/19/2020 07:07:39 PM
// Design Name: 
// Module Name: decode_engine_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

/* 
Current issues:
- The stream expects only a new stream bit on the first frame of an event
 I realized too late that each frame has a new stream bit so we will need to do 
 something about that in the future.

*/


/* Has been tested:
1. Single frame of data being passed through
2. Multi frame data passing through of first row hit data
3. Empty frames

Needs to be tested:
1. Second row hit data
2. Large amount of frames in single event
3. Starting and stopping the frames during single event


*/

module decode_engine_tb();
    logic         clk_i;
    logic         rst_i;
    logic         valid_stream_i;
    logic  [63:0] data_stream_i;
    logic         end_trans_i;
    logic         ready_stream_o;
    logic [127:0] decoded_data_o;
    logic         valid_decode_data_o;
    logic         ready_decode_data_i;
    
    decode_engine dut (
    .clk_i,
    .rst_i,
    .valid_stream_i,
    .data_stream_i,
    .end_trans_i,
    .ready_decode_data_i,
    .ready_stream_o,
    .decoded_data_o,
    .valid_decode_data_o
    );
    
    parameter ClockDelay = 1000;
    
    task newDataStream(input [63:0] data);
        valid_stream_i <= 1;
        data_stream_i <= data;
        @(posedge clk_i);
        valid_stream_i <= 0;
        @(posedge clk_i);
    endtask

    logic [9:0] data_frame_counter;
    task displayData();
        forever begin
            @(posedge clk_i);
            if (dut.decoded_data_ready == 1) begin
                data_frame_counter <= data_frame_counter + 1;
                $display("\n data frame %d", data_frame_counter);
                $display("tag value : %B", dut.tag_reg);
                $display("ccol value: %B", dut.ccol_reg);
                $display("qrow value: %B", dut.qrow_reg);
                $display("hitmap dec: %B", dut.decoded_hitmap);
                $display("tot value : %B", dut.tot_reg);
            end
        end
    endtask
    
    initial begin // Set up the clock
        clk_i <= 0;
        forever #(ClockDelay/2) clk_i <= ~clk_i;
    end

    initial begin
        data_frame_counter <= 0;
        displayData();
    end
    
    
    initial begin
        rst_i <= 1; end_trans_i <= 0; data_stream_i <= 0; valid_stream_i <= 0; ready_decode_data_i <= 1; @(posedge clk_i);
        @(posedge clk_i);
        rst_i <= 0; @(posedge clk_i);
        //@(posedge clk_i);
        // Empty stream check
        
        //TODO: Deal with empty frames
        newDataStream(63'b000000000000000000000000000000000000000000000000000000010111111);
        end_trans_i <= 1;
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        @(posedge ready_stream_o);
        // Two frames of data
        newDataStream(63'b000010000010001111101000011100101010101000011110100000111111111);
        newDataStream(63'b000000000000000000000000000000000000000000000000000000000000000);
        valid_stream_i <= 0;
        end_trans_i <= 1;
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        @(posedge ready_stream_o);
        newDataStream(63'b111000011111010000111001100100001010111000011110100000111111111);
        newDataStream(63'b000000000000000000000000000000000000000000000000000100100001010);
        valid_stream_i <= 0;
        end_trans_i <= 1;
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        @(posedge ready_stream_o);
        newDataStream(63'b100011111010000111001100101010101010111000011110100000111111110);
        newDataStream(63'b000000000000000000000000000000000000000000000000001001000000001);
        valid_stream_i <= 0;
        end_trans_i <= 1;
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        for(int i = 0; i < 64; i++) begin
            @(posedge clk_i);
        end
    
        $stop;
    end
    
endmodule
