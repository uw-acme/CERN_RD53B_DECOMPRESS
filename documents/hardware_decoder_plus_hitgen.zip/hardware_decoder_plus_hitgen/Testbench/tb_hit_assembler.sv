`timescale 1ns/1ps

module tb_hit_assembler();
    logic         clk, reset, restart;

    logic [7:0]   tag_init;
    logic [1:0]   chip_id;
    logic         en_chip_id;
    logic         en_eos;
    
    logic [109:0] din;
    logic [6:0]   din_size;
    logic         din_eos;
    logic         din_eoe;
    logic         din_dv;
    logic         ready_out;

    logic         ready_in;
    logic [63:0]  dout;
    logic         dout_eos;
    logic         dout_eoe;
    logic         dout_dv;

    integer       watchdog_timeout;
    logic         sim_done;
    
    hit_assembler dut
        (
         .clk, .reset, .restart,
         .tag_init, .chip_id, .en_chip_id, .en_eos,

         .din, .din_size, .din_eos, .din_eoe, .din_dv, .ready_out,
         .ready_in, .dout, .dout_eos, .dout_eoe, .dout_dv
         );

    parameter CLOCK_MHZ = 100;

    /* Generates clock. */
    initial begin
        sim_done = 0;
        clk <= 0;

        while (~sim_done) #(500/CLOCK_MHZ) clk <= ~clk;
    end

    /* Generates reset. */
    initial begin
        reset <= 1;
        repeat (10) @(posedge clk);
        reset <= 0;
    end

    /* Tracks data that has been provided to the hit assembler but has
       not yet been assembled and output by the hit assembler. */
    logic   accumulator[$]; // data that hasn't made it into a block yet
    logic   [63:0] expected_blocks[$]; // including new stream bit
    logic   expecting_new_stream;
    logic   [7:0] expected_tag;
    integer output_blocks_expected; // cumulative
    integer output_blocks_consumed;
    
    task provide_din (input logic data[], logic eos, logic eoe);
        // Need to unpack tag to add it to unpacked array.
        logic internal_tag[10:0];
        
        // Add data to queue for output consumer.
        accumulator = {accumulator, data};

        if (eoe) begin
            expected_tag = expected_tag + 1;
        end
        
        // If this is the end of an event but not also the end of a stream, also add the tag for the next event.
        if (eoe && ~eos) begin
            {>>{internal_tag}} = {3'b111, expected_tag};
            accumulator = {accumulator, internal_tag};
        end

        if (eos) begin
            // Make sure block has at least 6 zeros.
            accumulator = {accumulator, 0, 0, 0, 0, 0, 0};
        end

        // Dump the accumulator into expected blocks if we can
        while (accumulator.size() >= 63 || (accumulator.size() > 0 && eos)) begin
            // If this is eos and we're outputting a short block, need to fill up
            // accumulator with zeros so it packs properly when we dump it into
            // expected blocks.
            while (accumulator.size() < 63) begin
                accumulator.push_back(0);
            end
            
            expected_blocks.push_back({expecting_new_stream, {>>{accumulator[0:62]}}});
            expecting_new_stream = 0;
            accumulator = accumulator[63:$];
        end

        if (eos) begin
            // Insert stream header
            {>>{accumulator}} = {chip_id, expected_tag};
            expecting_new_stream = 1;
        end
        
        // Set input for hit assembler.
        din <= {>>{data}};
        din_size <= 7'(data.size());
        din_eos <= eos;
        din_eoe <= eoe;

        // If the assembler is not ready, wait until it is.
        while (~ready_out) @(posedge clk);

        din_dv <= 1;
        
        // Let assembler receive data.
        @(posedge clk);

        // Clear data valid so if we keep clocking, the hit assembler
        // doesn't spuriously consume data. A subsequent call to this
        // task can set it again.
        din_dv <= 0;
    endtask
    
    task provide_din_random (input integer size, logic eos, logic eoe);
        logic data[];

        data = new[size];

        // Generate some random data.
        assert(randomize(data));

        provide_din(data, eos, eoe);
    endtask

    task provide_din_ones (input integer size, logic eos, logic eoe);
        logic data[];

        data = new[size];

        // Fill the array with ones. If there is a better way to do this, please let me know.
        for (integer i = 0; i < size; i++)
            data[i] = 1'b1;

        provide_din(data, eos, eoe);
    endtask

    task provide_din_zeros (input integer size, logic eos, logic eoe);
        logic data[];

        data = new[size];

        for (integer i = 0; i < size; i++)
            data[i] = 1'b0;

        provide_din(data, eos, eoe);
    endtask

    task automatic expect_output_blocks (input integer amount, input integer timeout);
        integer cycles;

        cycles = 0;
        output_blocks_expected+= amount;
        
        while (output_blocks_consumed < output_blocks_expected && cycles < timeout) begin
            @(posedge clk);
            cycles++;
        end

        if (output_blocks_consumed < output_blocks_expected) begin
            $error("timed out before receiving an output block");
            $stop;
        end

        if (output_blocks_consumed != output_blocks_expected) begin
            $error("received too many output blocks");
            $stop;
        end
    endtask

    task automatic expect_no_output (input integer timeout);
        integer cycles;

        cycles = 0;

        repeat(timeout) @(posedge clk);

        if (output_blocks_consumed != output_blocks_expected) begin
            $error("received an output block when not expected");
            $stop;
        end
    endtask

    task automatic test_block_output_conditions();
        // Make sure blocks don't output when they're not supposed to.
        provide_din_random(63 - accumulator.size() - 1, 0, 0); // come up 1 bit short
        expect_no_output(.timeout(20));

        // Give it the last bit it needs to finish and make sure it outputs the block without waiting
        // for more data.
        provide_din_random(1, 0, 0);
        expect_output_blocks(.amount(1), .timeout(20));

        assert (accumulator.size() == 0);
    endtask

    task automatic test_variable_size_input();
        integer random_size;

        // Test a bunch of small chunks
        repeat(1000) begin
            // Randomly insert some breaks in the input data
            randcase
              100: ;                       // no break
              10: @(posedge clk);          // single clock cycle break
              1: repeat(5) @(posedge clk); // two clock cycle break
            endcase
            provide_din_random(16, 0, 0);
        end

        // Test a bunch of big chunks
        repeat(1000) begin
            // Randomly insert some breaks in the input data
            randcase
              100: ;                       // no break
              10: @(posedge clk);          // single clock cycle break
              1: repeat(5) @(posedge clk); // two clock cycle break
            endcase
            provide_din_random(110, 0, 0);
        end

        // Test a bunch of variable size chunks
        repeat(1000) begin
            // Randomly insert some breaks in the input data
            randcase
              100: ;                       // no break
              10: @(posedge clk);          // single clock cycle break
              1: repeat(5) @(posedge clk); // two clock cycle break
            endcase
            assert(randomize(random_size) with {16 <= random_size && random_size <= 110 ; });
            provide_din_random(random_size, 0, 0);
        end

        // End the stream to be polite to any tests who follow
        provide_din_zeros(16, 1, 1);
    endtask
    
    task automatic test_end_of_event();
        provide_din_zeros(30, 0, 1); // end an event in the middle of a block
        // 11-bit internal tag
        provide_din_zeros(22, 0, 1); // end an event at the end of a block
        // 11-bit internal tag
        provide_din_zeros(51, 0, 1); // end an event at a block boundary
        // 11-bit internal tag
        provide_din_zeros(53, 0, 0);
        expect_output_blocks(.amount(3), .timeout(20));

        assert (accumulator.size() == 0);        
    endtask

    task automatic test_end_of_stream();
        // End-of-stream in the middle of a block
        provide_din_ones(15, 1, 1);
        // Let's see what the start of the next stream looks like
        provide_din_zeros(63 - 2 - 8, 0, 0); // minus chip ID and initial tag
        expect_output_blocks(.amount(2), .timeout(20));
        assert (accumulator.size() == 0);

        // End-of-stream near the end of a block
        provide_din_ones(60, 1, 1); // 3 bits left in this block
        // Let's see what the start of the next stream looks like
        provide_din_zeros(63 - 2 - 8, 0, 0); // minus chip ID and initial tag
        expect_output_blocks(.amount(3), .timeout(20)); // expect an orphan block
        assert (accumulator.size() == 0);

        // End-of-stream exactly at the end of a block
        provide_din_ones(63, 1, 1);
        // Let's see what the start of the next stream looks like
        provide_din_zeros(63 - 2 - 8, 0, 0); // minus chip ID and initial tag
        expect_output_blocks(.amount(3), .timeout(20)); // expect an orphan block
        assert (accumulator.size() == 0);

        // End-of-stream when there is data to flush.
        $display("Testing EOS when there is two extra blocks worth of data to flush");
        // 0 bits in accumulator
        provide_din_ones(110, 0, 0);
        // 47 bits in accumulator (S_BODY output 63 no flush)
        provide_din_ones(110, 1, 1);
        // 94 bits in accumulator (S_BODY output 63 flush)
        // 31 bits in accumulator (S_EOS output 63 flush)
        // 0 bits in accumulator  (S_EOS output 31 flush)
        expect_output_blocks(.amount(4), .timeout(20));

        $display("Testing EOS when there is an extra block worth of data to flush but we need another block for 6-zero");
        // 10 bits in accumulator (from stream header)
        provide_din_ones(110, 0, 0);
        // 57 bits in accumulator (S_BODY output 63 no flush)
        provide_din_ones(69, 1, 1);
        // 63 bits in accumulator (S_BODY output 63 flush)
        // 0 bits in accumulator (S_EOS output 63 flush, can't fit 6 zeros)
        // 0 bits in accumulator  (S_EOS output 0 flush because need 6 zeros)
        expect_output_blocks(.amount(4), .timeout(20));

        $display("Testing EOS when we barely need 2 blocks for 6-zero");
        // 10 bits in accumulator (from stream header)
        provide_din_ones(110, 0, 0);
        // 57 bits in accumulator (S_BODY output 63 no flush)
        provide_din_ones(64, 1, 1);
        // 58 bits in accumulator (S_BODY output 63 flush)
        // 0 bits in accumulator (S_EOS output 58 flush, can't fit 6 zeros)
        // 0 bits in accumulator  (S_EOS output 0 flush because need 6 zeros)
        expect_output_blocks(.amount(4), .timeout(20));

        $display("Testing EOS when there is exactly enough room in the EOS block for 6 zeros");
        // 10 bits in accumulator (from stream header)
        provide_din_ones(110, 0, 0);
        // 57 bits in accumulator (S_BODY output 63 no flush)
        provide_din_ones(63, 1, 1);
        // 57 bits in accumulator (S_BODY output 63 flush)
        // 0 bits in accumulator (S_EOS output 57 flush, happy because we could fit 6 zeros in)
        expect_output_blocks(.amount(3), .timeout(20));
    endtask

    task automatic test_backpressure();
        // Stop accepting dut output into the testbench. Just fill up the output FIFO.
        ready_in <= 1'b0;
        
        while (dut.ready_in) begin
            provide_din_random(63, 0, 0);
        end

        // Drain it out
        ready_in <= 1'b1;

        while (expected_blocks.size() != 0) begin
            @(posedge clk);
        end
    endtask
    
    /* Inputs. */
    initial begin        
        restart    = 0;
        tag_init   = 8'd14;
        chip_id    = 2'b10;
        en_chip_id = 1'b1;
        en_eos     = 1'b1;

        din_dv     = 0;
        ready_in   = 1;

        expecting_new_stream = 1;
        expected_tag = tag_init;
        
        @(posedge clk);
        
        /* Wait for reset to complete. */
        while (reset) @(posedge clk);
        
        /* Wait for DUT to be ready for input. */
        while (~ready_out) @(posedge clk);

        /* Since we are starting a new stream, the hit assembler will
         insert some headers. Add this to our queue so the readout doesn't
         get confused. */
        {>>{accumulator}} = {chip_id, tag_init};

        test_block_output_conditions();
        test_end_of_event();
        test_end_of_stream();
        test_variable_size_input();
        test_backpressure();
        
        repeat(10) @(posedge clk);
                
        sim_done <= 1;
    end

    logic ready_in_d1;

    always_ff @(posedge clk) begin
        ready_in_d1 <= ready_in;
    end
    
    /* 64-bit Packet Readout. */
    initial begin
        logic [63:0] expected_block;

        output_blocks_expected = 0;
        output_blocks_consumed = 0;
        
        @(posedge clk);
        while (reset) @(posedge clk);
        
        while (~sim_done) begin
            if (dout_dv && ready_in_d1 && ~sim_done) begin
                if (expected_blocks.size() == 0) begin
                    $error("Readout got block when there shouldn't have been enough data to produce a complete block (had %d bytes in testbench accumulator).", accumulator.size());
                end

                /* Pop a block off the queue. */
                expected_block = expected_blocks.pop_front();
                
                $display("BLOCK: (EOS %b EOE %b, time %t)", dout_eos, dout_eoe, $realtime);
                $display("Readout:  %b", dout);
                $display("Expected: %b", expected_block);

                if (dout[63]) begin
                    if (en_chip_id) begin
                        $display("tag: %d", dout[60:53]);
                    end else begin
                        $stop;
                    end
                end
                
                assert(dout == expected_block) else $stop;

                output_blocks_consumed <= output_blocks_consumed + 1;
            end

            @(posedge clk);
        end
    end

    /* Watchdog to terminate test if hit assembler hangs. */
    initial begin
        watchdog_timeout = 0;

        while (~sim_done) begin
            if (watchdog_timeout > 0) begin
                if (watchdog_timeout == 1) begin
                    $display("watchdog timed out");
                    $stop;
                end else begin
                    watchdog_timeout-= 1;
                end
            end else begin
                /* Watchdog is disabled. */
            end
            
            @(posedge clk);
        end
    end
endmodule 
