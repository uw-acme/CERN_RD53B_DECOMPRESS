// tests that reg_hits_per_stream can be set by debounced switches
`timescale 1ns / 1ns
module tb_set_stream_size();
	logic 			clk;
    logic 			reset;
    logic [ 3:0] 	switches;
    logic [15:0] 	hits_per_stream;
	
	set_stream_size dut(
		.clk,
		.reset,
		.switches,
		.hits_per_stream
	);
	
	// Simulated clock
    parameter CLOCK_PERIOD = 5;
    initial begin 
        clk <= 0;
        forever #(CLOCK_PERIOD/2) clk <= ~clk;
    end
	
	integer i;
	initial begin
		reset		<= 1; 
		switches	<= 4'b0000; 
		@(posedge clk);
		
		// test debouncing
		reset		<= 0; 
		switches	<= 4'b0001;
		repeat(10) @(posedge clk);		
		
		// test all switch configurations
		for (i=0; i<16; i++) begin
			reset		<= 1; @(posedge clk);
			reset		<= 0; @(posedge clk);
			switches	<= i; repeat(1e6) @(posedge clk);
		end
		repeat(1e5) @(posedge clk);
		$stop;
	end
endmodule