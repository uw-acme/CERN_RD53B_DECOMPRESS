-------------------------------------------------------------------------------
-- Author      : Gjones
-------------------------------------------------------------------------------
-- Simple testbench for RD53B emulator hit generator sub-block hit_encode.sv
-------------------------------------------------------------------------------
library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;
use     std.textio.all;

entity tb_hit_encode is
end tb_hit_encode;

architecture struct of tb_hit_encode is

-- Clock freq expressed in MHz
constant CLK_FREQ_MHZ           : real      := 100.0;
-- Clock period
constant CLK_PER_MHZ            : time      := integer(1.0E+6/(CLK_FREQ_MHZ)) * 1 ps;

signal sim_done                 : boolean   := false;
signal busy                     : std_logic := '0';

signal clk                      : std_logic := '0';             
signal reset                    : std_logic := '1';           

-- Controls
signal en_encode                : std_logic := '1';           

-- input 
signal din                      : std_logic_vector(15 downto 0);    -- 
signal din_eos                  : std_logic; 
signal din_dv                   : std_logic; 

-- ToT output
signal dout                     : std_logic_vector(29 downto 0);    -- Output data.  
signal dout_size                : std_logic_vector( 4 downto 0);    -- Number of bits in dout (2 to 16)
signal dout_dv                  : std_logic;                        -- Set when new dout_hit produced  
                         
---------------------------------------------------------------
-- Delay
-------------------------------------------------------------
procedure clk_delay(
    constant nclks  : in  integer
) is
begin
    for I in 1 to nclks loop
        wait until clk'event and clk='0';
    end loop;
end;

----------------------------------------------------------------
-- Print a string with no time or instance path.
----------------------------------------------------------------
procedure cpu_print_msg(
    constant msg    : in    string
) is
variable line_out   : line;
begin
    write(line_out, msg);
    writeline(output, line_out);
end procedure cpu_print_msg;

-------------------------------------------------------------
-- Procedure to drive hit_encode input data
-- addr_din (clk, HITMAP, din, din_eos, din_dv);
-------------------------------------------------------------
procedure enc_din( 
    signal clk          : in  std_logic;
    constant hitmap     : in  std_logic_vector(15 downto 0);

    signal din          : out std_logic_vector(15 downto 0);
    signal din_eos      : out std_logic;
    signal din_dv       : out std_logic
) is
begin
    wait until clk'event and clk='0';
    din             <= hitmap;   
    din_eos         <= '0';
    din_dv          <= '1';
end;

-------------------------------------------------------------
-- Procedure to drive hit_encode input data with EOS set
-- addr_din (clk, HITMAP, din, din_eos, din_dv);
-------------------------------------------------------------
procedure enc_din_eos( 
    signal clk          : in  std_logic;
    constant hitmap     : in  std_logic_vector(15 downto 0);

    signal din          : out std_logic_vector(15 downto 0);
    signal din_eos      : out std_logic;
    signal din_dv       : out std_logic
) is
begin
    wait until clk'event and clk='0';
    din             <= hitmap;   
    din_eos         <= '1';
    din_dv          <= '1';
    wait until clk'event and clk='0';
    din             <= (others=>'0');
    din_eos         <= '0';
    din_dv          <= '0';
end;

-------------------------------------------------------------
-- Procedure to drive hit_encode inputs all low 
-------------------------------------------------------------
procedure enc_none( 
    signal clk          : in  std_logic;
    signal din          : out std_logic_vector(15 downto 0);
    signal din_eos      : out std_logic;
    signal din_dv       : out std_logic
) is
begin
    wait until clk'event and clk='0';
    din             <= (others=>'0');
    din_eos         <= '0';
    din_dv          <= '0';
end;


begin
    
    -------------------------------------------------------------
    -- 
    -------------------------------------------------------------
    u_hit_encode : entity work.hit_encode
    port map(
        clk         => clk          , -- input   logic           
        reset       => reset        , -- input   logic           

        en_encode   => en_encode    , -- input   logic             // '1' = ToT enabled, '0'= No ToT data

        din         => din          , -- input   logic   [15:0]     // 
        din_eos     => din_eos      , -- input   logic              // Input data end-of-stream
        din_dv      => din_dv       , -- input   logic              // Input data valid

        dout        => dout         , -- output  logic   [29:0]     // Output data.  
        dout_size   => dout_size    , -- output  logic   [ 4:0]     // Number of bits in dout (2 to 16)
        dout_dv     => dout_dv        -- output  logic              // Output data valid
    );



    -------------------------------------------------------------
    -- Generate logic clock
    -------------------------------------------------------------
    pr_clk : process
    begin
        clk  <= '0';
        wait for (CLK_PER_MHZ/2);
        clk  <= '1';
        wait for (CLK_PER_MHZ-CLK_PER_MHZ/2);
        if (sim_done=true) then
            wait;
        end if;
    end process;


    -------------------------------------------------------------
    -- Main 
    -------------------------------------------------------------
    pr_gen : process
    begin
        -- Reset
        reset           <= '1';
        en_encode       <= '1';           
        din             <= X"0000";
        din_eos         <= '0';
        din_dv          <= '0';

        clk_delay(10);
        reset           <= '0';
        clk_delay(10);

        -- Hit 0
        -- Series of hits. No gap
        enc_din     (clk,   X"0001",    din, din_eos, din_dv);
        enc_din     (clk,   X"0003",    din, din_eos, din_dv);
        enc_din     (clk,   X"0007",    din, din_eos, din_dv);
        enc_din     (clk,   X"FFFF",    din, din_eos, din_dv);
        enc_din     (clk,   X"001F",    din, din_eos, din_dv);
        enc_din     (clk,   X"003F",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        clk_delay(5);

        -- Series of hits. Gaps
        enc_din     (clk,   X"0001",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        enc_din     (clk,   X"0003",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        enc_din     (clk,   X"0007",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        enc_din     (clk,   X"FFFF",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        enc_din     (clk,   X"001F",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        enc_din_eos (clk,   X"003F",    din, din_eos, din_dv);
        enc_none    (clk,               din, din_eos, din_dv);
        clk_delay(5);

        sim_done    <= true;
        wait;

    end process;


end struct;

