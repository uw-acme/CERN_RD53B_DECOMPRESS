`timescale 1ns / 1ps

// Potential Issues:

// Could have an issue with an empty tag
module decode_top_tb();

    logic                           SYSCLK_P;
    logic                           SYSCLK_N;
    logic                           CPU_RESET; 
    logic                           GPIO_SW_S; // start
    logic                           GPIO_SW_N; // stop
    logic                           GPIO_LED_0_LS; 
    logic                           GPIO_LED_1_LS;
    logic                           GPIO_LED_2_LS;
    logic                           GPIO_LED_3_LS;
    logic                           GPIO_LED_4_LS;
    logic                           GPIO_LED_5_LS;
    logic                           GPIO_LED_6_LS;
    logic                           GPIO_LED_7_LS;

    parameter ENGINES_TOTAL = 12;
    // How man valid lines are in the decode top ROM (The actual data sent to decoder)
    parameter VALID_STREAMS_NUM = 11;
    // How many data frames to recieve from one engine
    parameter NUM_FRAMES = 300;
    // Number of quarter rows per stream
    parameter NUM_HITS = 3;
    // Overall number of streams that are possible
    parameter NUM_STREAMS = 3;

    

    decode_top #(ENGINES_TOTAL, NUM_HITS, NUM_STREAMS, VALID_STREAMS_NUM) dut (
        .SYSCLK_P,
        .SYSCLK_N,
        .CPU_RESET,
        .GPIO_SW_S,
        .GPIO_SW_N,
        .GPIO_LED_0_LS, 
        .GPIO_LED_1_LS,
        .GPIO_LED_2_LS,
        .GPIO_LED_3_LS,
        .GPIO_LED_4_LS,
        .GPIO_LED_5_LS,
        .GPIO_LED_6_LS,
        .GPIO_LED_7_LS 
    );

    logic [9:0] data_frame_counter;
    task displayData();
        forever begin
            @(posedge dut.clk_i);
            //////////////////////////////////////////////////////////////////
            // Only shows data when there is a mismatch between engine and
            // premade decoded data
            //////////////////////////////////////////////////////////////////
            for (int i = 0; i < ENGINES_TOTAL; i++) begin
            //for (int i = 0; i < 1; i++) begin
                if (dut.u_test_block_1.error_flag[0][i] | dut.u_test_block_1.error_flag[1][i] |
                    dut.u_test_block_1.error_flag[2][i] | dut.u_test_block_1.error_flag[3][i]) begin
                    $display("Engine Number: %d", i);
                    $display("We have a mismatch");
                    $display("//////////////////////////////");
                    $display("Checked Data:");
                    $display("tag value : %B", dut.u_test_block_1.tag_check[i]);
                    $display("ccol value: %d, %B", dut.u_test_block_1.ccol_check[i], dut.u_test_block_1.ccol_check[i]);
                    $display("qrow value: %d, %B", dut.u_test_block_1.qrow_check[i], dut.u_test_block_1.qrow_check[i]);
                    $display("hitmap dec: %B", dut.u_test_block_1.hitmap_check[i]);
                    $display("//////////////////////////////");
                    $display("Engine Data:");
                    $display("tag value : %B", dut.u_test_block_1.tag_data[i]);
                    $display("ccol value: %d, %B", dut.u_test_block_1.ccol_data[i], dut.u_test_block_1.ccol_data[i]);
                    $display("qrow value: %d, %B", dut.u_test_block_1.qrow_data[i], dut.u_test_block_1.qrow_data[i]);
                    $display("hitmap dec: %B", dut.u_test_block_1.hitmap_data[i]);
                    $display("//////////////////////////////");
                    $display("\n");
                end
            end


            //////////////////////////////////////////////////////////////////
            // Shows all data that comes in from decode engine to the test
            // block
            //////////////////////////////////////////////////////////////////
            //for (int i = 0; i < ENGINES_TOTAL; i++) begin
            /*for (int i = 0; i < 1; i++) begin
                if(dut.u_test_block_1.engine_valid_i[i] & dut.u_test_block_1.check_fifo_ready_o[i]) begin
                    $display("Engine Number: %d", i);
                    $display("//////////////////////////////");
                    $display("Engine Data:");
                    $display("tag value : %B", dut.u_test_block_1.tag_data[i]);
                    $display("ccol value: %d, %B", dut.u_test_block_1.ccol_data[i], dut.u_test_block_1.ccol_data[i]);
                    $display("qrow value: %d, %B", dut.u_test_block_1.qrow_data[i], dut.u_test_block_1.qrow_data[i]);
                    $display("hitmap dec: %B", dut.u_test_block_1.hitmap_data[i]);
                    $display("//////////////////////////////");
                    $display("\n");
                end
            end*/
        end
    endtask


    initial begin
        data_frame_counter <= 0;
        displayData();
    end


    parameter CLOCK_PERIOD=5000;
    initial begin
        SYSCLK_N<=0; 
		SYSCLK_P<=1;
        forever #(CLOCK_PERIOD/2) begin
            SYSCLK_N <= ~SYSCLK_N;
            SYSCLK_P <= ~SYSCLK_P;
        end
    end

    initial begin       
        CPU_RESET <= 1; repeat (10) @(posedge SYSCLK_P);
        CPU_RESET <= 0; repeat (10) @(posedge SYSCLK_P);
        @(posedge dut.clkreset_lock);
        GPIO_SW_N <= 0; GPIO_SW_S <= 0; repeat(100) @(posedge dut.clk_i);
        GPIO_SW_S <= 1; repeat (10) @(posedge dut.clk_i);
        for (int i = 0; i < 1000000; i++) begin
            GPIO_SW_N <= 1; GPIO_SW_S <= 0; #10;
            GPIO_SW_S <= 1; GPIO_SW_N <= 0; #10;

        end
        for (int i = 0; i < NUM_FRAMES + 1; i++) begin
            @(posedge dut.decode_engines[0].u_decode_engine.decoded_data_ready);
        end
    
        $stop;
    end

endmodule