`timescale 1ns/1ps

module tb_hit_barrelshift();
    logic clk, reset;

    logic [109:0] din;
    logic [7:0]   din_shift;
    logic         din_dv;

    logic [172:0] dout;
    logic         dout_dv;

    logic         sim_done;
    
    hit_barrelshift #(.ctrl(logic)) dut
        (
         .clk,
         .reset,
        
         .din,
         .din_shift,
         .din_dv,

         .dout,
         .dout_dv
         );
    
    parameter CLOCK_MHZ = 100;
    
    initial begin // clock generator
        sim_done = 0;
        clk <= 0;
        
        while(~sim_done) #(500/CLOCK_MHZ) clk <= ~clk;
    end

    initial begin // reset generator
        reset <= 1;
        repeat(10) @(posedge clk);      
        reset <= 0;
    end

    parameter COUNT = 173;

    logic [109:0] random_input;
    
    // inputs
    initial begin
        integer i;

        assert(randomize(random_input));
        
        // random bitstring
        din       = random_input;
        din_shift = 0;
        din_dv    = 0;

        // wait to come out of reset
        @(posedge clk);
        while(reset) @(posedge clk);

        for(i = 0; i < COUNT; i++) begin
            din_shift <= i;
            din_dv <= 1;
            @(posedge clk);
            din_dv <= 0;
            @(posedge clk);
        end
    end

    // output verification
    logic [345:0] extended_result;
    assign extended_result = {173'b0, random_input, 63'b0};
    
    initial begin
        integer i;
        integer fails;

        // wait to come out of reset
        @(posedge clk);
        while(reset) @(posedge clk);

        fails = 0;

        for(i = 0; i < COUNT; i++) begin
            while(~dout_dv) @(posedge clk);

            assert(dout == extended_result[i +: 173]) else begin
                $display("FAILED (time %t):", $realtime);
                $display("shift:  %d", i);
                $display("input:  %b", random_input);
                $display("output: %b", dout);
                $display("expect: %b", extended_result[i +: 173]);
                
                $display("");

                fails++;
            end

            if(fails > 10) begin
                $error("Too many test failures; aborting");
                $stop;
            end

            
            while(dout_dv) @(posedge clk);
        end

        repeat(10) @(posedge clk);

        if(fails == 0) begin
            $display("No failures!");
        end
        
        sim_done <= 1;
    end
endmodule
