// tests that switches are properly debounced
`timescale 1ns / 1ps
module tb_debounce();
	logic clk;
	logic reset;
    logic sw_in;
    logic sw_out;
	
	debounce dut (clk, reset, sw_in, sw_out);
	
	// Simulated clock
    parameter CLOCK_PERIOD = 100;
    initial begin 
        clk <= 0;
        forever #(CLOCK_PERIOD/2) clk <= ~clk;
    end
	
	initial begin
		reset<=1; sw_in<=0; @(posedge clk);
		// test sw_out becomes true then false
		reset<=0; sw_in<=1; repeat(66000) @(posedge clk);
		sw_in<=0; repeat(66000) @(posedge clk);
		// test short shift not passed
		sw_in<=1; repeat(4) @(posedge clk);
		sw_in<=0; @(posedge clk);
		// test counter not passed
		sw_in<=1; repeat(65534) @(posedge clk);
		sw_in<=0; repeat(5) @(posedge clk);
		$stop;
	end
endmodule