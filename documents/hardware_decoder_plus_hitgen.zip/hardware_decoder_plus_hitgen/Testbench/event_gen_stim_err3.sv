//----------------------------------------------------------------------------
// FSM that drives data captured from logic analyzer
//
//----------------------------------------------------------------------------
`timescale 1ns / 1ps


module event_gen_incr
(
    input   logic           clk             ,  
    input   logic           reset           , 

    input   logic           enable          , // Enable stream generation. 
    input   logic           start           , // Begin stream generation if enabled
    input   logic           ready           , // Downstream block can accept new hit data. This should be tied high for a real system with no back-pressure.
    output  logic           busy            , // Set low after end of a stream if enable is low.   
    
    input   logic   [ 1:0]  mode            , // Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
    input   logic   [31:0]  seed            , // Seed to initialize the pseudo-random number generator

    // Controls for stream size. The first condition to be reached, terminates each stream
    input   logic   [15:0]  hits_per_stream , // Number of hits in a stream.
    input   logic           hitmaker_dout_dv, // Set high when hitmaker block outputs a new word
    input   logic   [15:0]  words_per_stream, // Number of 64-bit words output from the hitmaker in a stream. Approximate. Set to ~buffer size in decoder.

    input   logic   [ 4:0]  lv_density      , // Parameter to set the probability of a vertical line of hits occurring. Can be zero
    input   logic   [ 4:0]  lv_maxlen       , // Parameter to set the max length of a v-line of hits occurring
    input   logic   [11:0]  cl_density      , // Parameter to set the range of the increment in x,y from one cluster to the next.
    input   logic   [11:0]  cl_max          , // Parameter to set the max number of clusters+lines to generate.

    output  logic           dout_dv         , //  Set when new dout_hit produced  
    output  logic           dout_eos        , //  Set for end-of-stream. Last hit in stream 
    output  logic           dout_eoe        , //  Set for end-of-event. Last hit in an event 
    output  logic   [ 7:0]  dout_hit_qrow   , // 
    output  logic   [ 5:0]  dout_hit_ccol   , // 
    output  logic   [15:0]  dout_hit_hitmap   // 
);
 


    //----------------------------------------------------------------------------
    //----------------------------------------------------------------------------
    initial 
    begin
        busy               = 0;
        dout_dv            = 0;
        dout_eos           = 0;
        dout_eoe           = 0;
        dout_hit_qrow      = 0;
        dout_hit_ccol      = 0;
        dout_hit_hitmap    = 0;

          // For tb_hitmaker sim
//        #200 dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h; dout_dv = 1'b1;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h; dout_eos = 1'b1;
//        #10  dout_hit_qrow = 6'h;  dout_hit_hitmap = 16'h;   dout_hit_ccol = 8'h; dout_eos = 1'b0; dout_dv = 1'b0;
//
//
//        // For full FPGA sim
        #565   dout_hit_qrow = 6'h09;  dout_hit_hitmap = 16'h01f0;   dout_hit_ccol = 8'h2f; dout_dv = 1'b1;
        #6.25  dout_hit_qrow = 6'h0a;  dout_hit_hitmap = 16'h01f1;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h0b;  dout_hit_hitmap = 16'h01f2;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h0c;  dout_hit_hitmap = 16'h01f3;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h0e;  dout_hit_hitmap = 16'h01f4;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h0f;  dout_hit_hitmap = 16'h01f5;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h10;  dout_hit_hitmap = 16'h01f6;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h12;  dout_hit_hitmap = 16'h01f7;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h14;  dout_hit_hitmap = 16'h01f8;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h16;  dout_hit_hitmap = 16'h01f9;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h18;  dout_hit_hitmap = 16'h01fa;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h1a;  dout_hit_hitmap = 16'h01fb;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h1c;  dout_hit_hitmap = 16'h01fc;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h1d;  dout_hit_hitmap = 16'h01fd;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h1e;  dout_hit_hitmap = 16'h01fe;   dout_hit_ccol = 8'h2f;
        #6.25  dout_hit_qrow = 6'h00;  dout_hit_hitmap = 16'h01ff;   dout_hit_ccol = 8'h30;
        #6.25  dout_hit_qrow = 6'h01;  dout_hit_hitmap = 16'h0200;   dout_hit_ccol = 8'h30;
        #6.25  dout_hit_qrow = 6'h03;  dout_hit_hitmap = 16'h0201;   dout_hit_ccol = 8'h30; dout_eos = 1'b1;

        #6.25  dout_hit_qrow = 6'h00;  dout_hit_hitmap = 16'h0000;   dout_hit_ccol = 8'h00; dout_eos = 1'b0; dout_dv = 1'b0;

        #500 busy = 1'b0;  
    end
        
endmodule

