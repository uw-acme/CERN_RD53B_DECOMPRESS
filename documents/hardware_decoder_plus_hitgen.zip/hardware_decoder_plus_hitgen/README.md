# Hardware Decoder with Hit Generator #

### Repo Hierarchy ###
<pre>
1. Constraints
2. Documents
3. Include
4. Src
5. Testbench
6. Tools
     |--Modelsim
     |--Vivado
     |--Scripts
     |--Vivado


### Contributors ###
Hardware Decoder
    - Donavan Erickson (donavan2@uw.edu)

Hit Generator
    - Geoff Jones (geoffhjones@msn.com)
    - Collin May (mayco@uw.edu)
    - An Nguyen (nguyea9@uw.edu)

### Description ###
- This is an fpga build for the KC705 development board that implements a hardware decoder for the RD53B chip.
- The repository also includes a hit generator to dynamically create stream data for the hardware decoder
