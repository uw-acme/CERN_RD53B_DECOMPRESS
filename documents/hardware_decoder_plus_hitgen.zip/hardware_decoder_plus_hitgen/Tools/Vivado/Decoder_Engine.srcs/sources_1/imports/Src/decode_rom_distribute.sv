module decode_rom_distribute #(ENGINE_NUM = 2) (
    input                          clk_i,
    input                          rst_i,
    input  [ENGINE_NUM-1:0] [15:0] first_rows_i,
    input  [ENGINE_NUM-1:0]        first_row_valid_i,
    input  [ENGINE_NUM-1:0] [13:0] sec_rows_i,
    input  [ENGINE_NUM-1:0]        sec_row_valid_i,
    output [ENGINE_NUM-1:0] [31:0] dec_first_rows_o,
    output [ENGINE_NUM-1:0] [15:0] dec_sec_rows_o
);

logic [2:0] first_row_select_a;
logic [2:0] first_row_select_b;
logic [2:0] second_row_select_a;
logic [2:0] second_row_select_b;


// This might end up being an inefficent way to select the active valid
always_comb begin
    first_row_select_a = 0;
    first_row_select_b = 0;
    for (int i = ENGINE_NUM-1; i >= ENGINE_NUM/2; i--) begin
        if(first_row_valid_i[i] == 1) begin
            first_row_select_a = i;
        end
    end

    for (int i = (ENGINE_NUM/2) - 1; i >= 0; i--) begin
        if(first_row_valid_i[i] == 1) begin
            first_row_select_b = i;
        end
    end
end

always_comb begin
    second_row_select_a = 0;
    second_row_select_b = 0;
    for (int i = ENGINE_NUM-1; i >= ENGINE_NUM/2; i--) begin
        if(sec_row_valid_i[i] == 1) begin
            second_row_select_a = i;
        end
    end

    for (int i = (ENGINE_NUM/2)-1; i >= 0; i--) begin
        if(sec_row_valid_i[i] == 1) begin
            second_row_select_b = i;
        end
    end
end



// ROM used for decoding the first row
decoder_first_row_16x32 u_decoder_first_row_16x32 (
  .clka(clk_i),  
  .addra(first_rows_i[0]),                // input wire [15 : 0] addra
  .douta(dec_first_rows_o[0]),            // output wire [31 : 0] douta
  .clkb(clk_i),    // input wire clkb
  .addrb(first_rows_i[1]),  // input wire [13 : 0] addrb
  .doutb(dec_first_rows_o[1])  // output wire [15 : 0] doutb
);

// ROM used for decoding the second row
decoder_second_row_14x16 u_decoder_second_row_14x16 (
  .clka(clk_i), 
  .addra(sec_rows_i[0]),                  // input wire [13 : 0] addra
  .douta(dec_sec_rows_o[0]),            // output wire [15 : 0] douta
  .clkb(clk_i),    // input wire clkb
  .addrb(sec_rows_i[1]),  // input wire [13 : 0] addrb
  .doutb(dec_sec_rows_o[1])  // output wire [15 : 0] doutb
);


endmodule