`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/19/2020 07:07:39 PM
// Design Name: 
// Module Name: decode_engine_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


// TODO: Create a task for displaying data that is read out

module decode_engine_tb();
    logic         clk_i;
    logic         rst_i;
    logic         valid_stream_i;
    logic  [63:0] data_stream_i;
    logic         end_trans_i;
    logic         ready_engine_o;
    logic [127:0]  data_engine_o;
    logic         valid_decode_data_o;
    logic         ready_decode_data_i;
    
    Decode_Engine_Top dut (
    .clk_i,
    .rst_i,
    .valid_stream_i,
    .data_stream_i,
    .end_trans_i,
    .ready_decode_data_i,
    .ready_engine_o,
    .data_engine_o,
    .valid_decode_data_o
    );
    
    parameter ClockDelay = 1000;
    
    task newDataStream(input [63:0] data);
        valid_stream_i <= 1;
        data_stream_i <= data;
        @(posedge clk_i);
        valid_stream_i <= 0;
        @(posedge clk_i);
    endtask

    logic [9:0] data_frame_counter;
    task displayData();
        forever begin
            @(posedge clk_i);
            if (dut.decoded_data_ready == 1) begin
                data_frame_counter <= data_frame_counter + 1;
                $display("\n data frame %d", data_frame_counter);
                $display("tag value : %B", dut.tag_reg);
                $display("ccol value: %B", dut.ccol_reg);
                $display("qrow value: %B", dut.qrow_reg);
                $display("hitmap dec: %B", dut.decoded_hitmap);
                $display("tot value : %B", dut.tot_reg);
            end
        end
    endtask
    
    initial begin // Set up the clock
        clk_i <= 0;
        forever #(ClockDelay/2) clk_i <= ~clk_i;
    end

    initial begin
        data_frame_counter <= 0;
        displayData();
    end
    
    
    initial begin
        rst_i <= 1; end_trans_i <= 0; data_stream_i <= 0; valid_stream_i <= 0; ready_decode_data_i <= 1; @(posedge clk_i);
        @(posedge clk_i);
        rst_i <= 0; @(posedge clk_i);
        //@(posedge clk_i);
        // Empty stream check
        
        //TODO: Deal with empty frames
        newDataStream(64'b0000000000000000000000000000000000000000000000000000000101111111);
        end_trans_i <= 1;
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        @(posedge ready_engine_o);
        // Two frames of data
        newDataStream(64'b0000100000100011111010000111001010101010000111101000001111111111);
        newDataStream(64'b0000000000000000000000000000000000000000000000000000000000000000);
        valid_stream_i <= 0;
        end_trans_i <= 1;
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        @(posedge ready_engine_o);
        newDataStream(64'b0000100000100011111010000111001010101010000111101000001111111111);
        newDataStream(64'b0000000000000000000000000000000000000000000000000000000000000000);
        valid_stream_i <= 0;
        end_trans_i <= 1;
        @(posedge clk_i);
        @(posedge clk_i);
        end_trans_i <= 0;
        @(posedge clk_i);
        for(int i = 0; i < 64; i++) begin
            @(posedge clk_i);
        end
    
        $stop;
    end
    
endmodule
