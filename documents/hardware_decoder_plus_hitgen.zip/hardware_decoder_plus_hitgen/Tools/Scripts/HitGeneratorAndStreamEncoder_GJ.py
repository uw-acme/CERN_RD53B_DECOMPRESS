import random
import os

seqQrow = 0
seqCcol = 0

#--------------------------------------------------------------------
# Generates a random ccol and qrow address.
# The seen() array keeps a list of the pairs and is checked for repeated
# pairs so that a given ccol,qrow pair is only generated once.
#--------------------------------------------------------------------
seen = set()
def gencoordinates(m, n):    
    x, y = m, n
    while True:
        while (x, y) in seen:
            # QUESTION: how many rows and columns are you giving?
            ### 192   ####1 to 55 in core colum instead 50
            x, y = random.randint(1,50), random.randint(1,192)
        seen.add((x, y))
        return (x, y)


#--------------------------------------------------------------------
# randomHitGen: is generating random values of the core column, quarter row and hit data
# Eg: ccol: x   (integer value)
#     qrow: x   (integer value)
#     tot : x x x x x x x x   (1's or 0's) where 1 => 1111
#           x x x x x x x x                      0 => 0000
#--------------------------------------------------------------------
def randomHitGen():  

    # A core column can have values between 1 to 56 only as 000000 value corresponds to the end of the stream and 
    # any value greater than 55, in binary is 111xxx is regarded as the internal tag  
    r = gencoordinates(random.randint(1,50), random.randint(1,192))
    ccol = r[0] 
    f.write("Ccol: %d \n" % ccol)

    # A quarter row can have values between 1 and 192 as the total rows are 384. Therefore, 
    # total quarter rows = 192
    qrow = r[1]
    f.write("Qrow: %d \n" % qrow)

    # Array of 16 ToT values
    pixelHitTemp = [bool(random.getrandbits(1)) for i in range(16)]

    # The hit map contains 16 1's and 0's instead of True and False
    pixelHit = []
    for i in range (16):
        if pixelHitTemp[i] == True:
            pixelHit.append(1)
        elif pixelHitTemp[i] == False:
            pixelHit.append(0) 

    # Print hit map on two lines
    f.write("Tot : ")
    for i in range (16):
        if i < 8:
            f.write("%d " % pixelHit[i])
        else:
            f.write("%d " % pixelHit[i])
            
        if i == 7:
            f.write("\n" + "Tot : ")
    f.write("\n" + "#----------------------------------\n")

#--------------------------------------------------------------------
# seqHitGen: is generating sequential values of the core column, quarter row and random hit data
# Eg: ccol: x   (integer value)
#     qrow: x   (integer value)
#     tot : x x x x x x x x   (1's or 0's) where 1 => 1111
#           x x x x x x x x                      0 => 0000
#--------------------------------------------------------------------
def seqHitGen():  

    global seqQrow
    global seqCcol

    seqQrow = seqQrow + 2
    seqCcol = seqCcol + 1
    # A core column can have values between 1 to 56 only as 000000 value corresponds to the end of the stream and 
    # any value greater than 55, in binary is 111xxx is regarded as the internal tag  
    r = (seqCcol, seqQrow)
    ccol = r[0] 
    f.write("Ccol: %d \n" % ccol)

    # A quarter row can have values between 1 and 192 as the total rows are 384. Therefore, 
    # total quarter rows = 192
    qrow = r[1]
    f.write("Qrow: %d \n" % qrow)

    # Array of 16 ToT values
    pixelHitTemp = [bool(random.getrandbits(1)) for i in range(16)]

    # The hit map contains 16 1's and 0's instead of True and False
    pixelHit = []
    for i in range (16):
        if pixelHitTemp[i] == True:
            pixelHit.append(1)
        elif pixelHitTemp[i] == False:
            pixelHit.append(0) 

    # Print hit map on two lines
    f.write("Tot : ")
    for i in range (16):
        if i < 8:
            f.write("%d " % pixelHit[i])
        else:
            f.write("%d " % pixelHit[i])
            
        if i == 7:
            f.write("\n" + "Tot : ")
    f.write("\n" + "#----------------------------------\n")


#--------------------------------------------------------------------
# Writing the initial/starting comments to the file        
# then 
#--------------------------------------------------------------------
def mainBlock(nHits, randOrSeq):        

    f.write("#----------------------------------\n")
    f.write("# %d Hits in the stream\n" % nHits)
    f.write("#----------------------------------\n") 

    if (randOrSeq == '1'):
        for i in range (nHits):
            seqHitGen()
    else:
        for i in range (nHits):
            randomHitGen()
        


#####################################################################
# FUNCTIONS BELOW THIS ARE READING THE RANDOM GENERATED totValues
# AND MAKING THE HIT MAP TREE OUT OF IT 
#####################################################################
   
#--------------------------------------------------------------------
# Function takes an input array of bits that is an even number of values.
# Each bit value is 1 or 0.
# The function returns a node (an array with two values, both either 1 or 0) 
#--------------------------------------------------------------------
def GetNode(arrBits): 

    if len(arrBits) <= 1:
        return False
        
    mid                 = int(len(arrBits) / 2)
    node_count_1        = 0
    node_count_2        = 0
    nodeValue           = []
    midTemp             = mid

    # First half of arrBits sets first bit in the output node.
    # Count number of bits that are set.
    for i in range (mid):
        if arrBits[i] == 1:
            node_count_1 = node_count_1 + 1

    if node_count_1 == 0:
        nodeValue.append('0')
    else:
        nodeValue.append('1')


    # Second half of arrBits sets second bit in the output node.
    # Count number of bits that are set.
    for i in range (mid):
        if arrBits[midTemp + i] == 1:
            node_count_2 = node_count_2 + 1

    if node_count_2 == 0:
        nodeValue.append('0')
    else:
        nodeValue.append('1')
    
    return nodeValue


#--------------------------------------------------------------------
#              Hit Map Tree Structure
#                   node 14
#             13                    12
#         11     10             9        8             
#       7   6   5  4          3   2    1   0
#--------------------------------------------------------------------
def EncodeHitMap(arrBits):

    # LEVEL1
    node14 = GetNode(arrBits)         # node 14    
    # LEVEL2
    node13 = GetNode(arrBits[0:8])    # node 13
    node12 = GetNode(arrBits[8:16])   # node 12    
    # LEVEL3
    node11 = GetNode(arrBits[0:4])    # node 11
    node10 = GetNode(arrBits[4:8])    # node 10
    node9  = GetNode(arrBits[8:12])   # node 9
    node8  = GetNode(arrBits[12:16])  # node 8    
    # LEVEL4
    node7  = GetNode(arrBits[0:2])    # node 7
    node6  = GetNode(arrBits[2:4])    # node 6 
    node5  = GetNode(arrBits[4:6])    # node 5
    node4  = GetNode(arrBits[6:8])    # node 4   
    node3  = GetNode(arrBits[8:10])   # node 3
    node2  = GetNode(arrBits[10:12])  # node 2    
    node1  = GetNode(arrBits[12:14])  # node 1
    node0  = GetNode(arrBits[14:16])  # node 0
    
    tree = []
	# Reordering the bits so that it follows how the new bit order (1st row then 2nd row)
    tree = node14 + node13 + node11 + node10 + node7 + node6 + node5 + node4 + node12 + node9 + node8 + node3 + node2 + node1 + node0
    treeWrite = ''.join(tree)  #array to string
    
    # Print the full tree in the README file
    f.write("Hit Map Encoded Tree:\n")
    f.write("                        " + treeWrite[0:2] + "\n")
    f.write("                " + treeWrite[2:4] + "              " + treeWrite[16:18] + "\n" )
    f.write("           " + treeWrite[4:6] + "       " + treeWrite[6:8] + "      " + treeWrite[18:20] + "      " + treeWrite[20:22] + "\n")
    f.write("       " + treeWrite[8:10] + "     " + treeWrite[10:12] + "  " + treeWrite[12:14] + "   " + treeWrite[14:16] + " " + treeWrite[22:24] + "   " + treeWrite[24:26] + " " + treeWrite[26:28] + "   " + treeWrite[28:30] + "\n")
    decHitmap.append(treeWrite[29] + treeWrite[28] + treeWrite[27] + treeWrite[26] + treeWrite[25] + treeWrite[24] + treeWrite[23] + treeWrite[22] + treeWrite[15] + treeWrite[14] + treeWrite[13] + treeWrite[12] + treeWrite[11] +  treeWrite[10] + treeWrite[9] + treeWrite[8])
    treeTempArray = []

    #------------------------------------------------------------
    # Second (B) operation to reduce the size of the tree
    # ENCODING rules
    #       1. 01 - 0
    #       2. 10 - 10
    #       3. 11 - 11
    #       4. 00 - remove
    #------------------------------------------------------------
    for i in range(0,len(tree),2):
         if tree[i] == '0' and tree[i+1] == '1':        # Convert '01' node into a single '0'
             treeTempArray.append(['0'])
         elif tree[i] == '1' and tree[i+1] == '0':      # '10' remains '10'
             treeTempArray.append(tree[i:i+2])
         elif tree[i] == '1' and tree[i+1] == '1':      # '11' remains '11'
             treeTempArray.append(tree[i:i+2])
         else:                                          # Discard all '00' nodes
             pass
    
    treeTempString = "".join(["".join(i) for i in treeTempArray])    
    compressedTree.append(treeTempString)
    f.write("Hitmap Encoded Data:" + treeTempString + "\n")
    totGenerator(arrBits)
    
    
#--------------------------------------------------------------------
# Generate ToT values for each bit in the hit map that is set.
#--------------------------------------------------------------------
# Currently sets totValues[i] to all ones with a length of 4 x number
# of bits set in the hitmap
#--------------------------------------------------------------------
# Wanted:
# The first bit that is set is given a toT value of "0000",
# the second bit is given a ToT value of "0001"
# The 14th bit is given a ToT value of "1110" (14).
# The 15th bit is given a ToT value of "0000".
# The 16th bit is given a ToT value of "0001".
# Code 15 "1111", means 'no hit' and should never be seen.
#--------------------------------------------------------------------
def totGenerator(arrBits):

    hitCounter = 0

    # Count the number of bits that are set
    for i in range (len(arrBits)):
        if arrBits[i] == 1:
            hitCounter = hitCounter + 1

    totValues.append('1'*(hitCounter*4))  # each ToT value is 4 '1' bits


#--------------------------------------------------------------------
# Merge the two lines of ToT values into a single array
#
# Eg: 0 1  2  3 |  4  5  6  7
#     ---------- ------------ 
#     8 9 10 11 | 12 13 14 15
#
# Resulting list will look like:
#    0 1 2 3 | 8 9 10 11 | 4 5 6 7 | 12 13 14 15
#--------------------------------------------------------------------
def MergeHitMap(hits):
    merged_hits = hits[0:4] + hits[8:12] + hits[4:8] + hits[12:16]
    EncodeHitMap(merged_hits)


#--------------------------------------------------------------------
# Parse the file containing the generated random values for ccol, qrow and lit pixels and
# write it to the updated README while storing the respective values in their
# corresponding list function such as rowAddress holds all the values for the qrow address in serial order
# therefore, rowAddress[0].value = 1st qrow address and so on.....
# columnAddress holds column addresses
#--------------------------------------------------------------------
def readGeneratedValues(line):

    global countTemp  # Looks for 2 lines of tot values as 16 pixels are arranged in 2x8 matrix
    global hits
    global merged_hits
    global stream
    
    if line[:4] == "Ccol":
        countTemp   = 0
        columnAddress.append('{0:06b}'.format(int(line[6:-2])))

    elif line[:4] == "Qrow":
        countTemp   = 0
        rowAddress.append('{0:08b}'.format(int(line[6:-2])))

    elif line[0] != "T":
        countTemp   = 0
        pixelValue  = []
        hits        = []
        merged_hits = []

    else:                               # Line begins with 'T'
        countTemp   = countTemp + 1
        perRowHits  = line.split(" ")    # there are 2 rows in a quarter row region
        pixelValue  = perRowHits[2:-1]        
        for i in range (len(pixelValue)):
            hits.append(int(pixelValue[i]))

    f.write(line)
        
    if countTemp == 2:
            MergeHitMap(hits)


#--------------------------------------------------------------------
# STREAM FORMER
#--------------------------------------------------------------------
def streamGenerator(nHits, nStream):
    stream = []
    
    for i in range (0 + (nHits*nStream),nHits*nStream + nHits):

        # First hit
        if i == (0 + (nHits*nStream)):
            isL = isLast(columnAddress[i],columnAddress[i+1])   # Compare current column against next column
            isN = 0
            isLast_previous = isL
            stream.append('00111000')   # Not Blank Tag
            stream.extend((columnAddress[i], str(isL), str(isN), rowAddress[i]))
            stream.extend((compressedTree[i],totValues[i]))
            
        # Last hit
        elif i == nHits*nStream + nHits-1:
            isN = isNeighbour((int(rowAddress[i],2)),(int(rowAddress[i-1],2)))
            isLast_previous = isL
            
            if isLast_previous == 1 and isN == 0:
                stream.extend((columnAddress[i],str(1),str(isN),rowAddress[i]))
            elif isLast_previous == 1 and isN == 1:
                stream.extend((columnAddress[i],str(1),str(isN)))
            elif isLast_previous == 0 and isN == 0:
                stream.extend((str(1),str(isN),rowAddress[i]))
            else:
                stream.extend((str(1),str(isN)))

            stream.extend((compressedTree[i],totValues[i]))
        
        # All other hits
        else:     
            isLast_previous = isL
            isN = isNeighbour((int(rowAddress[i],2)),(int(rowAddress[i-1],2)))  # Compare row against previous row
            isL = isLast((int(columnAddress[i],2)),(int(columnAddress[i+1],2))) # Compare col against next col
            
            if isLast_previous == 0 and isN == 0:
                stream.extend((str(isL),str(isN),rowAddress[i]))
            elif isLast_previous == 0 and isN == 1:
                stream.extend((str(isL),str(isN)))
            elif isLast_previous == 1 and isN == 0:
                stream.extend((columnAddress[i],str(isL),str(isN),rowAddress[i]))
            else:
                stream.extend((columnAddress[i],str(isL),str(isN)))
    
            stream.extend((compressedTree[i],totValues[i]))


    streamString = "".join(stream)
    
    #-------------------------------------------------------------------
    # Frames are 64 bits of encoded data in an unknown length stream
    #-------------------------------------------------------------------
    frames = []

    for i in range (0, len(streamString),63):
        diff = 63-len(streamString[i:i+63])
        if i == 0:
            frames.append('1'+streamString[i:i+63] + '0'*diff + ',')
        else:            
            frames.append('0'+streamString[i:i+63] + '0'*diff + ',')
    
    #frames[-1] = frames[-1][:-1]
    #frames[-1] = frames[-1] + '}'

    for i in range (0,len(frames)):
        file.write(frames[i]+"\n")


#--------------------------------------------------------------------
# Generated the value of isNeighbour bit   
#--------------------------------------------------------------------
def isNeighbour(current_row,previous_row):
    #global isN
    if current_row == previous_row + 1:
        isN = 1
    else:
        isN = 0
    return isN 

#--------------------------------------------------------------------
# Generates the value of isLast bit       
#--------------------------------------------------------------------
def isLast(current_col,next_col):
    #global isL
    if current_col != next_col:
        isL = 1
    else:
        isL = 0
    return isL 

#--------------------------------------------------------------------
# Main
#--------------------------------------------------------------------
if __name__ == "__main__":
    # Ask user to use random or sequential
    randOrSeq = input("Sequential(1) or Random(2)?: ")


    # Ask user for number of streams
    noOfStreams = input("Enter the number of streams: ")
    nStreams = int(noOfStreams)

    # Ask user for the number of hits needed in an encoded stream
    noOfHits = input("Enter the number of hits: ") 
    nHits = int(noOfHits)
    
    # Create a file to hold the text list of hits 
    with open("randomHitDataREADME.txt", 'w') as f:
        for i in range (0, nStreams):
            mainBlock(nHits, randOrSeq)
    f.close()
    
    #----------------------------------------------------------------
    # Write the random data generated to an updated file in the following format:
    # Ccol: 22 
    # Qrow: 90 
    # Tot : 1 0 0 0 0 1 1 0 
    # Tot : 0 0 0 1 1 1 1 0
    #   Hit Map Encoded Tree:
    #                    11
    #            11              11
    #       10       01      11      11
    #   10     00  00   01 01   10 11   10
    # Each set of hit data is separated by a #--------------
    #----------------------------------------------------------------
    readFile = open("randomHitDataREADME.txt","r")
    
    with open("hitDataREADME.txt", "w") as f:
        #----------------------------------------------------------------
        # List function such as rowAddress holds all the values for the qrow address in serial order
        # therefore, rowAddress[0].value = 1st qrow address and so on.....
        # columnAddress holds column addresses
        # compressedTree holds the variable length tree encoded data
        # totValues holds the corresponding Time-over-Theshold values
        #----------------------------------------------------------------
        global rowAddress
        global columnAddress 
        global compressedTree
        global totValues
        global decHitmap
    
        rowAddress      = []
        columnAddress   = []
        compressedTree  = []
        totValues       = []
        decHitmap       = []
        
        for line in readFile:
            readGeneratedValues(line)

    readFile.close()
    f.close() 

    # Delete the initial README file as the hitDataREADME has the hit map tree as well
    os.remove("randomHitDataREADME.txt")

    #----------------------------------------------------------------
    #            STREAM GENERATION OPERATION      
    # Append all the data in a stream of continuous bits 
    #----------------------------------------------------------------
    with open("PythonGeneratedBinaryStream.txt", "w") as file:
        for i in range (0, nStreams):
            streamGenerator(nHits, i)
    file.close()

    #----------------------------------------------------------------
    #             DECODED STREAM FILE     
    # Add the decoded strings into a while
    #----------------------------------------------------------------
    with open("DecodedStreamData.txt", "w") as file:
        for i in range(0, len(rowAddress)):
            file.write('0'*(26) + '00111000' + columnAddress[i] + rowAddress[i] + decHitmap[i] + '1'*64 + ',' + '\n')
    file.close()
        
   