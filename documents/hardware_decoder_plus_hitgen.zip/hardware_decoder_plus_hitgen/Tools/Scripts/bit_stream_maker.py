
#def incr_bit_stream(start_col, start_qrow, num_frames):
    #currindex = 0
    #stream = 0
    #for i in range num_frames:

def stream_formatter(tag, ccol, islast, isneighbor, qrow, hitmap, tot, new_stream):
    if new_stream == 1:
        return tot + hitmap + qrow + isneighbor + islast + ccol + tag
    else:
        return tot + hitmap + qrow + isneighbor + islast + ccol

def stream_combiner(stream1, stream2):
    room_left = len(stream1)
    for i in range(63- room_left):
        if (len(stream2) != 0):
            stream1 = stream2[len(stream2) - 1] + stream1
            stream2 = stream2[:-1]
        else:
            stream1 = "0" + stream1

    return [stream1, stream2]

def stream_incr(tag, ccol, islast, isneighbor, qrow, hitmap, new_stream, num_streams):
    stream_list = []
    

# Normal frame
tag  = "11111110"
ccol = "000001"
islast = "1"
isneighbor = "0"
qrow = "00001111"
#Top left hit
hitmap = "01010101010111"
tot = "10011001"
####### empty frame setup
#tag  = "11111111"
#ccol = "000000"
#islast = "0"
#isneighbor = "0"
#qrow = "00000000"
#hitmap = "0000000000000000"
#tot = "0000000000000000"
stream1 = stream_formatter(tag, ccol, islast, isneighbor, qrow, hitmap, tot, 1)
print(stream1)
tag = "11111110"
ccol = "000011"
islast = "1"
isneighbor = "0"
qrow = "00011111"
# Top right hit
hitmap = "00000011"
tot = "00100100"
stream2 = stream_formatter(tag, ccol, islast, isneighbor, qrow, hitmap, tot, 0)
stream_list = stream_combiner(stream1, stream2)
#stream_list = stream_combiner(stream1, stream2)

last_index = len(stream_list) - 1
room_left = len(stream_list[last_index])

for i in range(64 - room_left):
    stream_list[last_index] = "0" + stream_list[last_index]


print(stream_list[0])
print(stream_list[1])