onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -expand -group Control /tb_hit_barrelshift/clk
add wave -noupdate -expand -group Control /tb_hit_barrelshift/reset
add wave -noupdate -expand -group Inputs /tb_hit_barrelshift/din
add wave -noupdate -expand -group Inputs -radix unsigned /tb_hit_barrelshift/din_shift
add wave -noupdate -expand -group Inputs /tb_hit_barrelshift/din_eos
add wave -noupdate -expand -group Inputs /tb_hit_barrelshift/din_eoe
add wave -noupdate -expand -group Inputs /tb_hit_barrelshift/din_ptr
add wave -noupdate -expand -group Inputs /tb_hit_barrelshift/din_dv
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum1
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum2
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum3
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum4
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum5
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum6
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum7
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/reg_accum8
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift1
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift2
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift3
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift4
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift5
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift6
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift7
add wave -noupdate -expand -group Internals -radix unsigned /tb_hit_barrelshift/dut/shift8
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift1
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift2
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift3
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift4
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift5
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift6
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift7
add wave -noupdate -expand -group Internals /tb_hit_barrelshift/dut/rem_shift8
add wave -noupdate -expand -group Outputs /tb_hit_barrelshift/dout
add wave -noupdate -expand -group Outputs /tb_hit_barrelshift/dout_eos
add wave -noupdate -expand -group Outputs /tb_hit_barrelshift/dout_eoe
add wave -noupdate -expand -group Outputs /tb_hit_barrelshift/dout_ptr
add wave -noupdate -expand -group Outputs /tb_hit_barrelshift/dout_dv
add wave -noupdate /tb_hit_barrelshift/sim_done
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {1445000 ps} 0} {{Cursor 2} {0 ps} 0}
quietly wave cursor active 2
configure wave -namecolwidth 150
configure wave -valuecolwidth 978
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {5607 ns}
