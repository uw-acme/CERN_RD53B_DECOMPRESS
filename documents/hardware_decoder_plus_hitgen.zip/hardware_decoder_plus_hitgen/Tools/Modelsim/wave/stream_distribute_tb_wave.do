onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /stream_distribute_tb/clk_i
add wave -noupdate /stream_distribute_tb/data_raw_i
add wave -noupdate -radix binary /stream_distribute_tb/end_of_stream_o
add wave -noupdate -radix binary /stream_distribute_tb/ready_engine_i
add wave -noupdate /stream_distribute_tb/ready_raw_o
add wave -noupdate /stream_distribute_tb/rst_i
add wave -noupdate /stream_distribute_tb/valid_raw_i
add wave -noupdate -radix binary /stream_distribute_tb/valid_stream_o
add wave -noupdate /stream_distribute_tb/data_stream_o
add wave -noupdate /stream_distribute_tb/dut/new_stream
add wave -noupdate /stream_distribute_tb/dut/start_up_flag
add wave -noupdate /stream_distribute_tb/dut/raw_data_fifo_counter
add wave -noupdate /stream_distribute_tb/dut/rd_raw_data_fifo
add wave -noupdate /stream_distribute_tb/dut/rd_raw_data_fifo_reg
add wave -noupdate /stream_distribute_tb/dut/ready_raw_data_fifo
add wave -noupdate /stream_distribute_tb/dut/empty_raw_data_fifo
add wave -noupdate /stream_distribute_tb/dut/active_engine
add wave -noupdate /stream_distribute_tb/dut/active_engine_reg
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {7932 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 161
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {0 ps} {17886 ps}
