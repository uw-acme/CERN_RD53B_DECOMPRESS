onerror {resume}
quietly virtual signal -install /tb_encode_decode_top/dut { (context /tb_encode_decode_top/dut )&{GPIO_DIP_SW0 , GPIO_DIP_SW1 , GPIO_DIP_SW2 , GPIO_DIP_SW3 }} dip_switches
quietly virtual function -install /tb_encode_decode_top/dut -env /tb_encode_decode_top/dut { &{/tb_encode_decode_top/dut/GPIO_LED_0_LS, /tb_encode_decode_top/dut/GPIO_LED_1_LS, /tb_encode_decode_top/dut/GPIO_LED_2_LS, /tb_encode_decode_top/dut/GPIO_LED_3_LS, /tb_encode_decode_top/dut/GPIO_LED_4_LS, /tb_encode_decode_top/dut/GPIO_LED_5_LS, /tb_encode_decode_top/dut/GPIO_LED_6_LS, /tb_encode_decode_top/dut/GPIO_LED_7_LS }} leds
quietly virtual function -install /tb_encode_decode_top/dut -env /tb_encode_decode_top/dut { (concat_ascending)&{/tb_encode_decode_top/dut/GPIO_LED_0_LS, /tb_encode_decode_top/dut/GPIO_LED_1_LS, /tb_encode_decode_top/dut/GPIO_LED_2_LS, /tb_encode_decode_top/dut/GPIO_LED_3_LS, /tb_encode_decode_top/dut/GPIO_LED_4_LS, /tb_encode_decode_top/dut/GPIO_LED_5_LS, /tb_encode_decode_top/dut/GPIO_LED_6_LS, /tb_encode_decode_top/dut/GPIO_LED_7_LS }} leds001
quietly virtual signal -install /tb_encode_decode_top/dut { (concat_range (0 to 3) )( (context /tb_encode_decode_top/dut )&{GPIO_DIP_SW0 , GPIO_DIP_SW1 , GPIO_DIP_SW2 , GPIO_DIP_SW3 } )} dip
quietly virtual signal -install /tb_encode_decode_top/dut { (concat_range (0 to 3) )( (context /tb_encode_decode_top/dut )&{GPIO_DIP_SW3 , GPIO_DIP_SW2 , GPIO_DIP_SW1 , GPIO_DIP_SW0 } )} dip001
quietly WaveActivateNextPane {} 0
add wave -noupdate -radix binary /tb_encode_decode_top/SYSCLK_P
add wave -noupdate -radix binary /tb_encode_decode_top/SYSCLK_N
add wave -noupdate /tb_encode_decode_top/CPU_RESET
add wave -noupdate -radix binary /tb_encode_decode_top/dut/u_clkreset/clk
add wave -noupdate /tb_encode_decode_top/dut/clkreset_lock
add wave -noupdate -group Top_Level -radix binary -childformat {{{/tb_encode_decode_top/dut/dip001[0]} -radix binary} {{/tb_encode_decode_top/dut/dip001[1]} -radix binary} {{/tb_encode_decode_top/dut/dip001[2]} -radix binary} {{/tb_encode_decode_top/dut/dip001[3]} -radix binary}} -subitemconfig {/tb_encode_decode_top/dut/GPIO_DIP_SW3 {-radix binary} /tb_encode_decode_top/dut/GPIO_DIP_SW2 {-radix binary} /tb_encode_decode_top/dut/GPIO_DIP_SW1 {-radix binary} /tb_encode_decode_top/dut/GPIO_DIP_SW0 {-radix binary}} /tb_encode_decode_top/dut/dip001
add wave -noupdate -group Top_Level -radix binary -childformat {{(0) -radix binary} {(1) -radix binary} {(2) -radix binary} {(3) -radix binary} {(4) -radix binary} {(5) -radix binary} {(6) -radix binary} {(7) -radix binary}} -subitemconfig {/tb_encode_decode_top/dut/GPIO_LED_0_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_1_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_2_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_3_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_4_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_5_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_6_LS {-radix binary} /tb_encode_decode_top/dut/GPIO_LED_7_LS {-radix binary}} /tb_encode_decode_top/dut/leds001
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch1 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[0]/u_debounce/sw_in}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch1 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[0]/u_debounce/sw_out}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch2 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[1]/u_debounce/sw_in}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch2 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[1]/u_debounce/sw_out}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch3 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[2]/u_debounce/sw_in}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch3 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[2]/u_debounce/sw_out}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch4 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[3]/u_debounce/sw_in}
add wave -noupdate -group Top_Level -expand -group Dip_Switches -expand -group Switch4 {/tb_encode_decode_top/dut/u_set_stream_size/dip_switches[3]/u_debounce/sw_out}
add wave -noupdate -group Top_Level -expand -group Start_Signal -radix binary /tb_encode_decode_top/GPIO_SW_S
add wave -noupdate -group Top_Level -expand -group Start_Signal /tb_encode_decode_top/dut/start
add wave -noupdate -group Top_Level -expand -group Start_Signal /tb_encode_decode_top/dut/u_debounce/short_shifted
add wave -noupdate -group Top_Level -expand -group Start_Signal -radix binary /tb_encode_decode_top/dut/u_debounce/short_shift
add wave -noupdate -group Top_Level -expand -group Start_Signal /tb_encode_decode_top/dut/u_debounce/cnt_max
add wave -noupdate -group Top_Level -expand -group Start_Signal /tb_encode_decode_top/dut/u_debounce/cnt_stable
add wave -noupdate /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/clk
add wave -noupdate -group hit_decode_top -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/din
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/din_dv
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/ready
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/decoder_ready
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_ccol
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_dv
add wave -noupdate -group hit_decode_top -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_hitmap
add wave -noupdate -group hit_decode_top -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_qrow
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_tag
add wave -noupdate -group hit_decode_top /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_tot
add wave -noupdate -group Staging_hit -expand -group event_gen /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_event_gen/ready
add wave -noupdate -group Staging_hit -expand -group event_gen /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_event_gen/state_wr
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_event_gen/dout_dv
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_event_gen/dout_hit_ccol
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_event_gen/dout_hit_hitmap
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_event_gen/dout_hit_qrow
add wave -noupdate -group Staging_hit -group Hit_Addr /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_addr/dout_dv
add wave -noupdate -group Staging_hit -group Hit_Addr -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_addr/dout_size
add wave -noupdate -group Staging_hit -group Hit_Addr -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_addr/dout
add wave -noupdate -group Staging_hit -expand -group hit_encode -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_encode/dout
add wave -noupdate -group Staging_hit -expand -group hit_encode /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_encode/dout_dv
add wave -noupdate -group Staging_hit -expand -group hit_encode -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_encode/dout_size
add wave -noupdate -group Staging_hit -group Hit_tots /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_tots/dout
add wave -noupdate -group Staging_hit -group Hit_tots /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_tots/dout_dv
add wave -noupdate -group Staging_hit -group Hit_tots /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_tots/dout_size
add wave -noupdate -group Staging_hit -expand -group Back_pressure /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/ready_raw_o
add wave -noupdate -group Staging_hit -expand -group Back_pressure /tb_encode_decode_top/dut/u_test_encode_decode/comb_ready
add wave -noupdate -group Staging_hit -expand -group Back_pressure /tb_encode_decode_top/dut/u_test_encode_decode/checker_ready
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_dv
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_addr
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_addr_size
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_hitmap
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_hitmap_size
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_tots
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/din_tots_size
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_outputs -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/dout
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_outputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/dout_dv
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_outputs -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_packer/dout_size
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/din
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/din_dv
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/din_size
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/ready_in
add wave -noupdate -group Hit_Assembler -group Hit_Assembler_out -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/dout
add wave -noupdate -group Hit_Assembler -group Hit_Assembler_out /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/dout_dv
add wave -noupdate -group Hit_Assembler -group Hit_Assembler_out /tb_encode_decode_top/dut/u_test_encode_decode/u_hitmaker/u_hit_assembler/ready_out
add wave -noupdate -group tb_level_connect /tb_encode_decode_top/dut/u_test_encode_decode/hitmaker_dout_dv
add wave -noupdate -group decode_engine_0_out_fifo {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decoded_data_fifo_i}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/wr_decode_fifo}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/rd_decode_fifo}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/ready_decode_data_i}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decoded_data_o}
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_dv_d1
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_ccol_d1
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/exp_ccol
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/exp_qrow
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_qrow_d1
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/exp_hitmap
add wave -noupdate -group hit_checker -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_hitmap_d1
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/exp_tot
add wave -noupdate -group hit_checker /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_tot_d1
add wave -noupdate -group decode_engine_0 -expand -group state_machine {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/data_consume_state}
add wave -noupdate -group decode_engine_0 -expand -group state_machine {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/data_consume_state_n}
add wave -noupdate -group decode_engine_0 -expand -group state_machine -radix unsigned {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/stream_ptr}
add wave -noupdate -group decode_engine_0 -expand -group state_machine -radix unsigned {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/stream_ptr_reg}
add wave -noupdate -group decode_engine_0 -expand -group state_machine {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/shifted_stream}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix binary {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/total_hitmap_reg}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix binary {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/total_hitmap_shifted}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/addr_reg}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/sec_row_flag}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/first_row_flag}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix unsigned {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/first_row_rollback}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix unsigned {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/sec_row_rollback}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/wr_stream_fifo}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/fifo_stream_prog_full_o}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/stream_fifo_counter}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/rd_stream_fifo}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decode_data_valid_o}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data -radix binary {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decoded_hitmap}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data -radix unsigned {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/qrow_reg}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/tag_reg}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/tot_reg}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/ccol_reg}
add wave -noupdate -group decode_engine_0 -group engine_offset {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/engine_stall}
add wave -noupdate -group decode_engine_0 -group engine_offset {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/engine_offset}
add wave -noupdate -group decode_engine_0 -group engine_offset {/tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/engine_stall_reset}
add wave -noupdate -group decode_engine_0_outputs -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_tag
add wave -noupdate -group decode_engine_0_outputs -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_ccol
add wave -noupdate -group decode_engine_0_outputs -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_qrow
add wave -noupdate -group decode_engine_0_outputs -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_hitmap
add wave -noupdate -group decode_engine_0_outputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_tot
add wave -noupdate -group decode_engine_0_outputs /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/dout_dv
add wave -noupdate -expand -group Hit_checker -expand -group exp_data -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fout_exp_ccol
add wave -noupdate -expand -group Hit_checker -expand -group exp_data -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fout_exp_qrow
add wave -noupdate -expand -group Hit_checker -expand -group exp_data /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fout_exp_hitmap
add wave -noupdate -expand -group Hit_checker -expand -group exp_data /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/ftot_dout
add wave -noupdate -expand -group Hit_checker -expand -group exp_data /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/ftot_size_dout
add wave -noupdate -expand -group Hit_checker -expand -group act_data /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_dv_d1
add wave -noupdate -expand -group Hit_checker -expand -group act_data -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_ccol_d1
add wave -noupdate -expand -group Hit_checker -expand -group act_data -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_qrow_d1
add wave -noupdate -expand -group Hit_checker -expand -group act_data -radix hexadecimal /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_hitmap_d1
add wave -noupdate -expand -group Hit_checker -expand -group act_data /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_tot_d1
add wave -noupdate -expand -group Hit_checker -expand -group act_data /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/act_tag_d1
add wave -noupdate -expand -group Hit_checker -expand -group Error_flags /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/err_ccol
add wave -noupdate -expand -group Hit_checker -expand -group Error_flags /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/err_hitmap
add wave -noupdate -expand -group Hit_checker -expand -group Error_flags /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/err_qrow
add wave -noupdate -expand -group Hit_checker -expand -group Error_flags /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/err_tag
add wave -noupdate -expand -group Hit_checker -expand -group Error_flags /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/err_tot
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fexp_full
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fexp_din
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fexp_wr
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fexp_overflow
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls -radix unsigned /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fexp_level
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/fexp_rd
add wave -noupdate -expand -group Hit_checker -expand -group exp_fifo_controls /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_checker/ready_check_o
add wave -noupdate -group stream_distb -expand -group distb_input -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/data_raw_i
add wave -noupdate -group stream_distb -expand -group distb_input /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/valid_raw_i
add wave -noupdate -group stream_distb -expand -group distb_output /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/valid_stream_o
add wave -noupdate -group stream_distb -expand -group distb_output /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/end_of_stream_o
add wave -noupdate -group stream_distb -expand -group distb_output -radix binary /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/data_stream_o
add wave -noupdate -group stream_distb -expand -group distb_output /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/new_stream
add wave -noupdate -group stream_distb -expand -group intermediate /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/data_o_raw_fifo
add wave -noupdate -group stream_distb -expand -group intermediate /tb_encode_decode_top/dut/u_test_encode_decode/u_hit_decoder/u_decode_top/u_stream_distribute/raw_data_fifo_counter
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {335011 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 209
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ms
update
WaveRestoreZoom {0 ps} {811258 ps}
