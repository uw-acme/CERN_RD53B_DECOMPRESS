onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -radix binary /tb_set_stream_size/dut/clk
add wave -noupdate -radix binary /tb_set_stream_size/dut/reset
add wave -noupdate -radix binary -childformat {{{/tb_set_stream_size/dut/switches[3]} -radix binary} {{/tb_set_stream_size/dut/switches[2]} -radix binary} {{/tb_set_stream_size/dut/switches[1]} -radix binary} {{/tb_set_stream_size/dut/switches[0]} -radix binary}} -subitemconfig {{/tb_set_stream_size/dut/switches[3]} {-height 15 -radix binary} {/tb_set_stream_size/dut/switches[2]} {-height 15 -radix binary} {/tb_set_stream_size/dut/switches[1]} {-height 15 -radix binary} {/tb_set_stream_size/dut/switches[0]} {-height 15 -radix binary}} /tb_set_stream_size/dut/switches
add wave -noupdate -expand -group debounce -radix binary {/tb_set_stream_size/dut/dip_switches[0]/u_debounce/sw_in}
add wave -noupdate -expand -group debounce -radix binary {/tb_set_stream_size/dut/dip_switches[0]/u_debounce/sw_out}
add wave -noupdate -expand -group debounce -radix binary {/tb_set_stream_size/dut/dip_switches[0]/u_debounce/short_shift}
add wave -noupdate -expand -group debounce -radix binary {/tb_set_stream_size/dut/dip_switches[0]/u_debounce/short_shifted}
add wave -noupdate -expand -group debounce -radix binary {/tb_set_stream_size/dut/dip_switches[0]/u_debounce/cnt_max}
add wave -noupdate -expand -group debounce -radix binary {/tb_set_stream_size/dut/dip_switches[0]/u_debounce/idle}
add wave -noupdate -radix binary -childformat {{{/tb_set_stream_size/dut/switches_debounced[3]} -radix binary} {{/tb_set_stream_size/dut/switches_debounced[2]} -radix binary} {{/tb_set_stream_size/dut/switches_debounced[1]} -radix binary} {{/tb_set_stream_size/dut/switches_debounced[0]} -radix binary}} -subitemconfig {{/tb_set_stream_size/dut/switches_debounced[3]} {-height 15 -radix binary} {/tb_set_stream_size/dut/switches_debounced[2]} {-height 15 -radix binary} {/tb_set_stream_size/dut/switches_debounced[1]} {-height 15 -radix binary} {/tb_set_stream_size/dut/switches_debounced[0]} {-height 15 -radix binary}} /tb_set_stream_size/dut/switches_debounced
add wave -noupdate /tb_set_stream_size/hits_per_stream
add wave -noupdate /tb_set_stream_size/dut/random_32bit
add wave -noupdate /tb_set_stream_size/dut/random_16bit
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {12107110 ns} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {10925795 ns} {13288425 ns}
