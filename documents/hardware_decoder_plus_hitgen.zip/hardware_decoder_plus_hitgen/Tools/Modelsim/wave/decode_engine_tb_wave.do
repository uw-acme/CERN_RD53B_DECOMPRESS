onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -expand -group Inputs /decode_engine_tb/data_stream_i
add wave -noupdate -expand -group Outputs /decode_engine_tb/dut/data_stream_o
add wave -noupdate /decode_engine_tb/dut/ready_engine_o
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/clk
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/din
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/dout
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/empty
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/full
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/rd_en
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/srst
add wave -noupdate -expand -group data_stream_fifo /decode_engine_tb/dut/u_fifo_stream_data/wr_en
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/clk
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/din
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/dout
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/empty
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/full
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/rd_en
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/srst
add wave -noupdate -expand -group decode_fifo /decode_engine_tb/dut/u_fifo_decode_data/wr_en
add wave -noupdate -expand -group state_machine /decode_engine_tb/dut/stream_ptr
add wave -noupdate -expand -group state_machine /decode_engine_tb/dut/shifter_state
add wave -noupdate -expand -group state_machine /decode_engine_tb/dut/shifter_state_n
add wave -noupdate -expand -group state_machine /decode_engine_tb/dut/start_cosume
add wave -noupdate /decode_engine_tb/dut/shifted_stream
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/decoded_hitmap
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/tag_reg
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/tot_reg
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/ccol_reg
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/is_last_reg
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/qrow_reg
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/end_of_stream
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/end_of_stream_reg
add wave -noupdate -expand -group data_outputs /decode_engine_tb/dut/data_consume_state
add wave -noupdate /decode_engine_tb/dut/empty_event
add wave -noupdate /decode_engine_tb/dut/data_consume_state_n
add wave -noupdate /decode_engine_tb/dut/decoded_hitmap_row_one
add wave -noupdate /decode_engine_tb/dut/valid_decode_reg
add wave -noupdate /decode_engine_tb/dut/decoded_data_ready
add wave -noupdate /decode_engine_tb/dut/first_row_rollback
add wave -noupdate /decode_engine_tb/dut/sec_row_rollback
add wave -noupdate /decode_engine_tb/dut/flipped_first_row
add wave -noupdate /decode_engine_tb/dut/flipped_sec_row
add wave -noupdate -expand -group fifo_counters /decode_engine_tb/dut/decode_fifo_counter
add wave -noupdate -expand -group fifo_counters /decode_engine_tb/dut/stream_fifo_counter
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {8500000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 197
configure wave -valuecolwidth 142
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {4406250 ps} {12283108 ps}
