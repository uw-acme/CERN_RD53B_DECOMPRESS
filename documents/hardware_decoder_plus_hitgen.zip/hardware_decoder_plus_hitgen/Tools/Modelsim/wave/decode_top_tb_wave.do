onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/CPU_RESET
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/GPIO_SW_N
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/GPIO_SW_S
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/GPIO_LED_0_LS
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/all_start
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/start
add wave -noupdate -expand -group Top_level_inputs /decode_top_tb/dut/stop
add wave -noupdate -expand -group clkreset /decode_top_tb/dut/u_clkreset/clk_in1_n
add wave -noupdate -expand -group clkreset /decode_top_tb/dut/u_clkreset/clk_in1_p
add wave -noupdate -expand -group clkreset /decode_top_tb/dut/u_clkreset/lock
add wave -noupdate -expand -group clkreset /decode_top_tb/dut/u_clkreset/reset
add wave -noupdate -expand -group clkreset /decode_top_tb/dut/u_clkreset/reset_in
add wave -noupdate -group Inputs /decode_top_tb/dut/clk_i
add wave -noupdate -group Inputs /decode_top_tb/dut/rst_i
add wave -noupdate -group Inputs /decode_top_tb/dut/address_counter
add wave -noupdate -group Inputs -radix binary /decode_top_tb/dut/data_raw_i
add wave -noupdate -group Inputs /decode_top_tb/dut/valid_raw_i
add wave -noupdate -group Arb_Inputs /decode_top_tb/dut/u_stream_distribute/clk_i
add wave -noupdate -group Arb_Inputs /decode_top_tb/dut/u_stream_distribute/data_raw_i
add wave -noupdate -group Arb_Inputs /decode_top_tb/dut/u_stream_distribute/valid_raw_i
add wave -noupdate -group Arb_outputs /decode_top_tb/dut/u_stream_distribute/raw_data_fifo_counter
add wave -noupdate -group Arb_outputs /decode_top_tb/dut/u_stream_distribute/ready_raw_o
add wave -noupdate -group Arb_outputs /decode_top_tb/dut/u_stream_distribute/valid_stream_o
add wave -noupdate -group Arb_outputs /decode_top_tb/dut/u_stream_distribute/data_stream_o
add wave -noupdate -group rom_dist -radix binary /decode_top_tb/dut/u_decode_rom_distribute/first_row_valid_i
add wave -noupdate -group rom_dist -radix binary /decode_top_tb/dut/u_decode_rom_distribute/sec_row_valid_i
add wave -noupdate -group rom_dist /decode_top_tb/dut/u_decode_rom_distribute/dec_first_rows_o
add wave -noupdate -group rom_dist /decode_top_tb/dut/u_decode_rom_distribute/dec_sec_rows_o
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/ccol_reg}
add wave -noupdate -group Data_signals -radix unsigned {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/stream_ptr}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/stream_ptr_reg}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/isneigh_status}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decoded_hitmap}
add wave -noupdate -group Data_signals -radix binary {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decoded_hitmap_row_one}
add wave -noupdate -group Data_signals -radix hexadecimal {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/shifted_stream}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decoded_hitmap_row_two}
add wave -noupdate -group Data_signals -radix unsigned {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/number_hits}
add wave -noupdate -group Data_signals -radix unsigned {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/number_hits_reg}
add wave -noupdate -group Data_signals -radix binary {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/total_hitmap_reg}
add wave -noupdate -group Data_signals -radix binary {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/total_hitmap_shifted}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/sec_row_rollback}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/tag_reg}
add wave -noupdate -group Data_signals {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/tot_reg}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/clk_i}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/engine_offset}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/data_consume_state}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/data_consume_state_n}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/data_stream_o}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decode_fifo_counter}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decoded_data_fifo_i}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decoded_data_o}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/decoded_data_ready}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/empty_decode}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/empty_stream_fifo}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/end_of_stream}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/end_trans_i}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/finished_process}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/first_row_rollback}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/is_last_reg}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/qrow_reg}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/rd_decode_fifo}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/rd_stream_fifo}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/ready_decode_data_i}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/ready_stream_o}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/rst_i}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/setup_data}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/setup_stream_counter}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/shift_possible}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/stream_fifo_counter}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/wr_decode_fifo}
add wave -noupdate -group Decode_Engine_0 {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/wr_stream_fifo}
add wave -noupdate -group engine_0_offset {/decode_top_tb/dut/decode_engines[0]/u_decode_engine/engine_offset}
add wave -noupdate -group Engine_1_offset {/decode_top_tb/dut/decode_engines[1]/u_decode_engine/engine_offset}
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/clk_i
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/ENGINE_NUM
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/NUM_STREAMS
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/NUM_HITS
add wave -noupdate -group test_block_1_inputs -radix binary /decode_top_tb/dut/u_test_block_1/address_counter
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/new_stream_i
add wave -noupdate -group test_block_1_inputs -radix binary /decode_top_tb/dut/u_test_block_1/request_streams_valid
add wave -noupdate -group test_block_1_inputs -radix binary /decode_top_tb/dut/u_test_block_1/request_streams
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/data_setup_counter
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/check_data
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/check_data_valid
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/fill_fifo_state
add wave -noupdate -group test_block_1_inputs /decode_top_tb/dut/u_test_block_1/fill_fifo_state_n
add wave -noupdate -group test_block_1_outputs /decode_top_tb/dut/u_test_block_1/clk_i
add wave -noupdate -group test_block_1_outputs /decode_top_tb/dut/u_test_block_1/check_fifo_ready_o
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {17225304196196 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 216
configure wave -valuecolwidth 273
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {17225304196196 ps} {17225317006523 ps}
