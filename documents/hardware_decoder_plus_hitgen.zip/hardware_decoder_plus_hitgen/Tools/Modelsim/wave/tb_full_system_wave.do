onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb_test_encode_decode/dut/u_hit_decoder/clk
add wave -noupdate -group hit_decode_top -radix binary /tb_test_encode_decode/dut/u_hit_decoder/din
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/u_hit_decoder/din_dv
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/u_hit_decoder/ready
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/decoder_ready
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/u_hit_decoder/dout_ccol
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/u_hit_decoder/dout_dv
add wave -noupdate -group hit_decode_top -radix binary /tb_test_encode_decode/dut/u_hit_decoder/dout_hitmap
add wave -noupdate -group hit_decode_top -radix binary /tb_test_encode_decode/dut/u_hit_decoder/dout_qrow
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/u_hit_decoder/dout_tag
add wave -noupdate -group hit_decode_top /tb_test_encode_decode/dut/u_hit_decoder/dout_tot
add wave -noupdate -group Staging_hit -expand -group event_gen /tb_test_encode_decode/dut/u_hitmaker/u_event_gen/ready
add wave -noupdate -group Staging_hit -expand -group event_gen /tb_test_encode_decode/dut/u_hitmaker/u_event_gen/state_wr
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out /tb_test_encode_decode/dut/u_hitmaker/u_event_gen/dout_dv
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out /tb_test_encode_decode/dut/u_hitmaker/u_event_gen/dout_hit_ccol
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out -radix binary /tb_test_encode_decode/dut/u_hitmaker/u_event_gen/dout_hit_hitmap
add wave -noupdate -group Staging_hit -expand -group event_gen -expand -group event_gen_out /tb_test_encode_decode/dut/u_hitmaker/u_event_gen/dout_hit_qrow
add wave -noupdate -group Staging_hit -group Hit_Addr /tb_test_encode_decode/dut/u_hitmaker/u_hit_addr/dout_dv
add wave -noupdate -group Staging_hit -group Hit_Addr -radix unsigned /tb_test_encode_decode/dut/u_hitmaker/u_hit_addr/dout_size
add wave -noupdate -group Staging_hit -group Hit_Addr -radix binary /tb_test_encode_decode/dut/u_hitmaker/u_hit_addr/dout
add wave -noupdate -group Staging_hit -expand -group hit_encode -radix binary /tb_test_encode_decode/dut/u_hitmaker/u_hit_encode/dout
add wave -noupdate -group Staging_hit -expand -group hit_encode /tb_test_encode_decode/dut/u_hitmaker/u_hit_encode/dout_dv
add wave -noupdate -group Staging_hit -expand -group hit_encode -radix unsigned /tb_test_encode_decode/dut/u_hitmaker/u_hit_encode/dout_size
add wave -noupdate -group Staging_hit -group Hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/dout
add wave -noupdate -group Staging_hit -group Hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/dout_dv
add wave -noupdate -group Staging_hit -group Hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/dout_size
add wave -noupdate -group Staging_hit -expand -group Back_pressure /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/ready_raw_o
add wave -noupdate -group Staging_hit -expand -group Back_pressure /tb_test_encode_decode/dut/comb_ready
add wave -noupdate -group Staging_hit -expand -group Back_pressure /tb_test_encode_decode/dut/checker_ready
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_dv
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_addr
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_addr_size
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs -radix binary /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_hitmap
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_hitmap_size
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_tots
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_inputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/din_tots_size
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_outputs -radix binary /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/dout
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_outputs /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/dout_dv
add wave -noupdate -group Hit_Packer -expand -group Hit_packer_outputs -radix unsigned /tb_test_encode_decode/dut/u_hitmaker/u_hit_packer/dout_size
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/din
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/din_dv
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/din_size
add wave -noupdate -group Hit_Assembler -expand -group hit_assembler_in /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/ready_in
add wave -noupdate -group Hit_Assembler -group Hit_Assembler_out -radix binary /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/dout
add wave -noupdate -group Hit_Assembler -group Hit_Assembler_out /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/dout_dv
add wave -noupdate -group Hit_Assembler -group Hit_Assembler_out /tb_test_encode_decode/dut/u_hitmaker/u_hit_assembler/ready_out
add wave -noupdate -group tb_level_connect /tb_test_encode_decode/dut/hitmaker_dout_dv
add wave -noupdate -group decode_engine_0_out_fifo {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decoded_data_fifo_i}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/wr_decode_fifo}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/rd_decode_fifo}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/ready_decode_data_i}
add wave -noupdate -group decode_engine_0_out_fifo {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decoded_data_o}
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/act_dv_d1
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/act_ccol_d1
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/exp_ccol
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/exp_qrow
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/act_qrow_d1
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/exp_hitmap
add wave -noupdate -group hit_checker -radix binary /tb_test_encode_decode/dut/u_hit_checker/act_hitmap_d1
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/exp_tot
add wave -noupdate -group hit_checker /tb_test_encode_decode/dut/u_hit_checker/act_tot_d1
add wave -noupdate -group decode_engine_0 -expand -group state_machine {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/data_consume_state}
add wave -noupdate -group decode_engine_0 -expand -group state_machine {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/data_consume_state_n}
add wave -noupdate -group decode_engine_0 -expand -group state_machine -radix unsigned {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/stream_ptr}
add wave -noupdate -group decode_engine_0 -expand -group state_machine -radix unsigned {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/stream_ptr_reg}
add wave -noupdate -group decode_engine_0 -expand -group state_machine {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/shifted_stream}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix binary {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/total_hitmap_reg}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix binary {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/total_hitmap_shifted}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/addr_reg}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/sec_row_flag}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/first_row_flag}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix unsigned {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/first_row_rollback}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals -radix unsigned {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/sec_row_rollback}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/wr_stream_fifo}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/fifo_stream_prog_full_o}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/stream_fifo_counter}
add wave -noupdate -group decode_engine_0 -expand -group Control_signals {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/rd_stream_fifo}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decode_data_valid_o}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data -radix binary {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/decoded_hitmap}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data -radix unsigned {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/qrow_reg}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/tag_reg}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/tot_reg}
add wave -noupdate -group decode_engine_0 -expand -group intermediate_data {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/ccol_reg}
add wave -noupdate -group decode_engine_0 -group engine_offset {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/engine_stall}
add wave -noupdate -group decode_engine_0 -group engine_offset {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/engine_offset}
add wave -noupdate -group decode_engine_0 -group engine_offset {/tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/decode_engines[0]/u_decode_engine/engine_stall_reset}
add wave -noupdate -group decode_engine_0_outputs -radix binary /tb_test_encode_decode/dut/u_hit_decoder/dout_tag
add wave -noupdate -group decode_engine_0_outputs -radix unsigned /tb_test_encode_decode/dut/u_hit_decoder/dout_ccol
add wave -noupdate -group decode_engine_0_outputs -radix unsigned /tb_test_encode_decode/dut/u_hit_decoder/dout_qrow
add wave -noupdate -group decode_engine_0_outputs -radix binary /tb_test_encode_decode/dut/u_hit_decoder/dout_hitmap
add wave -noupdate -group decode_engine_0_outputs /tb_test_encode_decode/dut/u_hit_decoder/dout_tot
add wave -noupdate -group decode_engine_0_outputs /tb_test_encode_decode/dut/u_hit_decoder/dout_dv
add wave -noupdate -group Hit_checker -expand -group exp_data -radix unsigned /tb_test_encode_decode/dut/u_hit_checker/fout_exp_ccol
add wave -noupdate -group Hit_checker -expand -group exp_data -radix unsigned /tb_test_encode_decode/dut/u_hit_checker/fout_exp_qrow
add wave -noupdate -group Hit_checker -expand -group exp_data /tb_test_encode_decode/dut/u_hit_checker/fout_exp_hitmap
add wave -noupdate -group Hit_checker -expand -group exp_data /tb_test_encode_decode/dut/u_hit_checker/fout_exp_tot
add wave -noupdate -group Hit_checker -expand -group act_data /tb_test_encode_decode/dut/u_hit_checker/act_dv_d1
add wave -noupdate -group Hit_checker -expand -group act_data -radix unsigned /tb_test_encode_decode/dut/u_hit_checker/act_ccol_d1
add wave -noupdate -group Hit_checker -expand -group act_data -radix unsigned /tb_test_encode_decode/dut/u_hit_checker/act_qrow_d1
add wave -noupdate -group Hit_checker -expand -group act_data -radix hexadecimal /tb_test_encode_decode/dut/u_hit_checker/act_hitmap_d1
add wave -noupdate -group Hit_checker -expand -group act_data /tb_test_encode_decode/dut/u_hit_checker/act_tot_d1
add wave -noupdate -group Hit_checker -expand -group act_data /tb_test_encode_decode/dut/u_hit_checker/act_tag_d1
add wave -noupdate -group Hit_checker -expand -group Error_flags /tb_test_encode_decode/dut/u_hit_checker/err_ccol
add wave -noupdate -group Hit_checker -expand -group Error_flags /tb_test_encode_decode/dut/u_hit_checker/err_hitmap
add wave -noupdate -group Hit_checker -expand -group Error_flags /tb_test_encode_decode/dut/u_hit_checker/err_qrow
add wave -noupdate -group Hit_checker -expand -group Error_flags /tb_test_encode_decode/dut/u_hit_checker/err_tag
add wave -noupdate -group Hit_checker -expand -group Error_flags /tb_test_encode_decode/dut/u_hit_checker/err_tot
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls /tb_test_encode_decode/dut/u_hit_checker/fexp_full
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls /tb_test_encode_decode/dut/u_hit_checker/fexp_din
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls /tb_test_encode_decode/dut/u_hit_checker/fexp_wr
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls /tb_test_encode_decode/dut/u_hit_checker/fexp_overflow
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls -radix unsigned /tb_test_encode_decode/dut/u_hit_checker/fexp_level
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls /tb_test_encode_decode/dut/u_hit_checker/fexp_rd
add wave -noupdate -group Hit_checker -expand -group exp_fifo_controls /tb_test_encode_decode/dut/u_hit_checker/ready_check_o
add wave -noupdate -expand -group stream_distb -expand -group distb_input -radix binary /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/data_raw_i
add wave -noupdate -expand -group stream_distb -expand -group distb_input /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/valid_raw_i
add wave -noupdate -expand -group stream_distb -expand -group distb_output /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/valid_stream_o
add wave -noupdate -expand -group stream_distb -expand -group distb_output /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/end_of_stream_o
add wave -noupdate -expand -group stream_distb -expand -group distb_output -radix binary /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/data_stream_o
add wave -noupdate -expand -group stream_distb -expand -group distb_output /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/new_stream
add wave -noupdate -expand -group stream_distb -expand -group intermediate /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/data_o_raw_fifo
add wave -noupdate -expand -group stream_distb -expand -group intermediate /tb_test_encode_decode/dut/u_hit_decoder/u_decode_top/u_stream_distribute/raw_data_fifo_counter
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {1957881366 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 317
configure wave -valuecolwidth 315
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {1957814854 ps} {1957937429 ps}
