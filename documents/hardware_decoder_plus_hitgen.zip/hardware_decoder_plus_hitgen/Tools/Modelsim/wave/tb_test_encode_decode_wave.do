onerror {resume}
quietly virtual function -install /tb_test_encode_decode/dut/u_hit_checker -env /tb_test_encode_decode/dut/u_hit_checker { &{/tb_test_encode_decode/dut/u_hit_checker/err_chip_id, /tb_test_encode_decode/dut/u_hit_checker/err_tag, /tb_test_encode_decode/dut/u_hit_checker/err_qrow, /tb_test_encode_decode/dut/u_hit_checker/err_ccol, /tb_test_encode_decode/dut/u_hit_checker/err_hitmap, /tb_test_encode_decode/dut/u_hit_checker/err_tot, /tb_test_encode_decode/dut/u_hit_checker/err_eos, /tb_test_encode_decode/dut/u_hit_checker/err_eoe }} errors
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb_test_encode_decode/clk
add wave -noupdate /tb_test_encode_decode/reset
add wave -noupdate /tb_test_encode_decode/start
add wave -noupdate /tb_test_encode_decode/ready
add wave -noupdate /tb_test_encode_decode/busy
add wave -noupdate -group parameters /tb_test_encode_decode/reg_mode_evgen
add wave -noupdate -group parameters /tb_test_encode_decode/reg_seed
add wave -noupdate -group parameters /tb_test_encode_decode/reg_hits_per_stream
add wave -noupdate -group parameters /tb_test_encode_decode/reg_lv_density
add wave -noupdate -group parameters /tb_test_encode_decode/reg_lv_maxlen
add wave -noupdate -group parameters /tb_test_encode_decode/reg_cl_density
add wave -noupdate -group parameters /tb_test_encode_decode/reg_cl_max
add wave -noupdate -group parameters /tb_test_encode_decode/reg_restart
add wave -noupdate -group parameters /tb_test_encode_decode/reg_en_encode
add wave -noupdate -group parameters /tb_test_encode_decode/reg_en_tot
add wave -noupdate -group parameters /tb_test_encode_decode/reg_mode_tot
add wave -noupdate -group parameters /tb_test_encode_decode/reg_tot_value
add wave -noupdate -group parameters /tb_test_encode_decode/reg_tag_init
add wave -noupdate -group parameters /tb_test_encode_decode/reg_chip_id
add wave -noupdate -group parameters /tb_test_encode_decode/reg_en_chip_id
add wave -noupdate -group parameters /tb_test_encode_decode/reg_en_eos
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/act_dv_d1
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_chip_id
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_tag
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_eos
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_eoe
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_qrow
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_ccol
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_hitmap
add wave -noupdate -expand -group decoder -radix binary /tb_test_encode_decode/decoder_tot
add wave -noupdate -expand -group decoder /tb_test_encode_decode/decoder_dv
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/u_hit_checker/tag_calc
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_eos
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_eoe
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_qrow
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_ccol
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_hitmap
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_dv
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_tot
add wave -noupdate -expand -group hitmaker /tb_test_encode_decode/dut/exp_hit_tot_dv
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/din
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/din_dv
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/dout
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/dout_size
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/dout_dv
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/ones
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/ones_d1
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/ones_d2
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/din_dv_d1
add wave -noupdate -expand -group hit_tots /tb_test_encode_decode/dut/u_hitmaker/u_hit_tots/din_dv_d2
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/ftot_rd
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/fout_exp_ccol
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/fout_exp_qrow
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/fout_exp_hitmap
add wave -noupdate -group fifo_tot1 /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot1/din
add wave -noupdate -group fifo_tot1 /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot1/wr_en
add wave -noupdate -group fifo_tot1 /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot1/rd_en
add wave -noupdate -group fifo_tot1 /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot1/dout
add wave -noupdate -group fifo_tot1 /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot1/data_count
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/ftot_dout
add wave -noupdate -group fifo_tot_size /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot_size/din
add wave -noupdate -group fifo_tot_size /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot_size/wr_en
add wave -noupdate -group fifo_tot_size /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot_size/rd_en
add wave -noupdate -group fifo_tot_size /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot_size/dout
add wave -noupdate -group fifo_tot_size /tb_test_encode_decode/dut/u_hit_checker/u_fifo_tot_size/data_count
add wave -noupdate -radix decimal /tb_test_encode_decode/dut/u_hit_checker/ftot_size_dout
add wave -noupdate -radix decimal /tb_test_encode_decode/dut/u_hit_checker/exp_tot_size
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/act_ccol_d1
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/act_qrow_d1
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/act_hitmap_d1
add wave -noupdate /tb_test_encode_decode/dut/u_hit_checker/act_tot_d1
add wave -noupdate -expand /tb_test_encode_decode/dut/u_hit_checker/errors
add wave -noupdate /tb_test_encode_decode/dout_errs
add wave -noupdate /tb_test_encode_decode/dout_err_dv
add wave -noupdate /tb_test_encode_decode/dout_err_count
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {355100 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 50
configure wave -gridperiod 100
configure wave -griddelta 2
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {1325824 ps}
