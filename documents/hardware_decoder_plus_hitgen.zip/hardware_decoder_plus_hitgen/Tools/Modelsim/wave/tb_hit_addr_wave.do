onerror {resume}
quietly virtual function -install /tb_hit_addr/u_hit_addr -env /tb_hit_addr { &{/tb_hit_addr/u_hit_addr/dout[15], /tb_hit_addr/u_hit_addr/dout[14], /tb_hit_addr/u_hit_addr/dout[13], /tb_hit_addr/u_hit_addr/dout[12], /tb_hit_addr/u_hit_addr/dout[11], /tb_hit_addr/u_hit_addr/dout[10] }} ff
quietly virtual function -install /tb_hit_addr/u_hit_addr -env /tb_hit_addr { &{/tb_hit_addr/u_hit_addr/dout[15], /tb_hit_addr/u_hit_addr/dout[14], /tb_hit_addr/u_hit_addr/dout[13], /tb_hit_addr/u_hit_addr/dout[12], /tb_hit_addr/u_hit_addr/dout[11], /tb_hit_addr/u_hit_addr/dout[10] }} b16_ccol
quietly virtual signal -install /tb_hit_addr/u_hit_addr {/tb_hit_addr/u_hit_addr/dout[9]  } b16_is_last
quietly virtual signal -install /tb_hit_addr/u_hit_addr {/tb_hit_addr/u_hit_addr/dout[8]  } b16_is_neighbor
quietly virtual function -install /tb_hit_addr/u_hit_addr -env /tb_hit_addr { &{/tb_hit_addr/u_hit_addr/dout[7], /tb_hit_addr/u_hit_addr/dout[6], /tb_hit_addr/u_hit_addr/dout[5], /tb_hit_addr/u_hit_addr/dout[4], /tb_hit_addr/u_hit_addr/dout[3], /tb_hit_addr/u_hit_addr/dout[2], /tb_hit_addr/u_hit_addr/dout[1], /tb_hit_addr/u_hit_addr/dout[0] }} b16_qrow
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb_hit_addr/u_hit_addr/clk
add wave -noupdate /tb_hit_addr/u_hit_addr/reset
add wave -noupdate -expand -group Inputs -radix unsigned /tb_hit_addr/u_hit_addr/din_ccol
add wave -noupdate -expand -group Inputs /tb_hit_addr/u_hit_addr/din_dv
add wave -noupdate -expand -group Inputs /tb_hit_addr/u_hit_addr/din_eos
add wave -noupdate -expand -group Inputs -radix unsigned /tb_hit_addr/u_hit_addr/din_qrow
add wave -noupdate -expand -group Outputs /tb_hit_addr/u_hit_addr/dout_dv
add wave -noupdate -expand -group Outputs /tb_hit_addr/u_hit_addr/dout
add wave -noupdate -expand -group Outputs /tb_hit_addr/u_hit_addr/dout_eos
add wave -noupdate -expand -group Outputs -radix unsigned /tb_hit_addr/u_hit_addr/dout_size
add wave -noupdate /tb_hit_addr/u_hit_addr/new_stream
add wave -noupdate -expand -group {Output Components} -expand -group {16-bit output format} -radix unsigned /tb_hit_addr/u_hit_addr/b16_ccol
add wave -noupdate -expand -group {Output Components} -expand -group {16-bit output format} /tb_hit_addr/u_hit_addr/b16_is_last
add wave -noupdate -expand -group {Output Components} -expand -group {16-bit output format} /tb_hit_addr/u_hit_addr/b16_is_neighbor
add wave -noupdate -expand -group {Output Components} -expand -group {16-bit output format} -radix unsigned /tb_hit_addr/u_hit_addr/b16_qrow
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {266108 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 192
configure wave -valuecolwidth 142
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 5000
configure wave -gridperiod 10000
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {133344 ps} {355586 ps}
