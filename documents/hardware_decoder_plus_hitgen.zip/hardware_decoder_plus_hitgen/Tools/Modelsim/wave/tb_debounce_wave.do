onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -radix binary /tb_debounce/clk
add wave -noupdate -radix binary /tb_debounce/reset
add wave -noupdate -radix binary /tb_debounce/sw_in
add wave -noupdate -radix binary /tb_debounce/dut/sw_msync0
add wave -noupdate -radix binary /tb_debounce/dut/sw_msync1
add wave -noupdate -radix binary /tb_debounce/dut/short_shift
add wave -noupdate -radix binary /tb_debounce/dut/short_shifted
add wave -noupdate -radix binary /tb_debounce/dut/cnt_stable
add wave -noupdate -radix binary /tb_debounce/dut/cnt_max
add wave -noupdate /tb_debounce/dut/idle
add wave -noupdate -radix binary /tb_debounce/sw_out
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {19753000000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {19752683998 ps} {19755216002 ps}
