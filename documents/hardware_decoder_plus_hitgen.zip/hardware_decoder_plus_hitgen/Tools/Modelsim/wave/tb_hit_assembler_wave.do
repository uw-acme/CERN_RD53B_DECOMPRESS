onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/clk
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/reset
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/restart
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/tag_init
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/chip_id
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/en_chip_id
add wave -noupdate -expand -group {Misc Inputs} /tb_hit_assembler/en_eos
add wave -noupdate -expand -group Input /tb_hit_assembler/din
add wave -noupdate -expand -group Input -radix unsigned /tb_hit_assembler/din_size
add wave -noupdate -expand -group Input /tb_hit_assembler/din_eos
add wave -noupdate -expand -group Input /tb_hit_assembler/din_eoe
add wave -noupdate -expand -group Input /tb_hit_assembler/din_dv
add wave -noupdate -expand -group Input /tb_hit_assembler/ready_out
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_din_packed
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_wr_en
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_rd_en
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_dout_packed
add wave -noupdate -expand -group {Input FIFO} -radix unsigned /tb_hit_assembler/dut/fin_dout_size
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_dout_eoe
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_dout_eos
add wave -noupdate -expand -group {Input FIFO} /tb_hit_assembler/dut/fin_dout
add wave -noupdate -expand -group {Input FIFO} -expand -group Status -radix unsigned /tb_hit_assembler/dut/fin_dlevel
add wave -noupdate -expand -group {Input FIFO} -expand -group Status /tb_hit_assembler/dut/fin_empty
add wave -noupdate -expand -group {Input FIFO} -expand -group Status /tb_hit_assembler/dut/fin_full
add wave -noupdate -expand -group {Input FIFO} -expand -group Status /tb_hit_assembler/dut/fin_not_empty
add wave -noupdate -expand -group {Input FIFO} -expand -group Status /tb_hit_assembler/dut/fin_overflow
add wave -noupdate -expand -group {Input FIFO} -expand -group Status /tb_hit_assembler/dut/fin_underflow
add wave -noupdate -expand -group {Input Storage} /tb_hit_assembler/dut/stored_din
add wave -noupdate -expand -group {Input Storage} /tb_hit_assembler/dut/stored_din_dv
add wave -noupdate -expand -group {Input Storage} /tb_hit_assembler/dut/stored_din_eoe
add wave -noupdate -expand -group {Input Storage} /tb_hit_assembler/dut/stored_din_eos
add wave -noupdate -expand -group {Input Storage} -radix unsigned /tb_hit_assembler/dut/stored_din_size
add wave -noupdate -expand -group {Decided Inputs} /tb_hit_assembler/dut/decided_din
add wave -noupdate -expand -group {Decided Inputs} /tb_hit_assembler/dut/decided_din_dv
add wave -noupdate -expand -group {Decided Inputs} -radix unsigned /tb_hit_assembler/dut/decided_din_size
add wave -noupdate /tb_hit_assembler/dut/n_stream_state
add wave -noupdate /tb_hit_assembler/dut/p_stream_state
add wave -noupdate -expand -group {Barrel Shift Inputs} /tb_hit_assembler/dut/bs_din
add wave -noupdate -expand -group {Barrel Shift Inputs} -radix unsigned /tb_hit_assembler/dut/bs_din_shift
add wave -noupdate -expand -group {Barrel Shift Inputs} /tb_hit_assembler/dut/bs_din_dv
add wave -noupdate -expand -group {Barrel Shift Inputs} -expand /tb_hit_assembler/dut/bs_din_ctrl
add wave -noupdate -group {Barrel Shift Internals} /tb_hit_assembler/dut/u_barrelshift/reg_accum1
add wave -noupdate -group {Barrel Shift Internals} {/tb_hit_assembler/dut/u_barrelshift/sreg_din_ctrl[1]}
add wave -noupdate -group {Barrel Shift Internals} /tb_hit_assembler/dut/u_barrelshift/reg_accum2
add wave -noupdate -group {Barrel Shift Internals} {/tb_hit_assembler/dut/u_barrelshift/sreg_din_ctrl[2]}
add wave -noupdate -group {Barrel Shift Internals} /tb_hit_assembler/dut/u_barrelshift/reg_accum3
add wave -noupdate -group {Barrel Shift Internals} {/tb_hit_assembler/dut/u_barrelshift/sreg_din_ctrl[3]}
add wave -noupdate -group {Barrel Shift Internals} /tb_hit_assembler/dut/u_barrelshift/reg_accum4
add wave -noupdate -group {Barrel Shift Internals} {/tb_hit_assembler/dut/u_barrelshift/sreg_din_ctrl[4]}
add wave -noupdate -expand -group {Barrel Shift Outputs} -radix hexadecimal /tb_hit_assembler/dut/bs_dout
add wave -noupdate -expand -group {Barrel Shift Outputs} /tb_hit_assembler/dut/bs_dout_dv
add wave -noupdate -expand -group {Barrel Shift Outputs} -expand /tb_hit_assembler/dut/bs_dout_ctrl
add wave -noupdate /tb_hit_assembler/dut/naccum
add wave -noupdate /tb_hit_assembler/dut/paccum
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_din
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_dlevel
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_dout
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_empty
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_full
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_overflow
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_rd_en
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_underflow
add wave -noupdate -expand -group {Output FIFO} /tb_hit_assembler/dut/fout_wr_en
add wave -noupdate -expand -group Output /tb_hit_assembler/ready_in
add wave -noupdate -expand -group Output /tb_hit_assembler/dout
add wave -noupdate -expand -group Output /tb_hit_assembler/dout_eos
add wave -noupdate -expand -group Output /tb_hit_assembler/dout_eoe
add wave -noupdate -expand -group Output /tb_hit_assembler/dout_dv
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {84212988 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 504
configure wave -justifyvalue left
configure wave -signalnamewidth 1
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 5000
configure wave -gridperiod 10000
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ns
update
WaveRestoreZoom {84212988 ps} {85434085 ps}
