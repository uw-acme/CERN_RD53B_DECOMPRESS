# One place to list everything in the design.

# Includes
vlog "../../Include/defines.txt"

# Sources
vlog "../../Src/*.sv"
vcom -2008 "../../Src/*.vhd"

# Testbenches
vlog "../../Testbench/*.sv"
vcom -2008 "../../Testbench/*.vhd"

# IP netlists (alphabetical order)
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/decoder_first_row_16x32/decoder_first_row_16x32_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/decoder_second_row_14x16/decoder_second_row_14x16_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/dpram_512x66b/dpram_512x66b_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/fifo_chk_512x32b/fifo_chk_512x32b_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/fifo_decode_data/fifo_decode_data_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/fifo_stream_checker/fifo_stream_checker_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/fifo_stream_data/fifo_stream_data_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/generated_stream_data_ROM/generated_stream_data_ROM_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/raw_data_fifo/raw_data_fifo_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/test_write_request_fifo/test_write_request_fifo_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/u_stream_data_decoded/u_stream_data_decoded_sim_netlist.vhdl"
vcom "../Vivado/Decoder_Engine.srcs/sources_1/ip/clkgen_200to160/clkgen_200to160_sim_netlist.vhdl"
