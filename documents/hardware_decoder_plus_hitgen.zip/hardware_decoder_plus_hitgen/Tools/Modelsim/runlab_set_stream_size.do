# Create work library
vlib work

# Compile Verilog
vlog "../../Src/debounce.sv"
vlog "../../Src/set_stream_size.sv"
vlog "../../Testbench/tb_set_stream_size.sv"

# Call vsim to invoke simulator
#     Make sure the last item on the line is the name of the
#     testbench module you want to execute.
vsim -voptargs="+acc" -t 1ns -lib work tb_set_stream_size



# Source the wave do file
#     This should be the file that sets up the signal window for
#     the module you are testing.
do wave/tb_set_stream_size_wave.do


# Set the window types
view wave
view structure
view signals

# Run the simulation
run -all

# End
