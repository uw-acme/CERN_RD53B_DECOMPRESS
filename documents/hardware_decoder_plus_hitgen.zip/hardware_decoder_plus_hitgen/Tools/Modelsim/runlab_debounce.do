# Create work library
vlib work

# Compile Verilog
vlog "../../Src/debounce.sv"
vlog "../../Testbench/tb_debounce.sv"

# Call vsim to invoke simulator
#     Make sure the last item on the line is the name of the
#     testbench module you want to execute.
vsim -voptargs="+acc" -t 1ps -lib work tb_debounce



# Source the wave do file
#     This should be the file that sets up the signal window for
#     the module you are testing.
do wave/tb_debounce_wave.do


# Set the window types
view wave
view structure
view signals

# Run the simulation
run -all

# End
