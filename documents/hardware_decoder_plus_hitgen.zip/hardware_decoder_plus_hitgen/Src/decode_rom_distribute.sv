module decode_rom_distribute #(ENGINE_NUM = 2) (
    input                          clk_i,
    input                          rst_i,
    input  [ENGINE_NUM-1:0] [13:0] first_rows_i,
    input  [ENGINE_NUM-1:0]        first_row_valid_i,
    input  [ENGINE_NUM-1:0] [13:0] sec_rows_i,
    input  [ENGINE_NUM-1:0]        sec_row_valid_i,
    output [ENGINE_NUM-1:0] [15:0] dec_first_rows_o,
    output [ENGINE_NUM-1:0] [15:0] dec_sec_rows_o
);


    logic [ENGINE_NUM - 1:0] first_row_select_a;
    logic [ENGINE_NUM - 1:0] first_row_select_b;
    logic [ENGINE_NUM - 1:0] sec_row_select_a;
    logic [ENGINE_NUM - 1:0] sec_row_select_b;

    logic [ENGINE_NUM - 1:0] first_row_select_a_reg;
    logic [ENGINE_NUM - 1:0] first_row_select_b_reg;
    logic [ENGINE_NUM - 1:0] sec_row_select_a_reg;
    logic [ENGINE_NUM - 1:0] sec_row_select_b_reg;

    logic [15:0] dec_first_row_a, dec_first_row_b;
    logic [15:0] dec_sec_row_a, dec_sec_row_b;

    logic [ENGINE_NUM-1:0] [15:0] dec_first_rows_reg;
    logic [ENGINE_NUM-1:0] [15:0] dec_sec_rows_reg;



    // This might end up being an inefficent way to select the active valid
    // Choose which engine gets access this clock cycle for first row ROM (Both ports)
    always_comb begin
        first_row_select_a = 0;
        first_row_select_b = 0;
        for (int i = ENGINE_NUM-1; i >= 0; i--) begin
            if(first_row_valid_i[i] == 1) begin
                if (i >= ENGINE_NUM/2) begin
                    first_row_select_a = i;
                end else begin
                    first_row_select_b = i;
                end
            end
        end
    end

    // Choose which engine gets access this clock cycle for second row ROM (Both ports)
    always_comb begin
        sec_row_select_a = 0;
        sec_row_select_b = 0;
        for (int i = ENGINE_NUM-1; i >= 0; i--) begin
            if(sec_row_valid_i[i] == 1) begin
                if (i >= ENGINE_NUM/2) begin
                    sec_row_select_a = i;
                end else begin
                    sec_row_select_b = i;
                end
            end
        end
    end

    // Register engine selection choice
    always_ff @(posedge clk_i) begin
        if (rst_i) begin
            first_row_select_a_reg <= 3'b0;
            first_row_select_b_reg <= 3'b0;
            sec_row_select_a_reg <= 3'b0;
            sec_row_select_b_reg <= 3'b0;
        end else begin
            first_row_select_a_reg <= first_row_select_a;
            first_row_select_b_reg <= first_row_select_b;
            sec_row_select_a_reg <= sec_row_select_a;
            sec_row_select_b_reg <= sec_row_select_b;
        end
    end

    // Register data sent back to decode engines
    always_ff @(posedge clk_i) begin
        if(rst_i) begin
            dec_first_rows_reg <= 0;
            dec_sec_rows_reg <= 0;
        end else begin
            dec_first_rows_reg[first_row_select_a_reg] <= dec_first_row_a;
            dec_first_rows_reg[first_row_select_b_reg] <= dec_first_row_b;
            dec_sec_rows_reg[sec_row_select_a_reg] <= dec_sec_row_a;
            dec_sec_rows_reg[sec_row_select_b_reg] <= dec_sec_row_b;
        end

    end

    // Assign output values to be equal to registered values from ROMs
    assign dec_first_rows_o = dec_first_rows_reg;
    assign dec_sec_rows_o    = dec_sec_rows_reg;

    // ROM used for decoding the first row
    decoder_second_row_14x16 u_decoder_first_row_14x16 (
        .clka(clk_i),  
        .addra(first_rows_i[first_row_select_a]),                // input wire [15 : 0] addra
        .douta(dec_first_row_a),                                 // output wire [31 : 0] douta
        .clkb(clk_i),                                            // input wire clkb
        .addrb(first_rows_i[first_row_select_b]),                // input wire [15 : 0] addrb
        .doutb(dec_first_row_b)                                  // output wire [15 : 0] doutb
    );

    // ROM used for decoding the second row
    decoder_second_row_14x16 u_decoder_second_row_14x16 (
        .clka(clk_i), 
        .addra(sec_rows_i[sec_row_select_a]),                  // input wire [13 : 0] addra
        .douta(dec_sec_row_a),                                 // output wire [15 : 0] douta
        .clkb(clk_i),                                          // input wire clkb
        .addrb(sec_rows_i[sec_row_select_b]),                  // input wire [13 : 0] addrb
        .doutb(dec_sec_row_b)                                  // output wire [15 : 0] doutb
    );


endmodule