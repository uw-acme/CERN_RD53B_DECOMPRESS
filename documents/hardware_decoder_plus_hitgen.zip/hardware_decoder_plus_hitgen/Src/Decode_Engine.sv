`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 11/18/2020 10:27:44 PM
// Design Name: 
// Module Name: Decode_Engine_Top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

/*
Current issues:
- The TOT just grabs the next 64 bits in the stream which should be okay, but sometimes will pass along X's

*/


// TODO: Overall restructure of the code so it flows better


`define TAG_SIZE     8
`define ISNEIGH_SIZE 1
`define ISLAST_SIZE  1
`define CCOL_SIZE    6
`define QROW_SIZE    8
`define HITMAP_SHIFT 29
`define MAX_ROW_SIZE 14
`define TWO_BIT_HIT  2
`define MAX_TOT_SIZE 64

`define IS_BIT_SHIFT   (`ISNEIGH_SIZE + `ISLAST_SIZE)
`define CCOL_ON_SHIFT  (`IS_BIT_SHIFT + `CCOL_SIZE)
`define QROW_ON_SHIFT  (`IS_BIT_SHIFT + `QROW_SIZE)
`define BOTH_ON_SHIFT  (`IS_BIT_SHIFT + `QROW_SIZE + `CCOL_SIZE)

`define PACKET_SIZE    63   // TODO Really 'word size'

`define BUFF_SIZE      188  // Buffer for data. Size is three words. Why not 189 ???

`define SHIFT_POINT    (`BUFF_SIZE - `PACKET_SIZE) // 188 - 63 = 125


// *** Parameter ENGINES_TOTAL is not used ***
module decode_engine #(ENGINE_ID = 0, ENGINES_TOTAL = 2)(
    input                             clk_i,
    input                             rst_i,
    input                             stream_valid_i,            // The stream data that is being advertised is valid
    input        [`PACKET_SIZE-1:0]   stream_data_i,             // Raw data from the data stream
    input                             end_trans_i,               // Tells engine when the current event ends
    input                             ready_decode_data_i,       // When the next module is ready to recieve the decoded data
    input        [15:0]               decoded_hitmap_row_one_i,
    input        [15:0]               decoded_hitmap_row_two_i,
    input        [5:0]                engine_offset_counter_i,
    output logic                      ready_stream_o,            // When the engine is ready to recieve raw stream data
    output       [127:0]              decoded_data_o,            // Output of decoded data when engine is finished 
    output                            decode_data_valid_o,       // Advertises when the decoded data is valid
    output       [13:0]               first_row_o,
    output       [13:0]               sec_row_o,
    output logic                      first_row_valid_o,
    output logic                      sec_row_valid_o,
    output logic                      fifo_stream_prog_full_o
    );


// Registers to hold intermediate data
logic         is_last_reg;                   // Register to hold the is last value from last event
logic [7:0]   qrow_reg;                      // Holds the previous qrow value for data storage
logic [5:0]   ccol_reg;                      // Holds the previous ccol value for data storage
logic [7:0]   tag_reg;                       // Holds the previous tag value for data storage
logic [15:0]  decoded_hitmap;                // Holds the decoded hitmap value for data storage
logic [188:0] shifted_stream;                // Holds the stream as it is shifted through for consumption, 188 to hold 3 63 bit sets
logic [15:0]  decoded_hitmap_row_one;        // Value from the first row hitmap ROM
logic [15:0]  decoded_hitmap_row_two;        // Value from the second row hitmap ROM
logic [4:0]   number_hits;                   // Calculates number of hits in current hitmap
logic [4:0]   number_hits_reg;               // Calculates number of hits in current hitmap
logic [63:0]  tot_reg;                       // Holds the previous TOT value for data storage

// TODO: Centalize the clock offset counter
logic         engine_offset;


// Data processing state machine enumerations
// TODO Use caps for names. Use names beginning with 'S_' e.g. S_NO_STREAM, S_SETUP, S_TAG
enum {no_stream, setup_stream, tag_consume, address_consume, 
      decode_hitmap_row_one, rom_stall, decode_hitmap_row_two, hitmap_calc, total_data_ready} 
      data_consume_state, data_consume_state_n; // TODO Why 'data_consume_state' ??? Some state names already have 'consume' in them. This is the only state machine
      // TODO : DO NOT USE xx_state_n FOR THE NEXT STATE. STATE_N MEANS THE INVERSE OF STATE. USE STATE_NEXT OR SOMETHING


logic         end_of_stream;                 // Signals 6 zeros in a row or end of stream
logic         decoded_data_ready;            // Signals that the registers current values are ready to be stored
logic [7:0]   first_row_rollback;            // Roll back for the first row of the hitmaps
logic [7:0]   sec_row_rollback;              // Roll back for the second row of the hitmaps
logic [7:0]   tot_start;
logic         first_row_flag;
logic         sec_row_flag;
logic [1:0]   hitmap_start_shift;

// Shifter controls
logic [7:0]   stream_ptr;                    // Keeps track of the current index of the shifted stream
logic [7:0]   stream_ptr_reg;
logic         shift_possible;                // Signals whenever we can bring in new data

// Stream Fifo controls
logic                     empty_stream_fifo;             // The empty signal from the stream fifo
logic [`PACKET_SIZE-1:0]  data_stream_o;                 // The data from the empty stream fifo
logic                     rd_stream_fifo;                // Signals when to read new raw stream data out of fifo
logic                     wr_stream_fifo;                // Signals when to write new data from the input to the raw stream fifo
logic                     setup_stream_counter;          // Used to count number of packets during setup

// Decoded data fifo controls
logic [127:0] decoded_data_fifo_i;           // Data from the registers into the final output fifo
logic         wr_decode_fifo;               // Signals when to wrtie decode fifo
logic         rd_decode_fifo;                // Signals when to read the decoded fifo
logic         empty_decode;                  // Empty decode fifo signal

// Counter system logic
logic [9:0]  decode_fifo_counter;            // Counter system for reading out of the decode fifo
logic [9:0]  stream_fifo_counter;            // Counter system for reading out of the stream fifo

logic finished_process;                      // Shows when all the different pieces in the system have finished processing

logic engine_stall;                          // Stalls the engine when there is no new data to take in
logic engine_stall_reset;                    // Starts engine back up when new data is ready

logic setup_data;
logic rd_setup_stream;

logic [29:0] total_hitmap_shifted;
logic [29:0] total_hitmap_reg;


logic       isneigh_status;
logic [7:0] hitmap_end;
logic [15:0] addr_reg;


//------------------------------------------------------------------------
// Control Systems
//
//------------------------------------------------------------------------

// Lets the system know when the output is valid and all data for event has been processed
assign decode_data_valid_o = !empty_decode & decode_fifo_counter > 0;
assign rd_decode_fifo = decode_data_valid_o & ready_decode_data_i;

// This piece of logic will look at all pieces of the process and determine that it is done processing an event
assign finished_process = stream_fifo_counter == 0 & decode_fifo_counter == 0 & data_consume_state == no_stream;

// Signals to unit sending in data that it is ready to recieve more
always_ff @(posedge clk_i) begin
    if (rst_i) begin
        ready_stream_o <= 1;
    end else if (end_trans_i) begin
        ready_stream_o <= 0;
    end else if (finished_process) begin
        ready_stream_o <= 1;
    end
end


assign wr_decode_fifo = decoded_data_ready;
assign decoded_data_fifo_i = {26'h0, tag_reg, ccol_reg, qrow_reg, decoded_hitmap, tot_reg};

//------------------------------------------------------------------------
// Setup for shifting in new data
//
//------------------------------------------------------------------------

always_ff @(posedge clk_i) begin
    if (rst_i | data_consume_state != setup_stream) begin
        setup_stream_counter <= 1'b0;
    end else if (shift_possible & setup_stream_counter == 0) begin
        setup_stream_counter <= setup_stream_counter + 1;
    end
end

// Used to offset the engines for when they make requests from the decoder ROM
always_ff @(posedge clk_i) begin
    if(rst_i) begin
        engine_offset <= 0;
    end else begin
        if ((engine_offset_counter_i) == ENGINE_ID % 6) begin
            engine_offset <= 1;
        end else begin
            engine_offset <= 0;
        end
    end
end

// Control signals used to setup when to read   TODO Read what???
assign shift_possible    = (!empty_stream_fifo & stream_fifo_counter > 0);
assign setup_data        = (shift_possible & (data_consume_state == no_stream | data_consume_state == setup_stream));
assign rd_setup_stream    = ((setup_data & setup_stream_counter == 1'b0) | (setup_data & engine_offset & setup_stream_counter == 1'b1));
assign rd_stream_fifo    = (shift_possible & stream_ptr_reg <= `SHIFT_POINT) | rd_setup_stream;


//-------------------------------------------------------------------------------------------
// Completes the shifting of data stream. 
// TODO Actually does all the shifting of data buffer.
// TODO Do we really need to shift the data or just move a pointer ???
// TODO Does initial fill of 'shifted_stream' then reads data from input FIFO into LSBs of reg 
// whenever there is room for more data.
//-------------------------------------------------------------------------------------------
always_ff @(posedge clk_i) begin

    if (rst_i) begin
        shifted_stream <= 128'b0;   // TODO Isn't this 189 bits ???  BUFF_SIZE'b0 ???

    end else begin

        // First data word from input FIFO into MSBs
        if          (setup_data & data_consume_state == no_stream) begin
            shifted_stream <= {data_stream_o[`PACKET_SIZE-1:0], 126'h0};    

        // Second data word from input FIFO into  middle of reg
        end else if (setup_data & setup_stream_counter == 1'b0) begin
            shifted_stream <= {shifted_stream[188:126], data_stream_o[`PACKET_SIZE-1:0], 63'b0};

        // Third data word from input FIFO into LSBs
        end else if (setup_data & engine_offset & setup_stream_counter == 1'b1) begin
            shifted_stream <= {shifted_stream[188:63], data_stream_o[`PACKET_SIZE-1:0]};

        // Shift data left 63 bits and read next data word from input FIFO into LSBs whenever 
        // reg pointer is <= SHIFT_POINT (125) i.e. At least 63 MSBs have been decoded.
        end else if(shift_possible & stream_ptr_reg <= `SHIFT_POINT) begin
            shifted_stream <= {shifted_stream[125:0], data_stream_o[`PACKET_SIZE-1:0]};

        end
    end
end


//------------------------------------------------------------------------
// Hitmap parsing and storage
//
//------------------------------------------------------------------------

// Get the isneighbor status early to determine the length of address bits 
always_ff @(posedge clk_i) begin
    if (rst_i) begin
        isneigh_status <= 0;
    end else if (data_consume_state == tag_consume) begin
        isneigh_status <= 1'b0;
    end else if (data_consume_state == decode_hitmap_row_two) begin
        if (!is_last_reg) begin
            isneigh_status <= shifted_stream[stream_ptr - `ISLAST_SIZE]; 
        end else begin
            isneigh_status <= shifted_stream[stream_ptr - `ISLAST_SIZE - `CCOL_SIZE];
        end
    end
end

// Registers the address bits to cut down on resource usage from searching
// entire buffer for the address
always_ff @(posedge clk_i) begin
    if (rst_i) begin
        addr_reg <= 0;
    end else if (data_consume_state == tag_consume) begin
        addr_reg <= shifted_stream[`BUFF_SIZE - `TAG_SIZE -: 16];
    end else if (data_consume_state == hitmap_calc) begin
        addr_reg <= shifted_stream[stream_ptr_reg - 15 +: 16];
    end
end

// Find the end point of the hitmap to register it
always_comb begin
    if (data_consume_state == hitmap_calc) begin
        if(!is_last_reg) begin
            if(isneigh_status) begin
                hitmap_end = stream_ptr_reg - `IS_BIT_SHIFT - `HITMAP_SHIFT;
            end else begin
                hitmap_end = stream_ptr_reg - `QROW_ON_SHIFT - `HITMAP_SHIFT;
            end
        end else begin
            if(isneigh_status) begin
                hitmap_end = stream_ptr_reg - `CCOL_ON_SHIFT - `HITMAP_SHIFT;
            end else begin
                hitmap_end = stream_ptr_reg - `BOTH_ON_SHIFT - `HITMAP_SHIFT;
            end
        end

    end else begin
        hitmap_end = 0;
    end
end

//------------------------------------------------------------------------
// State Machine
//
//------------------------------------------------------------------------

// Register all possible hitmap bits to send to ROMs early
always_ff @(posedge clk_i) begin
    if(rst_i) begin
        first_row_valid_o <= 0;
        total_hitmap_reg <= 0;
    end else if ((data_consume_state == setup_stream & data_consume_state_n == tag_consume)) begin
        first_row_valid_o <= 1;
        total_hitmap_reg <= shifted_stream[`BUFF_SIZE - `TAG_SIZE - `BOTH_ON_SHIFT - `HITMAP_SHIFT +: 30];
    end else if (data_consume_state == hitmap_calc) begin
        first_row_valid_o <= 1;
        total_hitmap_reg <= shifted_stream[hitmap_end +: 30];
    end else begin
        first_row_valid_o <= 0;
    end
end


// State machine for processing data
// TODO Not really. This is just the state variable register
always_ff @(posedge clk_i) begin
    if(rst_i) begin
        data_consume_state <= no_stream;
    end else begin
        data_consume_state <= data_consume_state_n;
    end
end

// System for switching between data consumption states
// TODO Combinational part of state machine. Calc next state
always_comb begin

    case (data_consume_state)
        no_stream             : data_consume_state_n = (shift_possible) ? setup_stream : no_stream;
        setup_stream          : data_consume_state_n = (shift_possible & setup_stream_counter == 1'b1 & engine_offset) ? tag_consume 
                                           : (!ready_stream_o & stream_fifo_counter == 0 & engine_offset) ? tag_consume 
                                           : setup_stream;
        // TODO: I think I can delete the end of stream here and have it only in the ccol state
        tag_consume           : data_consume_state_n = end_of_stream ? no_stream : address_consume;
        address_consume       : data_consume_state_n = end_of_stream ? no_stream : decode_hitmap_row_one;
        decode_hitmap_row_one : data_consume_state_n = rom_stall;
        rom_stall             : data_consume_state_n = engine_stall ? rom_stall 
                                                       : (engine_stall_reset) ? decode_hitmap_row_two
                                                       : rom_stall;
        decode_hitmap_row_two : data_consume_state_n = hitmap_calc;
        hitmap_calc           : data_consume_state_n = total_data_ready;
        total_data_ready      : data_consume_state_n = address_consume;
        default               : data_consume_state_n = no_stream;
    endcase

end

// End of stream control to shift different states and start the reading of decoded fifo
assign end_of_stream = shifted_stream[stream_ptr_reg - 5 +: 6] == 6'b000000 & (data_consume_state == tag_consume | data_consume_state == address_consume) & is_last_reg;

// Logic to stall engine while waiting for new data
assign engine_stall = stream_fifo_counter == 0 & stream_ptr <= `SHIFT_POINT & ready_stream_o;
assign engine_stall_reset = engine_offset_counter_i == (ENGINE_ID + 5) % 6;

// Stream_ptr calculations
always_ff @(posedge clk_i) begin
    if(rst_i | data_consume_state == no_stream) begin
        stream_ptr_reg <= 8'd188;
    end else begin
        stream_ptr_reg <= stream_ptr;
    end
end

// Takes care of the stream_ptr shifting
always_comb begin
    case(data_consume_state)

        (tag_consume) :
        begin
            number_hits = number_hits_reg;
            stream_ptr = stream_ptr_reg - `TAG_SIZE;

        end

        
        (address_consume):
        begin
            number_hits = number_hits_reg;
            if(!is_last_reg) begin
                if (isneigh_status) begin
                    stream_ptr = stream_ptr_reg - `IS_BIT_SHIFT;
                end else begin
                    stream_ptr = stream_ptr_reg - `QROW_ON_SHIFT;
                end
            end else begin
                if (isneigh_status) begin
                    stream_ptr = stream_ptr_reg - `CCOL_ON_SHIFT;
                end else begin
                    stream_ptr = stream_ptr_reg - `BOTH_ON_SHIFT;
                end
            end
        end


        (decode_hitmap_row_one):
        begin
            if (first_row_flag) begin
            stream_ptr = stream_ptr_reg - `MAX_ROW_SIZE - hitmap_start_shift + first_row_rollback;
            number_hits =  decoded_hitmap_row_one[0]  + decoded_hitmap_row_one[1]  + decoded_hitmap_row_one[2]  + decoded_hitmap_row_one[3] +
                            decoded_hitmap_row_one[4]  + decoded_hitmap_row_one[5]  + decoded_hitmap_row_one[6]  +
                            decoded_hitmap_row_one[7];
            end else begin
                stream_ptr = stream_ptr_reg - hitmap_start_shift;
                number_hits = 0;
            end
            
        end

        (decode_hitmap_row_two):
        begin
            if (sec_row_flag) begin
                number_hits =  number_hits_reg  + decoded_hitmap_row_two[0]  + decoded_hitmap_row_two[1] +
                                decoded_hitmap_row_two[2] + decoded_hitmap_row_two[3] + decoded_hitmap_row_two[4] +
                                decoded_hitmap_row_two[5] + decoded_hitmap_row_two[6] + decoded_hitmap_row_two[7];
                stream_ptr = stream_ptr_reg - `MAX_ROW_SIZE - (number_hits << 2) + sec_row_rollback;
            end else begin
                stream_ptr = stream_ptr_reg - (number_hits << 2);
                number_hits = number_hits_reg;
            end
        end

        default: 
        begin
            stream_ptr = stream_ptr_reg;
            number_hits = number_hits_reg;
        end
    endcase

    // If a new packet is being read from the fifo then shift the stream ptr down
    if (stream_ptr_reg <= `SHIFT_POINT & !empty_stream_fifo) begin
        stream_ptr = stream_ptr + `PACKET_SIZE;
    end
end


// TODO COMMENT What is this ???
always_ff @(posedge clk_i) begin
    if(rst_i | data_consume_state == no_stream) begin
        qrow_reg <= 0;
        ccol_reg <= 0;
        is_last_reg <= 1;
        number_hits_reg <= 0;
        decoded_hitmap <= 16'h0000;
        tag_reg <= 8'h00;
        tot_reg <= 64'h0;
        decoded_data_ready <= 1'b0;
        sec_row_valid_o <= 1'b0;
    end else begin
        case(data_consume_state)
            (tag_consume) :
                begin
                    // Set tag value
                    tag_reg <= shifted_stream[`BUFF_SIZE:`BUFF_SIZE-7];
                end
            (address_consume) :
                // Should move the stream_ptr calculation into a combinational block and register it
                begin
                    // Checks if is_last should be used
                    if(!is_last_reg) begin
                        // Stores ccol and is_last values
                        is_last_reg <= addr_reg[15];
                        ccol_reg <= ccol_reg;
                        if (isneigh_status) begin
                            qrow_reg <= qrow_reg + 1;
                        end else begin
                            qrow_reg <= addr_reg[6 +: `QROW_SIZE];
                        end
                    end else begin
                        // Stores ccol and is_last values
                        ccol_reg <= addr_reg[15:10];
                        is_last_reg <= addr_reg[9];

                        if (isneigh_status) begin
                            qrow_reg <= qrow_reg + 1;
                        end else begin
                            qrow_reg <= addr_reg[0 +: `QROW_SIZE];
                        end
                    end

                    // No data should be ready next cycle so keep this signal low
                    decoded_data_ready <= 1'b0;
                    sec_row_valid_o <= 1'b1;

                end

            (decode_hitmap_row_one):
                begin
                    if (first_row_flag) begin
                        // Grabs the decoded hitmap
                        // This will be a complete hitmap if only one row has hits
                        decoded_hitmap[7:0] <= decoded_hitmap_row_one[7:0];

                        // Counts the number of hits in the hitmap for the TOT
                        number_hits_reg <= number_hits;
                    end else begin
                        decoded_hitmap[7:0] <= 8'b0;
                        number_hits_reg <= 5'b0;
                    end
                    
                    sec_row_valid_o <= 1'b0;
                end
            (decode_hitmap_row_two):
                begin

                    if (sec_row_flag) begin
                        // If there is a second row with hits then we will or this with the origional decoded hitmap
                        decoded_hitmap[15:8] <= decoded_hitmap_row_two[7:0];

                        number_hits_reg <= number_hits;
                    end
                        tot_reg <= shifted_stream[tot_start - 63 +: 64];
                end

            (total_data_ready):
                begin
                    // After this stage all data should be ready to be stored
                    decoded_data_ready <= 1'b1;
                end 
        endcase
    end
end

//------------------------------------------------------------------------
// Decode ROM in/out
//
//------------------------------------------------------------------------

// Grab the rollback values from each ROM
always_comb begin
    if (first_row_flag) begin
        first_row_rollback = decoded_hitmap_row_one[15:8];
    end else begin
        first_row_rollback = 8'd14;
    end

    sec_row_rollback   = decoded_hitmap_row_two[15:8];

    if (sec_row_flag) begin
        tot_start = stream_ptr_reg + sec_row_rollback - `MAX_ROW_SIZE;
    end else begin
        tot_start = stream_ptr_reg;
    end
end


// Decodes first two bits of the hitmap to see which rows are active
always_comb begin
    if(total_hitmap_reg[29] == 1'b0) begin
        total_hitmap_shifted = total_hitmap_reg << 1;
        hitmap_start_shift = 2'b01;
        first_row_flag = 1'b0;
        sec_row_flag = 1'b1;
    end else if (total_hitmap_reg[29:28] == 2'b10) begin
        total_hitmap_shifted = total_hitmap_reg << 2;
        hitmap_start_shift = 2'b10;
        first_row_flag = 1'b1;
        sec_row_flag = 1'b0;
    end else begin
        total_hitmap_shifted = total_hitmap_reg << 2;
        hitmap_start_shift = 2'b10;
        first_row_flag = 1'b1;
        sec_row_flag = 1'b1;
    end
end

// Replacing the in module ROM with input and output ports
assign first_row_o            = total_hitmap_shifted[29 -: 14];
assign sec_row_o              = total_hitmap_shifted[15 + first_row_rollback -: 14];
assign decoded_hitmap_row_one = decoded_hitmap_row_one_i;
assign decoded_hitmap_row_two = decoded_hitmap_row_two_i;

//------------------------------------------------------------------------
// Memory modules TODO ??? What?
//
//------------------------------------------------------------------------

assign wr_stream_fifo = stream_valid_i & ready_stream_o;

// Fifo to store input data
// Fifo is first word fall through
fifo_stream_data u_fifo_stream_data (
  .clk(clk_i),
  .srst(rst_i),
  .din(stream_data_i),      // input wire [62 : 0] din
  .wr_en(wr_stream_fifo),
  .rd_en(rd_stream_fifo), 
  .dout(data_stream_o),    // output wire [62 : 0] dout
  .full(),                              // TODO Isn't 'full' important ???
  .empty(empty_stream_fifo),
  .prog_full(fifo_stream_prog_full_o)    // output wire prog_full (480)
);

// Fifo to hold output data
// Fifo is first word fall through
fifo_decode_data u_fifo_decode_data (
  .clk(clk_i),
  .srst(rst_i),
  .din(decoded_data_fifo_i),      // input wire [128 : 0] din
  .wr_en(wr_decode_fifo),
  .rd_en(rd_decode_fifo),
  .dout(decoded_data_o),    // output wire [128 : 0] dout
  .full(),
  .empty(empty_decode)
);

// Counter System for processing data through stream fifo ???
// TODO Keep track of the number of data words stored in the input data FIFO 
fifo_counter #(10) u_stream_fifo_counter
(
    .clk_i(clk_i),
    .rst_i(rst_i),
    .write_i(wr_stream_fifo),
    .read_i(rd_stream_fifo),
    .count(stream_fifo_counter)
);

// Counter System for processing data through decoded fifo ???
// TODO Keep track of the number of data words stored in the input data FIFO 
fifo_counter #(10) u_decode_fifo_counter
(
    .clk_i(clk_i),
    .rst_i(rst_i),
    .write_i(wr_decode_fifo),
    .read_i(rd_decode_fifo),
    .count(decode_fifo_counter)
);

endmodule
