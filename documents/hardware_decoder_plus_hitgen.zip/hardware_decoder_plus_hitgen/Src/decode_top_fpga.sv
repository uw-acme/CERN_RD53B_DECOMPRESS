`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 01/05/2021 09:29:38 PM
// Design Name: 
// Module Name: decode_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// Defines can be changed in the defines file
`include "../Include/defines.txt"
`timescale 1ns / 1ps

// ENGINES_TOTAL: Amount of engines to put into the design (Max 12, Min 1)
// NUM_HITS: The number of quarter rows per stream for the testing block
// NUM_STREAMS: Number of streams in the raw data ROM
// VALID_STREAM_NUM: The amount of lines for the raw data ROM that are valid
module decode_top #(ENGINES_TOTAL=12, NUM_HITS=3, NUM_STREAMS=3, VALID_STREAM_NUM=11)(
    // I/O used for simulation version of code
    `ifndef TOPLEVEL
        input                              clk_i,
        input                              rst_i,
        input  [63:0]                      data_raw_i,
        input                              valid_raw_i,
        output                             ready_raw_o,
        output [ENGINES_TOTAL-1:0]         valid_decode_data_io,
        output [ENGINES_TOTAL-1:0] [127:0] decoded_data_o
        
    // I/O used for vivado build version of code
    `else 
        input                           SYSCLK_P,
        input                           SYSCLK_N,
        input   logic                   CPU_RESET, 
        input   logic                   GPIO_SW_S, // start
        input   logic                   GPIO_SW_N, // stop
        output  logic                   GPIO_LED_0_LS, 
        output  logic                   GPIO_LED_1_LS,
        output  logic                   GPIO_LED_2_LS,
        output  logic                   GPIO_LED_3_LS,
        output  logic                   GPIO_LED_4_LS,
        output  logic                   GPIO_LED_5_LS,
        output  logic                   GPIO_LED_6_LS,
        output  logic                   GPIO_LED_7_LS 
    `endif
    );
    


    // Interconnects for the decoding ROM and engines modules
    logic [ENGINES_TOTAL-1:0]       first_row_valid;
    logic [ENGINES_TOTAL-1:0]       sec_row_valid;
    logic [ENGINES_TOTAL-1:0][13:0] first_row_addr_io;
    logic [ENGINES_TOTAL-1:0][13:0] sec_row_addr_io;
    logic [ENGINES_TOTAL-1:0][15:0] dec_first_row_io;
    logic [ENGINES_TOTAL-1:0][15:0] dec_sec_row_io;

    // Centralized engine offset counter
    logic [5:0]                     engine_offset_counter_io;

    // Interconnects for the stream distributor and the engines
    logic                           ready_stream_o;
    logic [ENGINES_TOTAL-1:0]       end_of_stream_io;
    logic [ENGINES_TOTAL-1:0]       stream_valid_io;
    logic [62:0]                    stream_data_io;
    logic [ENGINES_TOTAL-1:0]       engine_ready_io;
    logic [ENGINES_TOTAL-1:0]       dec_eng_prog_full_io;

    // interconnects for the test block
    logic [ENGINES_TOTAL-1:0]       test_new_stream_io;
    logic [ENGINES_TOTAL-1:0]       check_fifo_ready_io; 

    genvar i;
    

    `ifdef TOPLEVEL
        // Conenctions to setup if we are using decode_top as top level file
        logic [ENGINES_TOTAL-1:0] [127:0] decoded_data_o;
        logic                             clk_i;
        logic                             reset_in;
        logic                             rst_i;
        logic                             clkreset_lock;
        logic [3:0]                       err_signals;
        logic [3:0]                       pulse_stretched;
        logic [3:0]                       pulse;
        logic                             blink;
        logic                             tick_sec;
        logic                             tick_usec;
        logic                             start;
        logic                             stop;
        logic                             all_start;

        // Connections for the raw stream data ROM
        logic [9:0]                  address_counter;
        logic [63:0]                 data_raw_i;
        logic                        valid_raw_i;
        logic                        ready_raw_o;

        // If this decode_top is the top level then this is an interconnect
        // For the testing block.
        logic [ENGINES_TOTAL-1:0]       valid_decode_data_io;

        assign reset_in = CPU_RESET;

        // Clock setup
        clkreset            u_clkreset       
            (         
                .reset_in   (reset_in       ),  // input
                .clk_in1_p  (SYSCLK_P       ),  // input 
                .clk_in1_n  (SYSCLK_N       ),  // input
                .clk        (clk_i          ),  // output
                .lock       (clkreset_lock  ),  // output
                .reset      (rst_i          )   // output
            );

        //------------------------------------
        // Debounce start
        //------------------------------------
        debounce            u_debounce_start
        (
            .clk    (clk_i      ),  
            .reset  (rst_i      ),
            .sw_in  (GPIO_SW_S  ),  // input
            .sw_out (start      )   // output
        );

        debounce            u_debounce_stop
        (
            .clk    (clk_i      ),  
            .reset  (rst_i      ),
            .sw_in  (GPIO_SW_N  ),  // input
            .sw_out (stop       )   // output
        );

        // Only register the inputs and don't debounce
        //logic start_reg1, start_reg2, start_reg3;
        //logic stop_reg1, stop_reg2, stop_reg3;

        /*always_ff @(posedge clk_i) begin
            start_reg1 <= GPIO_SW_S;
            start_reg2 <= start_reg1;
            start_reg3 <= start_reg2;
            start      <= start_reg3;
            stop_reg1  <= GPIO_SW_N;
            stop_reg2  <= stop_reg1;
            stop_reg3  <= stop_reg2;
            stop       <= stop_reg3;
        end*/

        // No registering or delay on input buttons
        /*assign start = GPIO_SW_S;
        assign stop = GPIO_SW_N; */ 

        // Turn the input buttons into on and off buttons
        always_ff @(posedge clk_i) begin
            if (rst_i) begin
                all_start <= 1'b0;
            end else if (start) begin
                all_start <= 1'b1;
            end else if (stop) begin
                all_start <= 1'b0;
            end
        end

        //------------------------------------
        // Blinky and pulse stretcher
        //------------------------------------
        blink #(4, 20)      u_blink             // G_NBITS = 4, G_INTERVAL_TICK_SLOW = 20
        (
            .reset      (rst_i                ),  // input
            .clk        (clk_i                ),  // input
            
            .flash      (blink              ),    
            .tick_sec   (tick_sec           ),  // output
            .tick_msec  (                   ),  // output, not hooked to anything
            .tick_usec  (tick_usec          ),  // output
            
            .pulse      (pulse              ),  // [G_NBITS-1:0] input 
            .stretched  (pulse_stretched    )   // [G_NBITS-1:0] output
        );
            
        assign pulse            = err_signals[3:0]      ;
        
        assign GPIO_LED_0_LS    = clkreset_lock         ;
        assign GPIO_LED_1_LS    = blink                 ;
        assign GPIO_LED_2_LS    = tick_sec              ;
        assign GPIO_LED_3_LS    = all_start             ;
        assign GPIO_LED_4_LS    = pulse_stretched[3]    ; // ToT
        assign GPIO_LED_5_LS    = pulse_stretched[2]    ; // hitmap
        assign GPIO_LED_6_LS    = pulse_stretched[1]    ; // ccol
        assign GPIO_LED_7_LS    = pulse_stretched[0]    ; // qrow

        
        // All testing logic, right now it is using a decoded version of the data from a ROM
        test_block #(ENGINES_TOTAL, NUM_HITS, NUM_STREAMS) u_test_block_1(
            .clk_i(clk_i),
            .rst_i(rst_i),
            .new_stream_i(test_new_stream_io),
            .engine_valid_i(valid_decode_data_io),
            .decoded_data_i(decoded_data_o),
            .check_fifo_ready_o(check_fifo_ready_io),
            .checked_data_o(),
            .err_signals(err_signals)
        );

        // Increments through the valid addresses in the ROM
        always_ff @(posedge clk_i) begin
            if (rst_i) begin
                address_counter <= 0;
            end else if (all_start & ready_raw_o) begin
                if (address_counter == VALID_STREAM_NUM - 1) begin
                    address_counter <= 0;
                end else begin
                    address_counter <= address_counter + 1;
                end
            end
        end

        // Automatically starts the data send when rst is no longer asserted
        assign valid_raw_i = !rst_i & all_start & ready_raw_o;

        // ROM that sends preset streams to engines
        generated_stream_data_ROM u_generated_stream_data_ROM (
            .a(address_counter),      // input wire [5 : 0] a
            .spo(data_raw_i)          // output wire [63 : 0] spo
        );
    `endif
    
    // Output module always ready to accept data (Used for testing)
    // Current hit_gen does not have this signal so hardwired it.
    `ifndef TOPLEVEL
        assign check_fifo_ready_io = 1'b1;
    `endif
    
    // Generates the number of engines to use for the system based on top level parameter
    generate
        for(i = 0; i < ENGINES_TOTAL; i++) begin : decode_engines
            decode_engine #(i, ENGINES_TOTAL) u_decode_engine(
                .clk_i(clk_i),
                .rst_i(rst_i),
                .stream_valid_i(stream_valid_io[i]),                      // The stream data that is being advertised is valid
                .stream_data_i(stream_data_io),                     // Raw data from the data stream
                .end_trans_i(end_of_stream_io[i]),                         // Tells engine when the current event ends
                .ready_decode_data_i(check_fifo_ready_io[i]),                 // When the next module is ready to recieve the decoded data
                .decoded_hitmap_row_one_i(dec_first_row_io[i]),
                .decoded_hitmap_row_two_i(dec_sec_row_io[i]),
                .engine_offset_counter_i(engine_offset_counter_io),
                .ready_stream_o(engine_ready_io[i]),            // When the engine is ready to recieve raw stream data
                .decoded_data_o(decoded_data_o[i]),            // Output of decoded data when engine is finished 
                .decode_data_valid_o(valid_decode_data_io[i]),   // Advertises when the decoded data is valid
                .first_row_o(first_row_addr_io[i]),
                .sec_row_o(sec_row_addr_io[i]),
                .first_row_valid_o(first_row_valid[i]),
                .sec_row_valid_o(sec_row_valid[i]),
                .fifo_stream_prog_full_o(dec_eng_prog_full_io[i])
            );
        end
    endgenerate

    // Centralized engine offset counter so all engines are using the same count
    engine_offset_shared #(ENGINES_TOTAL) u_engine_offset_shared (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .engine_offset_counter(engine_offset_counter_io)
    );

    // Takes in raw data from data source (ROM right now) and send it to available engines
    stream_distribute #(ENGINES_TOTAL) u_stream_distribute (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .ready_engine_i(engine_ready_io),
        .valid_raw_i(valid_raw_i),
        .data_raw_i(data_raw_i),
        .dec_eng_prog_full_i(dec_eng_prog_full_io),
        .valid_stream_o(stream_valid_io),
        .data_stream_o(stream_data_io),
        .ready_raw_o(ready_raw_o),
        .end_of_stream_o(end_of_stream_io),
        .test_new_stream_o(test_new_stream_io)
    );

    // Takes in hitmap decode requests from engines and returns decoded hitmaps
    decode_rom_distribute #(ENGINES_TOTAL) u_decode_rom_distribute (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .first_rows_i(first_row_addr_io),
        .first_row_valid_i(first_row_valid),
        .sec_rows_i(sec_row_addr_io),
        .sec_row_valid_i(sec_row_valid),
        .dec_first_rows_o(dec_first_row_io),
        .dec_sec_rows_o(dec_sec_row_io)
    );


endmodule
