`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 01/05/2021 09:29:38 PM
// Design Name: 
// Module Name: decode_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// Defines can be changed in the defines file
`include "../Include/defines.txt"
`timescale 1ns / 1ps

// ENGINES_TOTAL: Amount of engines to put into the design (Max 12, Min 1)
// NUM_HITS: The number of quarter rows per stream for the testing block
// NUM_STREAMS: Number of streams in the raw data ROM
// VALID_STREAM_NUM: The amount of lines for the raw data ROM that are valid
module decode_top #(ENGINES_TOTAL=12, NUM_HITS=3, NUM_STREAMS=3, VALID_STREAM_NUM=11)
(
    input                              clk_i,
    input                              rst_i,
    input  [63:0]                      data_raw_i,
    input                              valid_raw_i,
    output                             ready_raw_o,
    output [ENGINES_TOTAL-1:0]         valid_decode_data_io,
    output [ENGINES_TOTAL-1:0] [127:0] decoded_data_o
);
    
    // Interconnects for the decoding ROM and engines modules
    logic [ENGINES_TOTAL-1:0]       first_row_valid;
    logic [ENGINES_TOTAL-1:0]       sec_row_valid;
    logic [ENGINES_TOTAL-1:0][13:0] first_row_addr_io;
    logic [ENGINES_TOTAL-1:0][13:0] sec_row_addr_io;
    logic [ENGINES_TOTAL-1:0][15:0] dec_first_row_io;
    logic [ENGINES_TOTAL-1:0][15:0] dec_sec_row_io;

    // Centralized engine offset counter
    logic [5:0]                     engine_offset_counter_io;

    // Interconnects for the stream distributor and the engines
    logic                           ready_stream_o;
    logic [ENGINES_TOTAL-1:0]       end_of_stream_io;
    logic [ENGINES_TOTAL-1:0]       stream_valid_io;
    logic [62:0]                    stream_data_io;
    logic [ENGINES_TOTAL-1:0]       engine_ready_io;
    logic [ENGINES_TOTAL-1:0]       dec_eng_prog_full_io;

    // interconnects for the test block
    logic [ENGINES_TOTAL-1:0]       test_new_stream_io;
    logic [ENGINES_TOTAL-1:0]       check_fifo_ready_io; 
    
    
    // Output module always ready to accept data (Used for testing)
    // Current hit_gen does not have this signal so hardwired it.
    assign check_fifo_ready_io = 1'b1;
    
    // Centralized engine offset counter so all engines are using the same count
    // *** Parameter ENGINES_TOTAL is not used ***
    // *** Counter output is a 6-bit value but counter only goes from 0 to 5. 
    // ??? Should be a shift rather than a count ??
    // Moved to be 'above' engines
    engine_offset_shared #(ENGINES_TOTAL) u_engine_offset_shared (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .engine_offset_counter(engine_offset_counter_io)
    );


    // Takes in raw data from data source and sends it to an available engine
    // Moved to be 'above' engines
    stream_distribute #(ENGINES_TOTAL) u_stream_distribute (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .ready_engine_i(engine_ready_io),
        .valid_raw_i(valid_raw_i),
        .data_raw_i(data_raw_i),
        .dec_eng_prog_full_i(dec_eng_prog_full_io),
        .valid_stream_o(stream_valid_io),
        .data_stream_o(stream_data_io),
        .ready_raw_o(ready_raw_o),
        .end_of_stream_o(end_of_stream_io),
        .test_new_stream_o(test_new_stream_io)
    );


    // Generates multiple engines based on top level parameter
    genvar i;
    generate
        for (i = 0; i < ENGINES_TOTAL; i++) begin : decode_engines

            // *** Parameter ENGINES_TOTAL is not used ***
            decode_engine #(i, ENGINES_TOTAL) u_decode_engine(
                .clk_i(clk_i),
                .rst_i(rst_i),
                .stream_valid_i(stream_valid_io[i]),                      // The stream data that is being advertised is valid
                .stream_data_i(stream_data_io),                     // Raw data from the data stream
                .end_trans_i(end_of_stream_io[i]),                         // Tells engine when the current event ends
                .ready_decode_data_i(check_fifo_ready_io[i]),                 // When the next module is ready to recieve the decoded data
                .decoded_hitmap_row_one_i(dec_first_row_io[i]),
                .decoded_hitmap_row_two_i(dec_sec_row_io[i]),
                .engine_offset_counter_i(engine_offset_counter_io),
                .ready_stream_o(engine_ready_io[i]),            // When the engine is ready to recieve raw stream data
                .decoded_data_o(decoded_data_o[i]),            // Output of decoded data when engine is finished 
                .decode_data_valid_o(valid_decode_data_io[i]),   // Advertises when the decoded data is valid
                .first_row_o(first_row_addr_io[i]),
                .sec_row_o(sec_row_addr_io[i]),
                .first_row_valid_o(first_row_valid[i]),
                .sec_row_valid_o(sec_row_valid[i]),
                .fifo_stream_prog_full_o(dec_eng_prog_full_io[i])
            );
        end
    endgenerate


    // Takes in hitmap decode requests from engines and returns decoded hitmaps
    decode_rom_distribute #(ENGINES_TOTAL) u_decode_rom_distribute (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .first_rows_i(first_row_addr_io),
        .first_row_valid_i(first_row_valid),
        .sec_rows_i(sec_row_addr_io),
        .sec_row_valid_i(sec_row_valid),
        .dec_first_rows_o(dec_first_row_io),
        .dec_sec_rows_o(dec_sec_row_io)
    );


endmodule
