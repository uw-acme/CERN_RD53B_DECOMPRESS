module test_block #(ENGINE_NUM = 8, NUM_HITS = 5, NUM_STREAMS=5)(
    input  clk_i,
    input  rst_i,
    input  [ENGINE_NUM-1:0] new_stream_i,
    input  [ENGINE_NUM-1:0] engine_valid_i,
    input  [ENGINE_NUM-1:0] [127:0] decoded_data_i,
    output [ENGINE_NUM-1:0] check_fifo_ready_o,
    output [ENGINE_NUM-1:0] [127:0] checked_data_o,
    output [3:0]                    err_signals
);

    logic [9:0]                   address_counter;
    logic [9:0]                   data_setup_counter;
    logic [15:0]                  new_stream_engines;
    logic                         write_request_empty;
    logic [127:0]                 check_data;
    logic                         check_data_valid;
    logic [15:0]                  request_streams;
    logic [15:0]                  request_streams_valid;
    logic [3:0] [ENGINE_NUM-1:0]  error_flag;
    logic [ENGINE_NUM-1:0]        check_fifo_empty;

    //////////////////////////////////////////////////////////////////
    // Fifo choosing and data send state machine
    // 
    //////////////////////////////////////////////////////////////////
    enum {wait_data, process_data} 
        fill_fifo_state, fill_fifo_state_n;

    always_ff @(posedge clk_i) begin
        if (rst_i) begin
            fill_fifo_state <= wait_data;
        end else begin
            fill_fifo_state <= fill_fifo_state_n;
        end
    end

    always_comb begin
        case(fill_fifo_state)
            (wait_data): fill_fifo_state_n = write_request_empty ? wait_data : process_data;

            (process_data): fill_fifo_state_n = (data_setup_counter == NUM_HITS - 1) ? wait_data : process_data;
        endcase
    end

    // If process state is active then values coming from ROM are valid
    assign check_data_valid = fill_fifo_state == process_data;


    // Address selection for decoded data checker
    always_ff @(posedge clk_i) begin
        if (rst_i) begin
            address_counter <= 0;
        end else if (address_counter == NUM_HITS*NUM_STREAMS - 1) begin
            address_counter <= 0;
        end else if(fill_fifo_state == process_data) begin
            address_counter <= address_counter + 1;
        end
    end

    // Counter for individual streams and state machine
    always_ff @(posedge clk_i) begin
        if (rst_i | (fill_fifo_state == wait_data & fill_fifo_state_n == process_data)) begin
            data_setup_counter <= 0;
        end else if (fill_fifo_state == process_data) begin
            data_setup_counter <= data_setup_counter + 1;
        end
    end


    // Expanding bus to 10 bits
    assign new_stream_engines = 16'h000 | new_stream_i;

    // Fifo that takes in write requests that correspond to new stream bits
    test_write_request_fifo u_test_write_request_fifo (
        .clk(clk_i),                   // input wire clk
        .srst(rst_i),                  // input wire srst
        .din(new_stream_engines),      // input wire [15 : 0] din
        .wr_en(|new_stream_i),         // input wire wr_en
        .rd_en(fill_fifo_state == process_data & fill_fifo_state_n == wait_data),  // input wire rd_en
        .dout(request_streams),        // output wire [15 : 0] dout
        .full(),                       // output wire full
        .empty(write_request_empty)    // output wire empty
    );

    // Fifo with decoded data
    u_stream_data_decoded u1_stream_data_decoded (
        .a(address_counter),      // input wire [9 : 0] a
        .spo(check_data)          // output wire [127 : 0] spo
    );

    // Combines requests with when the check data is valid to deliver it to correct engine
    assign request_streams_valid = request_streams & {16{check_data_valid}};

    genvar i;

    // Debug signals
    logic [ENGINE_NUM-1:0][7:0]  tag_check;
    logic [ENGINE_NUM-1:0][7:0]  tag_data;
    logic [ENGINE_NUM-1:0][5:0]  ccol_check;
    logic [ENGINE_NUM-1:0][5:0]  ccol_data;
    logic [ENGINE_NUM-1:0][7:0]  qrow_check;
    logic [ENGINE_NUM-1:0][7:0]  qrow_data;
    logic [ENGINE_NUM-1:0][15:0] hitmap_check;
    logic [ENGINE_NUM-1:0][15:0] hitmap_data;

    // Checks if fifo has checked data ready to compare to engine
    assign check_fifo_ready_o = ~check_fifo_empty;

    // Block for generating check fifos per engine with additional debug logic
    generate
        for(i = 0; i < ENGINE_NUM; i++) begin
            fifo_stream_checker u_fifo_stream_checker (
                .clk(clk_i),                                        // input wire clk
                .srst(rst_i),                                       // input wire srst
                .din(check_data),                                   // input wire [127 : 0] din
                .wr_en(request_streams_valid[i]),                   // input wire wr_en
                .rd_en(engine_valid_i[i] & check_fifo_ready_o[i]),  // input wire rd_en
                .dout(checked_data_o[i]),                           // output wire [127 : 0] dout
                .full(),                                            // output wire full
                .empty(check_fifo_empty[i])                         // output wire empty
            );

            // Data format for output
            //  [127:102]  [101:94]     [93:88]      [87:80]        [79:64]        [63:0]
            //  {26'h0, tag_reg_flip, ccol_reg_flip, qrow_reg_flip, decoded_hitmap, tot_reg_flip};
            assign tag_check[i]    = checked_data_o[i][101:94];
            assign ccol_check[i]   = checked_data_o[i][93:88];
            assign qrow_check[i]   = checked_data_o[i][87:80];
            assign hitmap_check[i] = checked_data_o[i][79:64];

            assign tag_data[i]    = decoded_data_i[i][101:94];
            assign ccol_data[i]   = decoded_data_i[i][93:88];
            assign qrow_data[i]   = decoded_data_i[i][87:80];
            assign hitmap_data[i] = decoded_data_i[i][79:64];


            assign error_flag[0][i] = (tag_check[i] != tag_data[i]) & (engine_valid_i[i] & check_fifo_ready_o[i]);
            assign error_flag[1][i] = (ccol_check[i] != ccol_data[i]) & (engine_valid_i[i] & check_fifo_ready_o[i]);
            assign error_flag[2][i] = (qrow_check[i] != qrow_data[i]) & (engine_valid_i[i] & check_fifo_ready_o[i]);
            assign error_flag[3][i] = (hitmap_check[i] != hitmap_data[i]) & (engine_valid_i[i] & check_fifo_ready_o[i]);
        end
    endgenerate

    assign err_signals[0] = |error_flag[0];
    assign err_signals[1] = |error_flag[1];
    assign err_signals[2] = |error_flag[2];
    assign err_signals[3] = |error_flag[3];

endmodule