-------------------------------------------------------------------------------
-- File       : stream_distrib.vhd
-------------------------------------------------------------------------------
-- [Filename]       stream_distrib.vhd [RTL]
-- [Project]        Stream Decoder for RD53B data in an FPGA
-- [Author]         
-- [Language]       VHDL
-- [Created]        
-- [Description]    Distribute a series of streams to different instances of the decoder
-- 
-- 
-- Input is over a 63-bit bus with a 'ns' (new stream) bit
-- The 
-- Data is initially buffered in a FIFO and then read out into a shift register (sreg) whenever the register
-- has space for 63 new bits. Initially 3 words are read into sreg[188:126], sreg[125:63] and sreg[62:0]
-- After each hit is decoded, from the sreg MSBs, we check to see if the 
-- sreg can be shifted left by 63 bits so that a new word can be read from the input FIFO.
-- Shifts can only occur in blocks of 63. The sreg_ptr keeps track of where the next hits address field starts.
-- The sreg_ptr starts at sreg[188]. If a 10-bit hit is consumed then sreg_ptr will be moved to (188-10) 178.
-- A second hit of 42 bits (say) will move the pointer to (178-48) 136.
-- A third hit of 31 bits (say) will move the pointer to 105. Once the pointer is below (188-63) = 125 then
-- sreg will be shifted left by 63 bits, a new word will be read from the FIFO into sreg[62:0] and the pointer
-- moves to (105+63) 168.  This is the location of the MSB of the next address block. 
--
-- If the MSBs are 6, or more, zeros then there are no more hits and this marks the end of the stream.
-- *** Internal (11-bit beginning "111") internal tags are not currently supported
-------------------------------------------------------------------------------
library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;

entity stream_distrib is
generic (
    G_NUM_CHAN      : in    integer                         -- Number of decode engine channels 1-8
);
port (
    reset           : in    std_logic;
    clk             : in    std_logic;

    busy            : out   std_logic;                      -- Status. Set once a 'NS=1' is seen. Cleared when end of stream is detected
    errors          : out   std_logic_vector( 1 downto 0);  -- Status. FIFO overflow, decoder unavailable

    -- Encoded stream data input from hit generator
    din             : in    std_logic_vector(62 downto 0);  -- Input encoded stream data
    din_ns          : in    std_logic;                      -- NS (new_stream) bit
    din_dv          : in    std_logic;                      -- Data valid
    din_ready       : out   std_logic;                      -- Set low when input FIFO approaches full

    -- Stream outputs to decoders. Only one channel is active at a time
    dout            : out   std_logic_vector(62 downto 0);  -- Input encoded stream data
    dout_ns         : out   std_logic;                      -- NS (new_stream) bit
    dout_chan       : out   std_logic_vector( 2 downto 0);  -- Encoded data channel number (0-7)
    dout_dv         : out   std_logic;                      -- Data valid

    -- Un-encoded event generator data from hit generator, for comparison with data after decoding 
    hit_eos         : in    std_logic;  
    hit_eoe         : in    std_logic; 
    hit_qrow        : in    std_logic_vector( 7 downto 0); 
    hit_ccol        : in    std_logic_vector( 5 downto 0); 
    hit_hitmap      : in    std_logic_vector(15 downto 0); 
    hit_dv          : in    std_logic;                      -- Expected data valid

    hit_tot         : in    std_logic_vector(63 downto 0);  -- ToT data packed into MSBs of bus
    hit_tot_size    : in    std_logic_vector( 6 downto 0);
    hit_tot_dv      : in    std_logic;                      -- Expected ToT data valid. ToT data is delayed from other expected data.

    -- Un-encoded event generator data to hit_checkers for comparison with data after decoding 
    exp_eos         : out   std_logic;  
    exp_eoe         : out   std_logic; 
    exp_qrow        : out   std_logic_vector( 7 downto 0); 
    exp_ccol        : out   std_logic_vector( 5 downto 0); 
    exp_hitmap      : out   std_logic_vector(15 downto 0); 
    exp_chan        : out   std_logic_vector( 2 downto 0);  -- Encoded data channel number (0-7)
    exp_dv          : out   std_logic;                      -- Expected data valid

    exp_tot         : out   std_logic_vector(63 downto 0);  -- ToT data packed into MSBs of bus
    exp_tot_size    : out   std_logic_vector( 6 downto 0);
    exp_tot_dv      : out   std_logic;                      -- Expected ToT data valid. ToT data is delayed from other expected data.
);
end stream_distrib;

architecture rtl of stream_distrib is

-- State machine variable for selecting decode engines
type t_state  is (
    S_IDLE          ,   -- Waiting for a new stream. Load first word into reg_shift
    S_EOS
);
signal state                : t_state;  
signal sm_rd_fifo           : std_logic; 
signal start_sm             : std_logic; 

-- Expected (un-encoded hit data) is written into FIFOs. These are needed 
-- because the encoded data is delayed and the distributor has not chosen a channel when the
-- expected data is received.
-- One FIFO for hit map,addr, and one for ToT data since it is delayed by a few cycles
-- Both FIFOs can be read simultaneously to align the two types of data for the hit_checker blocks
signal hit_fifo_din        : std_logic_vector(XX downto 0);
signal hit_fifo_dout       : std_logic_vector( downto 0);
signal hit_fifo_uflow      : std_logic;
signal hit_fifo_oflow      : std_logic;
signal hit_fifo_full       : std_logic;
signal hit_fifo_empty      : std_logic;
signal hit_fifo_prog_full  : std_logic;
signal hit_fifo_level      : std_logic_vector( 9 downto 0);

begin      
    
    start_sm        <= '1';
    fifo_ibuf_din  <= din_ns & din; 

    -----------------------------------------------------------
    -- 64b x 512 FIFO buffer for 63-bit input data and NS flag
    -- This FIFO should be reduced in size if possible. (8K bits?)
    -----------------------------------------------------------
    u_fifo_buf : entity work.fifo_512x64b
    port map(
        clk         => clk                      ,
        srst        => reset                    ,
        din         => fifo_ibuf_din            ,   -- input wire [63 : 0] din
        wr_en       => din_dv                   ,

        rd_en       => sm_rd_fifo               , 
        dout        => fifo_ibuf_dout           ,   -- output wire [63 : 0] dout
        
        underflow   => fifo_ibuf_uflow           ,
        overflow    => fifo_ibuf_oflow           ,
        full        => fifo_ibuf_full            ,
        empty       => fifo_ibuf_empty           ,
        data_count  => fifo_ibuf_level               -- Number of words stored in FIFO

    );
    -- Errors
    errors(0)   <= fifo_ibuf_uflow;
    errors(1)   <= fifo_ibuf_oflow;


    -----------------------------------------------------------------------------------
    -- FIFO data is read into a shift reg that can hold 3x 63-bit words (188:0)
    -- Initially 3 words are read into the buffer and a pointer is set to bit 188. 
    -- The first word in [188:126], the second into [125:63] and the third into [62:0].
    -- As variable sized chunks of data are decoded the pointer is moved down the buffer.
    -- The data is shifted 63 bits left in the buffer (MSB-wards)and FIFO data is read 
    -- into the LSBs when the current buffer pointer value is past the most significant
    -- 63 bits i.e. < 126
    -- The buffer pointer will then also be increased by 63.
    -- Initial buffer pointer, maintained by s.m.,  is 188
    -----------------------------------------------------------------------------------
    -- State machine to maintain the shift reg and current data pointer.
    -- Sends encoded hit data to the decoder block. 
    -- Parses the address fields.
    -- Outputs the ToT bits
    -- Detects 'end-of-stream' (6 zeros) in the S_ADDR state.
    -----------------------------------------------------------------------------------
    pr_sm : process (reset, clk)
    variable v_orphans  : std_logic_vector( 5 downto 0);
    begin
        if (reset='1') then
            state           <= S_IDLE;
            sm_rd_fifo      <= '0';

        elsif rising_edge(clk) then

            sm_rd_fifo  <= '0';

            case state is

                ------------------------------------------------
                -- Wait for the start of a new stream. The 'start_sm' bit allows
                -- multiple engines to be offset from each other. (Future feature)
                --  Load first word into sreg
                --  Capture ch_id, tag and first hit address fields
                --  Detect EOS
                ------------------------------------------------
                when S_IDLE   =>
                
                    busy        <= '0';

                    if (fifo_ibuf_empty = '0') and (fifo_ibuf_dout(63) = '1') and (start_sm = '1') then 

                        sreg(188 downto 126)    <= fifo_ibuf_dout(62 downto 0);
                        sm_rd_fifo              <= '1';
                        
                        busy    <= '1';
                        
                    else
                        -- Read words from FIFO that do not have NS bit set. Junk?
                        if (fifo_ibuf_empty = '0') and (fifo_ibuf_dout(63) = '0') then 
                            sm_rd_fifo  <= '1';
                        else
                            sm_rd_fifo  <= '0';
                        end if;
                        
                        ptr_sreg    <= 188;
                        sreg        <= (others=>'0');
                        dout_eos    <= '0';

                    end if;


                ------------------------------------------------
                -- Wait for decoder output pipeline delay.
                -- Check to see if ptr_sreg is below the shift point so that 
                -- sreg can be shifted and loaded with another word from the FIFO
                ------------------------------------------------
                when S_WAIT_DEC =>


                ------------------------------------------------
                -- End of stream (TODO Prob. remove this state)
                ------------------------------------------------
                when S_EOS  =>
                    state       <= S_IDLE;
                    dout_eos    <= '0';
                    dbg_6zeros  <= sreg(ptr_sreg downto ptr_sreg-5);


                when others =>
                    state   <= S_IDLE;

            end case;

        end if;

    end process;


    -----------------------------------------------------------------------------------
    -- Hitmap Decoder 
    -- (4 to 30 bits of input hitmap decoded into an output 16-bit field with its number
    -- of bits set and also the actual length of the original input hitmap
    -----------------------------------------------------------------------------------
    u_hitdecode2 : entity work.hitdecode2 
    port map(
        clk                 => clk                  ,  -- input                        
        reset               => reset                ,  -- input                        

        reg_en_encode       => reg_en_encode        ,  -- input                        

        data_in             => dh_din               ,  -- input   [29:0]              Contains input hitmap in MSBs. Actual size is unknown. 5 bits min, 30 bits max
        data_in_chan        => dh_din_chan          ,  -- input   [ 3:0]              Channel number of input hitmap data
        data_in_dv          => dh_din_dv            ,  -- input                       Input data valid

        hitmap_out          => dh_hitmap_out        ,  -- output  reg [15:0]          Decoded hitmap
        hitmap_length       => dh_hitmap_length     ,  -- output  reg [ 4:0]          Actual length of the compressed input hitmap (4 to 30)
        hitmap_nbits        => dh_hitmap_nbits      ,  -- output  reg [ 4:0]          Number of bits set in the decoded hitmap. (1 to 16)
        hitmap_out_chan     => dh_hitmap_out_chan   ,  -- output  reg [ 3:0]          Channel number of output hitmap
        hitmap_out_dv       => dh_hitmap_out_dv        -- output  reg                 Output data valid
    );


    -----------------------------------------------------------------------------------
    -- Output registers. 
    -- Mask ToT bits that do not contain valid data
    -----------------------------------------------------------------------------------
    pr_dout : process (reset, clk)
    begin
        if (reset='1') then

            dout_chip_id    <= (others=>'0'); 
            dout_tag        <= (others=>'0');
            dout_ccol       <= (others=>'0');
            dout_qrow       <= (others=>'0');
            dout_hitmap     <= (others=>'0');
            dout_tot        <= (others=>'0');
            dout_eoe        <= '0';
          --dout_eos        <= '0'; -- Set directly in state machine process to avoid an additional clock delay
            dout_dv         <= '0';

        elsif rising_edge(clk) then

            -- Output all of the collected fields/bits
            if (state = S_ADDR) then
                
                dout_chip_id    <= reg_chip_id; 
                dout_tag        <= reg_tag;
                dout_ccol       <= reg_ccol;
                dout_qrow       <= reg_qrow;
                dout_hitmap     <= reg_hitmap;
                dout_dv         <= '1';
                
                -- Zero out the unused parts of the ToT bus
                case to_integer(unsigned(reg_hitmap_nbits)) is

                    when  1     =>  dout_tot    <= reg_tot(63 downto 60) & X"000000000000000";
                    when  2     =>  dout_tot    <= reg_tot(63 downto 56) & X"00000000000000";
                    when  3     =>  dout_tot    <= reg_tot(63 downto 52) & X"0000000000000";
                    when  4     =>  dout_tot    <= reg_tot(63 downto 48) & X"000000000000";
                    when  5     =>  dout_tot    <= reg_tot(63 downto 44) & X"00000000000";
                    when  6     =>  dout_tot    <= reg_tot(63 downto 40) & X"0000000000";
                    when  7     =>  dout_tot    <= reg_tot(63 downto 36) & X"000000000";
                    when  8     =>  dout_tot    <= reg_tot(63 downto 32) & X"00000000";
                    when  9     =>  dout_tot    <= reg_tot(63 downto 28) & X"0000000";
                    when 10     =>  dout_tot    <= reg_tot(63 downto 24) & X"000000";
                    when 11     =>  dout_tot    <= reg_tot(63 downto 20) & X"00000";
                    when 12     =>  dout_tot    <= reg_tot(63 downto 16) & X"0000";
                    when 13     =>  dout_tot    <= reg_tot(63 downto 12) & X"000";
                    when 14     =>  dout_tot    <= reg_tot(63 downto  8) & X"00";
                    when 15     =>  dout_tot    <= reg_tot(63 downto  4) & X"0";
                    when 16     =>  dout_tot    <= reg_tot(63 downto  0);
                    when others =>  dout_tot    <= (others=>'0');

                end case;

            else

                dout_chip_id    <= (others=>'0'); 
                dout_tag        <= (others=>'0');
                dout_ccol       <= (others=>'0');
                dout_qrow       <= (others=>'0');
                dout_hitmap     <= (others=>'0');
                dout_tot        <= (others=>'0');
                dout_eoe        <= '0';
                dout_dv         <= '0';

            end if;

        end if;

    end process;


    -----------------------------------------------------------------------------------
    -- Signal to hitmaker when decoding input FIFO is getting full
    -----------------------------------------------------------------------------------
    pr_ready : process (reset, clk)
    begin
        if (reset='1') then
            ready   <= '0';

        elsif rising_edge(clk) then

            if (unsigned(fifo_ibuf_level) < 256) then   
                ready         <= '1';

            elsif (unsigned(fifo_ibuf_level) > 400) then    -- Back pressure to hitmaker
                ready         <= '0';

            else
                ready         <= '1';

            end if;

        end if;

    end process;

end rtl;

