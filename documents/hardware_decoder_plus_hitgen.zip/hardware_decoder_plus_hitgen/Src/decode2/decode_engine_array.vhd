-------------------------------------------------------------------------------
-- File       : decode_engine_2.vhd
-------------------------------------------------------------------------------
-- [Filename]       decode_engine_2.vhd [RTL]
-- [Project]        Stream Decoder for RD53B data in an FPGA
-- [Author]         
-- [Language]       VHDL
-- [Created]        
-- [Description]    Decode a single stream of compressed/encoded addresses, hitmaps, ToTs.
-- 
-- Address length can vary between 2,8,10,16.
-- Encoded hitmap length can vary from 4 to 30 bits
-- ToT length can vary from 4 to 64 bits in steps of 4.
-- Min encoded hit length is 2+4+4 = 10.
-- Max encoded hit length is 16+30+64 = 110.
-- 
-- Input is over a 63-bit bus. 
-- Data is initially buffered in a FIFO and then read out into a shift register (sreg) whenever the register
-- has space for 63 new bits. Initially 3 words are read into sreg[188:126], sreg[125:63] and sreg[62:0]
-- After each hit is decoded, from the sreg MSBs, we check to see if the 
-- sreg can be shifted left by 63 bits so that a new word can be read from the input FIFO.
-- Shifts can only occur in blocks of 63. The sreg_ptr keeps track of where the next hits address field starts.
-- The sreg_ptr starts at sreg[188]. If a 10-bit hit is consumed then sreg_ptr will be moved to (188-10) 178.
-- A second hit of 42 bits (say) will move the pointer to (178-48) 136.
-- A third hit of 31 bits (say) will move the pointer to 105. Once the pointer is below (188-63) = 125 then
-- sreg will be shifted left by 63 bits, a new word will be read from the FIFO into sreg[62:0] and the pointer
-- moves to (105+63) 168.  This is the location of the MSB of the next address block. 
--
-- If the MSBs are 6, or more, zeros then there are no more hits and this marks the end of the stream.
-- *** Internal (11-bit beginning "111") internal tags are not currently supported
-------------------------------------------------------------------------------
library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;

entity decode_engine_arr is
generic ( 
    G_ENG           : integer := 8;         -- Number of decode engines sharing one decoder ROM. MAX = 8
);
port (
    reset           : in    std_logic;
    clk             : in    std_logic;

    arr_busy        : out   std_logic_vector(G_ENG-1 downto 0);     -- Status. Set once a 'NS=1' is seen. Cleared when end of stream is detected
    arr_ready       : out   std_logic_vector(G_ENG-1 downto 0);     -- Set low when input FIFO approaches full
    arr_errors      : out   std_logic_vector((2*G_ENG)-1 downto 0); -- Status. FIFO overflow, underflow.

    -- Options. '1' to enable. Common to all engines
    reg_en_chip_id  : in    std_logic;                              -- '1' means that channel_id is in stream immediately after NS
    reg_en_encode   : in    std_logic;                              -- '1' means that hitmap is encoded. '0' = Always 16 bits
    reg_en_tot      : in    std_logic;                              -- '1' means that  there are ToT values in the data
    reg_en_eos      : in    std_logic;                              -- '1'  Enable min 6 zeros output to mark end of stream

    -- Encoded data input. Single stream. 'din_chan' identifies the engine number
    din             : in    std_logic_vector(62 downto 0);          -- Input encoded stream data
    din_ns          : in    std_logic;                              -- NS (new_stream) bit
    din_chan        : in    std_logic_vector( 2 downto 0);          -- Encoded data channel number (0-7)
    din_dv          : in    std_logic;                              -- Data valid

    -- Data identification outputs. single stream. 'dout_chan' identifies the engine number
    dout_chan       : out   std_logic_vector( 2 downto 0);          -- Channel number to identify the stream of the other dout signals
    dout_chip_id    : out   std_logic_vector( 1 downto 0);          -- Channel ID captured from beginning of data stream (optional)
    dout_tag        : out   std_logic_vector( 7 downto 0);          -- Tag 8-bit captured from beginning of data stream
    dout_eos        : out   std_logic;
    dout_eoe        : out   std_logic;

    -- Decoded hit fields 
    dout_ccol       : out   std_logic_vector( 5 downto 0);
    dout_qrow       : out   std_logic_vector( 7 downto 0);
    dout_hitmap     : out   std_logic_vector(15 downto 0);
    dout_tot        : out   std_logic_vector(63 downto 0);
    dout_dv         : out   std_logic 
);
end decode_engine_arr;

architecture rtl of decode_engine_arr is

type t_arr_slv2               is array (0 to G_ENG-1) of std_logic_vector( 1 downto 0);
type t_arr_slv3               is array (0 to G_ENG-1) of std_logic_vector( 2 downto 0);
type t_arr_slv4               is array (0 to G_ENG-1) of std_logic_vector( 3 downto 0);
type t_arr_slv5               is array (0 to G_ENG-1) of std_logic_vector( 4 downto 0);
type t_arr_slv6               is array (0 to G_ENG-1) of std_logic_vector( 5 downto 0);
type t_arr_slv8               is array (0 to G_ENG-1) of std_logic_vector( 7 downto 0);
type t_arr_slv10              is array (0 to G_ENG-1) of std_logic_vector( 9 downto 0);
type t_arr_slv16              is array (0 to G_ENG-1) of std_logic_vector(15 downto 0);
type t_arr_slv30              is array (0 to G_ENG-1) of std_logic_vector(29 downto 0);
type t_arr_slv64              is array (0 to G_ENG-1) of std_logic_vector(63 downto 0);

-- Input FIFO I/O
signal fifo_ibuf_wr         : std_logic_vector(G_ENG-1 downto 0);
signal fifo_ibuf_din        : std_logic_vector(63 downto 0);
signal fifo_ibuf_dout       : t_arr_slv64;          -- array of std_logic_vector(63 downto 0);
signal fifo_ibuf_uflow      : std_logic_vector(G_ENG-1 downto 0);
signal fifo_ibuf_oflow      : std_logic_vector(G_ENG-1 downto 0);
signal fifo_ibuf_full       : std_logic_vector(G_ENG-1 downto 0);
signal fifo_ibuf_empty      : std_logic_vector(G_ENG-1 downto 0);
signal fifo_ibuf_level      : t_arr_slv10;          -- array of std_logic_vector( 9 downto 0);

-- Register for each channel to hold up to three words read from each FIFO.  3 x 63 = 189
-- An encoded 'hit' can be as short as 10 bits and as long as 110
constant  C_SIZE_SREG       : integer := 3*63;     
signal t_arr_sreg             is array (0 to G_ENG-1) of  std_logic_vector(C_SIZE_SREG-1 downto 0);
signal arr_sreg             : t_arr_sreg;           --  array of std_logic_vector(C_SIZE_SREG-1 downto 0);

-- State machine variable for updating sreg, ptr_sreg
type t_state  is (
    S_IDLE          ,   -- Waiting for a new stream. Load first word into reg_shift
    S_WAIT_INIT0    ,   -- Load MSBs of sreg
    S_INIT0         ,   -- Load MSBs of sreg
    S_WAIT_INIT1    ,   -- Load middle of sreg
    S_INIT1         ,   -- Load MSBs of sreg
    S_INIT2         ,   -- Load LSBs of sreg
    S_ADDR          ,   -- Decode the address field (ccol, islast, isneighbor, qrow)
    S_WAIT_DEC      ,   -- Wait N clock cycles for 30-bit encoded hit data to be decoded 
    S_TOT           ,   -- Extract ToT bits. Update reg_shift and ptr_shift 
    S_EOS
);
-- A this block will handles the decoding of multiple streams with one ROM decoder
type   t_arr_state            is array (G_ENG-1 downto 0) of t_state;
signal arr_state            : t_arr_state;

constant  C_PIPELEN_DECODE  : integer := 5;                                                     -- Length of hitmap decoder pipeline
type   t_arr_sm_cnt           is array (0 to G_ENG-1) of integer range 0 to C_PIPELEN_DECODE;   -- Counter used in state machine for decoder pipeline delay
signal arr_sm_cnt           : t_arr_sm_cnt;                                                     -- Counter used in state machine for decoder pipeline delay

type   t_arr_ptr_sreg         is array (0 to G_ENG-1) of integer range 0 to 188;                -- Pointer to current decode point. Updated by state machine
signal arr_ptr_sreg         : t_arr_ptr_sreg;                                                   -- Pointer to current decode point. Updated by state machine

type   t_arr_nbits_tot        is array (0 to G_ENG-1) of integer range 0 to 64;                 -- Number of bits in ToT field
signal arr_nbits_tot        : t_arr_nbits_tot;                                                  -- Number of bits in ToT field

signal arr_is_last          : std_logic_vector(G_ENG-1 downto 0); 
signal arr_is_neighbor      : std_logic_vector(G_ENG-1 downto 0); 
signal arr_sm_rd_fifo       : std_logic_vector(G_ENG-1 downto 0); 
signal arr_start_sm         : std_logic_vector(G_ENG-1 downto 0);   -- Enable ?

-- Interface to hitmap decoder from each state machine
signal arr_dh_din           : t_arr_slv30;                          -- array of std_logic_vector(29 downto 0);    --  Contains input hitmap in MSBs. Actual size is unknown. 5 bits min, 30 bits max
signal arr_dh_din_chan      : t_arr_slv4;                           -- array of std_logic_vector( 3 downto 0);    -- Channel number of input hitmap data
signal arr_dh_din_dv        : std_logic_vector(G_ENG-1 downto 0);   -- Input data valid
-- Out
signal arr_dh_hitmap_out    : t_arr_slv16;                          -- Decoded hitmap
signal arr_dh_hitmap_length : t_arr_slv5;                           -- Actual length of the compressed input hitmap (4 to 30)
signal arr_dh_hitmap_nbits  : t_arr_slv5;                           -- Number of bits set in the decoded hitmap. (1 to 16)
signal arr_dh_hitmap_out_chan : t_arr_slv4;                         -- Channel number of output hitmap
signal arr_dh_hitmap_out_dv : std_logic_vector(G_ENG-1 downto 0);                        -- Output data valid

-- Common interface to hitmap decoder. 
signal dh_din               : std_logic_vector(29 downto 0);        -- Contains input hitmap in MSBs. Actual size is unknown. 5 bits min, 30 bits max
signal dh_din_chan          : std_logic_vector( 3 downto 0);        -- Channel number of input hitmap data
signal dh_din_dv            : std_logic;                            -- Input data valid
-- Out
signal dh_hitmap_out        : std_logic_vector(15 downto 0);        -- Decoded hitmap
signal dh_hitmap_length     : std_logic_vector( 4 downto 0);        -- Actual length of the compressed input hitmap (4 to 30)
signal dh_hitmap_nbits      : std_logic_vector( 4 downto 0);        -- Number of bits set in the decoded hitmap. (1 to 16)
signal dh_hitmap_out_chan   : std_logic_vector( 3 downto 0);        -- Channel number of output hitmap
signal dh_hitmap_out_dv     : std_logic;                            -- Output data valid


-- Registers to hold outputs from address, hitmap and ToT decoding
signal arr_reg_chip_id      : t_arr_slv2;           -- array of std_logic_vector( 1 downto 0);    -- Captured at beginning of the stream (opt)
signal arr_reg_tag          : t_arr_slv8;           -- array of std_logic_vector( 7 downto 0);    -- Captured at beginning of the stream
signal arr_reg_ccol         : t_arr_slv6;           -- array of std_logic_vector( 5 downto 0);
signal arr_reg_qrow         : t_arr_slv8;           -- array of std_logic_vector( 7 downto 0);
signal arr_reg_hitmap       : t_arr_slv16;          -- array of std_logic_vector(15 downto 0);
signal arr_reg_tot          : t_arr_slv64;          -- array of std_logic_vector(63 downto 0);
signal arr_reg_hitmap_nbits : t_arr_slv5;           -- array of std_logic_vector( 4 downto 0);    --  Number of bits set in the decoded hitmap. (1 to 16)

signal arr_dbg_6zeros       : t_arr_slv6;           -- array of std_logic_vector( 5 downto 0);

-- Data identification outputs. single stream. 'dout_chan' identifies the engine number
signal arr_dout_chan        : t_arr_slv3;                           -- array of std_logic_vector( 2 downto 0); ** TODO Replace with counter ??`
signal arr_dout_eos         : std_logic_vector(G_ENG-1 downto 0);
signal arr_dout_eoe         : std_logic_vector(G_ENG-1 downto 0);

-- Decoded hit fields 
signal arr_dout_ccol       : t_arr_slv6;                             -- array of std_logic_vector( 5 downto 0);
signal arr_dout_qrow       : t_arr_slv8;                             -- array of std_logic_vector( 7 downto 0);
signal arr_dout_hitmap     : t_arr_slv16;                            -- array of std_logic_vector(15 downto 0);
signal arr_dout_tot        : t_arr_slv64;                            -- array of std_logic_vector(63 downto 0);
signal arr_dout_dv         : std_logic_vector(G_ENG-1 downto 0) 

begin      
    
    -- Enable all channels
    arr_start_sm    <= (others=>'1');


    -----------------------------------------------------------
    -- Process to write incoming stream data to the correct input FIFO
    -----------------------------------------------------------
    pr_sm : process (reset, clk)
    begin
        if (din_dv = '1') then

            fifo_ibuf_din   <= din_ns & din; 
            
            case din_chan is
                when "000"  =>  fifo_ibuf_wr        <= (0 => '1', others=>'0'); 
                when "001"  =>  fifo_ibuf_wr        <= (1 => '1', others=>'0'); 
                when "010"  =>  fifo_ibuf_wr        <= (2 => '1', others=>'0'); 
                when "011"  =>  fifo_ibuf_wr        <= (3 => '1', others=>'0'); 
                when "100"  =>  fifo_ibuf_wr        <= (4 => '1', others=>'0'); 
                when "101"  =>  fifo_ibuf_wr        <= (5 => '1', others=>'0'); 
                when "110"  =>  fifo_ibuf_wr        <= (6 => '1', others=>'0'); 
                when others =>  fifo_ibuf_wr        <= (7 => '1', others=>'0'); 
            end case;
        else
            fifo_ibuf_wr        <= (others=>'0'); 
        end if;

    end process;


    -----------------------------------------------------------
    -- 64b x 512 FIFO buffer for 63-bit input data and NS flag
    -- One buffer per channel (stream)
    -- This FIFO should be reduced in size if possible. (8K bits?)
    -----------------------------------------------------------
    gen_ififos : for N in 0 to G_ENG-1 generate
        
        u_fifo_buf : entity work.fifo_512x64b
        port map(
            clk         => clk                      ,
            srst        => reset                    ,
            din         => fifo_ibuf_din            ,   -- input wire [63 : 0] din (common)
            wr_en       => fifo_ibuf_wr(N)          ,

            rd_en       => arr_sm_rd_fifo(N)        , 
            dout        => fifo_ibuf_dout(N)        ,   -- output wire [63 : 0] dout
        
            underflow   => fifo_ibuf_uflow(N)       ,
            overflow    => fifo_ibuf_oflow(N)       ,
            full        => fifo_ibuf_full(N)        ,
            empty       => fifo_ibuf_empty(N)       ,
            data_count  => fifo_ibuf_level(N)           -- Number of words stored in FIFO
        );

        -- Errors
        errors(N)       <= fifo_ibuf_uflow(N);
        errors(G_ENG+N) <= fifo_ibuf_oflow(N);

    end generate;


    -----------------------------------------------------------------------------------
    -- FIFO data is read into a shift reg that can hold 3x 63-bit words (188:0)
    -- Initially 3 words are read into the buffer and a pointer is set to bit 188. 
    -- The first word in [188:126], the second into [125:63] and the third into [62:0].
    -- As variable sized chunks of data are decoded the pointer is moved down the buffer.
    -- The data is shifted 63 bits left in the buffer (MSB-wards)and FIFO data is read 
    -- into the LSBs when the current buffer pointer value is past the most significant
    -- 63 bits i.e. < 126
    -- The buffer pointer will then also be increased by 63.
    -- Initial buffer pointer, maintained by s.m.,  is 188
    -----------------------------------------------------------------------------------
    -- State machine to maintain the shift reg and current data pointer.
    -- Sends encoded hit data to the decoder block. 
    -- Parses the address fields.
    -- Outputs the ToT bits
    -- Detects 'end-of-stream' (6 zeros) in the S_ADDR state.
    -----------------------------------------------------------------------------------
    gen_sm : for N in 0 to G_ENG-1 generate

        pr_sm : process (reset, clk)
        variable v_orphans  : std_logic_vector( 5 downto 0);
        begin
            if (reset='1') then
                arr_state(N)            <= S_IDLE;
                arr_sm_rd_fifo(N)       <= '0';
                arr_ptr_sreg(N)         <= 188;
                arr_sreg(N)             <= (others=>'0');

                arr_is_neighbor(N)      <= '0';
                arr_is_last(N)          <= '0';

                
                arr_dh_din(N)           <= (others=>'0');
                arr_dh_din_chan(N)      <= (others=>'0');
                arr_dh_din_dv(N)        <= '0';

                arr_reg_chip_id(N)      <= (others=>'0'); 
                arr_reg_tag(N)          <= (others=>'0');
                arr_reg_ccol(N)         <= (others=>'0');
                arr_reg_qrow(N)         <= (others=>'0');
                arr_reg_hitmap(N)       <= (others=>'0');
                arr_reg_hitmap_nbits(N) <= (others=>'0');
                arr_reg_tot(N)          <= (others=>'0');
                arr_dbg_6zeros(N)       <= "XXXXXX";
                arr_dout_eos(N)         <= '0';

            elsif rising_edge(clk) then

                arr_dh_din_dv(N)        <= '0'; 
                arr_sm_rd_fifo(N)       <= '0';

                case arr_state(N) is

                    ------------------------------------------------
                    -- Wait for the start of a new stream. 
                    --  Load first word into sreg
                    --  Capture ch_id, tag and first hit address fields
                    --  Detect EOS
                    ------------------------------------------------
                    when S_IDLE   =>
                
                        arr_busy(N)         <= '0';

                        if (fifo_ibuf_empty(N) = '0') and (fifo_ibuf_dout(N)(63) = '1') and (arr_start_sm(N) = '1') then 

                            arr_sreg(N)(188 downto 126) <= fifo_ibuf_dout(N)(62 downto 0);
                            arr_sm_rd_fifo(N)           <= '1';
                        
                            if (reg_en_chip_id = '1') then
                                arr_reg_chip_id(N)  <= fifo_ibuf_dout(N)(62 downto 61);
                                arr_reg_tag(N)      <= fifo_ibuf_dout(N)(60 downto 53);
                                v_orphans           := fifo_ibuf_dout(N)(52 downto 47);     -- Six zeros marks end of stream

                                arr_reg_ccol(N)     <= fifo_ibuf_dout(N)(52 downto 47);
                                arr_is_neighbor(N)  <= fifo_ibuf_dout(N)(46);
                                arr_is_last(N)      <= fifo_ibuf_dout(N)(45);
                                arr_reg_qrow(N)     <= fifo_ibuf_dout(N)(44 downto 37);
                                arr_ptr_sreg(N)     <= 188-26;  -- 26-bit header if chan_id included
                            else
                                arr_reg_chip_id(N)  <= (others=>'0');
                                arr_reg_tag(N)      <= fifo_ibuf_dout(N)(62 downto 55);
                                v_orphans           := fifo_ibuf_dout(N)(54 downto 49);     -- Six zeros marks end of stream
                            
                                arr_reg_ccol(N)     <= fifo_ibuf_dout(N)(54 downto 49);
                                arr_is_neighbor(N)  <= fifo_ibuf_dout(N)(48);
                                arr_is_last(N)      <= fifo_ibuf_dout(N)(47);
                                arr_reg_qrow(N)     <= fifo_ibuf_dout(N)(46 downto 39);
                                arr_ptr_sreg(N)     <= 188-24;  -- 24-bit header if no chan_id
                            end if;
                                                                                              
                            if (v_orphans = "000000") then
                                arr_state(N)        <= S_EOS;
                                arr_dout_eos(N)     <= '1';
                            else    
                                arr_state(N)        <= S_WAIT_INIT0;
                                arr_dout_eos(N)     <= '0';
                            end if;
                            arr_busy(N)     <= '1';
                        
                        else
                            -- Read words from FIFO that do not have NS bit set. Junk?
                            if (fifo_ibuf_empty(N) = '0') and (fifo_ibuf_dout(N)(63) = '0') then 
                                arr_sm_rd_fifo(N)   <= '1';
                            else
                                arr_sm_rd_fifo(N)   <= '0';
                            end if;
                        
                            arr_ptr_sreg(N)     <= 188;
                            arr_sreg(N)         <= (others=>'0');
                            arr_dout_eos(N)     <= '0';

                        end if;

                        arr_dbg_6zeros(N)       <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);


                    when S_WAIT_INIT0   =>
                        arr_state(N)           <= S_INIT0;
                        arr_dbg_6zeros(N)      <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);

                   
                   ------------------------------------------------
                   -- Load second word into sreg
                   ------------------------------------------------
                    when S_INIT0   =>

                        if (fifo_ibuf_empty(N) = '0') then

                            arr_sreg(N)(125 downto 63)      <= fifo_ibuf_dout(N)(62 downto 0);
                            arr_sm_rd_fifo(N)               <= '1';
                            arr_state(N)                    <= S_WAIT_INIT1;

                        else
                            arr_sm_rd_fifo(N)   <= '0';
                        end if;

                        arr_dbg_6zeros(N)   <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);


                    when S_WAIT_INIT1   =>
                        arr_state(N)        <= S_INIT1;
                        arr_dbg_6zeros(N)   <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);
                   
                   ------------------------------------------------
                   -- Load third word into sreg
                   ------------------------------------------------
                    when S_INIT1   =>

                        if (arr_fifo_ibuf_empty(N) = '0') then

                            arr_sreg(N)(62 downto 0)    <= fifo_ibuf_dout(N)(62 downto 0);
                            arr_sm_rd_fifo(N)           <= '1';

                            -- Send 30-bit encoded hitmap to decoder
                            arr_dh_din(N)       <= arr_sreg(N)(arr_ptr_sreg(N) downto (arr_ptr_sreg(N)-29));
                            arr_dh_din_chan(N)  <= (others=>'0');
                            arr_dh_din_dv(N)    <= '1';
                            arr_sm_cnt(N)       <= 0;
                            arr_state(N)        <= S_WAIT_DEC;      -- No need to decode address after init. 

                        else
                            arr_sm_rd_fifo(N)   <= '0';
                        end if;

                        arr_dbg_6zeros(N)   <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);


                    ------------------------------------------------
                    -- Decode address fields. 
                    -- EOS if 6 zeros 
                    -- Send next 30 bits to hitmap decoder.
                    -- Update ptr_sreg to MSB of encoded hitmap.
                    ------------------------------------------------
                    when S_ADDR  =>

                        if (arr_is_last(N) = '1') then -- Previous is_last was set so update ccol

                            if (arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5) = "000000") then -- End of sequence marked by six zeros in ccol field
                                arr_state(N)        <= S_EOS;
                                arr_dout_eos(N)     <= '1';
                            else
                                arr_reg_ccol(N)     <= arr_sreg(N)(arr_ptr_sreg(N) downto (arr_ptr_sreg(N)-5));
                                arr_is_last(N)      <= arr_sreg(N)(arr_ptr_sreg(N)-6);
                                arr_is_neighbor(N)  <= arr_sreg(N)(arr_ptr_sreg(N)-7);
                                arr_dout_eos(N)     <= '0';

                                if (arr_sreg(arr_ptr_sreg(N)-7) = '0') then                                -- Update qrow
                                    arr_reg_qrow(N)    <= arr_sreg(N)((arr_ptr_sreg(N)-8)  downto (arr_ptr_sreg(N)-15));
                                    arr_dh_din(N)      <= arr_sreg(N)((arr_ptr_sreg(N)-16) downto (arr_ptr_sreg(N)-16-29)); -- Send 30-bit encoded hitmap to decoder
                                    arr_ptr_sreg(N)    <= arr_ptr_sreg(N) - 16;
                                else    
                                    arr_reg_qrow(N)    <= std_logic_vector(unsigned(arr_reg_qrow(N)) + 1);    -- Increment qrow
                                    arr_dh_din(N)      <= arr_sreg(N)((arr_ptr_sreg(N)-8) downto (arr_ptr_sreg(N)-8-29));   -- Send 30-bit encoded hitmap to decoder
                                    arr_ptr_sreg(N)    <= arr_ptr_sreg(N) - 8;
                                end if;
                        
                                arr_state(N)           <= S_WAIT_DEC;

                            end if;

                        else    -- Keep current ccol. Not in stream

                            arr_is_last(N)     <= arr_sreg(N)(arr_ptr_sreg(N));
                            arr_is_neighbor(N) <= arr_sreg(N)(arr_ptr_sreg(N)-1);
                            arr_dout_eos(N)    <= '0';

                            if (arr_sreg(arr_ptr_sreg-1) = '0') then                                -- Update qrow
                                arr_reg_qrow(N)    <= arr_sreg(N)((arr_ptr_sreg(N)-2)  downto (arr_ptr_sreg(N)-9));
                                arr_dh_din(N)      <= arr_sreg(N)((arr_ptr_sreg(N)-10) downto (arr_ptr_sreg(N)-10-29)); -- Send 30-bit encoded hitmap to decoder
                                arr_ptr_sreg(N)    <= arr_ptr_sreg(N) - 10;
                            else    
                                arr_reg_qrow(N)    <= std_logic_vector(unsigned(arr_reg_qrow(N)) + 1);    -- Increment qrow
                                arr_dh_din(N)      <= arr_sreg((arr_ptr_sreg(N)-2) downto (arr_ptr_sreg(N)-2-29));   -- Send 30-bit encoded hitmap to decoder
                                arr_ptr_sreg(N)    <= arr_ptr_sreg(N) - 2;
                            end if;
                        
                            arr_state(N)    <= S_WAIT_DEC;
                        end if;

                        arr_dbg_6zeros(N)   <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);
                        arr_dh_din_dv(N)    <= '1';


                    ------------------------------------------------
                    -- Wait for decoder output pipeline delay.
                    -- Check to see if ptr_sreg is below the shift point so that 
                    -- sreg can be shifted and loaded with another word from the FIFO
                    ------------------------------------------------
                    when S_WAIT_DEC =>

                        if (arr_sm_cnt(N) = C_PIPELEN_DECODE) then
                            
                            arr_reg_hitmap(N)       <= dh_hitmap_out;                               -- Decoded hitmap
                            arr_nbits_tot(N)        <= 4*to_integer(unsigned(dh_hitmap_nbits));     -- 4*Number of bits set in the decoded hitmap. (1 to 16) -> 4 to 64
                            arr_reg_hitmap_nbits(N) <= dh_hitmap_nbits;
                            arr_ptr_sreg(N)         <= arr_ptr_sreg(N) - to_integer(unsigned(dh_hitmap_length));   -- Move pointer to MSB of ToTs

                            arr_state(N)           <= S_TOT;
                            arr_sm_cnt(N)          <= 0;
                        else
                            arr_sm_cnt(N)          <= arr_sm_cnt(N) + 1;

                            -- On these two stages, check to see if sreg can be shifted and loaded with another word from the FIFO
                            if ((arr_sm_cnt(N) = 1) or (arr_sm_cnt(N) = 3)) then

                                if (arr_ptr_sreg(N) < 126) then
                                    arr_sreg(N)(188 downto 63)      <= arr_sreg(N)(125 downto 0);
                                    arr_ptr_sreg(N)                 <= arr_ptr_sreg(N) + 63;   -- Update pointer 

                                    if (fifo_ibuf_empty(N) = '0') then
                                        arr_sreg(N)( 62 downto  0)      <= fifo_ibuf_dout(N)(62 downto 0);
                                        arr_sm_rd_fifo(N)               <= '1';
                                    else
                                        arr_sreg(N)( 62 downto  0)      <= (others=>'0');
                                        arr_sm_rd_fifo(N)               <= '0';
                                    end if;
                                end if;

                            end if;

                        end if;

                        arr_dbg_6zeros(N)  <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);

                    ------------------------------------------------
                    -- Extract ToT field, if it is in use.
                    -- Move pointer to start of next address field.
                    ------------------------------------------------
                    when S_TOT =>

                        if (reg_en_tot = '1') then

                            -- Extract 64 ToT bits.
                            -- This can be a problem in the last word when ptr_sreg can be < 64. In that case, pad with zeros
                            if (arr_ptr_sreg(N) < 63) and (fifo_ibuf_empty(N) = '1') then
                                arr_reg_tot(N)     <= arr_sreg(N)(arr_ptr_sreg(N) downto 0) & std_logic_vector(to_unsigned(0, 63-arr_ptr_sreg(N)));   
                            else 
                                arr_reg_tot(N)     <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-63); 
                            end if;

                            -- If pointer is low, read data word from FIFO
                            if (arr_ptr_sreg(N) < 126) and (fifo_ibuf_empty(N) = '0') then
                                arr_sreg(N)(188 downto 63)     <= arr_sreg(N)(125 downto 0);
                                arr_sreg(N)( 62 downto  0)     <= fifo_ibuf_dout(N)(62 downto 0);
                                arr_sm_rd_fifo(N)              <= '1';
                                arr_ptr_sreg(N)                <= arr_ptr_sreg(N) - arr_nbits_tot(N) + 63;   -- Update pointer 
                            else
                                arr_ptr_sreg(N)                <= arr_ptr_sreg(N) - arr_nbits_tot(N);        -- Update pointer 
                            end if;

                        else
                            arr_reg_tot(N)     <= (others=>'0');
                        
                        end if;
                
                        arr_state(N)       <= S_ADDR;
                        arr_dbg_6zeros(N)  <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);


                    ------------------------------------------------
                    -- End of stream 
                    ------------------------------------------------
                    when S_EOS  =>
                        arr_state(N)       <= S_IDLE;
                        arr_dout_eos(N)    <= '0';
                        arr_dbg_6zeros(N)  <= arr_sreg(N)(arr_ptr_sreg(N) downto arr_ptr_sreg(N)-5);


                    when others =>
                        arr_state(N)    <= S_IDLE;

                end case;

            end if;

        end process;

    end generate;


    -----------------------------------------------------------------------------------
    -- Hitmap Decoder. Time-slice shared by each channel. 
    -- i.e. Each channel can access the hitdecode2 block once in every eight clock cycles.
    -- (4 to 30 bits of input hitmap decoded into an output 16-bit field with its number
    -- of bits set and also the actual length of the original input hitmap
    -----------------------------------------------------------------------------------
    u_hitdecode2 : entity work.hitdecode2 
    port map(
        clk                 => clk                  ,  -- input                        
        reset               => reset                ,  -- input                        

        reg_en_encode       => reg_en_encode        ,  -- input                        

        data_in             => dh_din               ,  -- input   [29:0]              Contains input hitmap in MSBs. Actual size is unknown. 5 bits min, 30 bits max
        data_in_chan        => dh_din_chan          ,  -- input   [ 3:0]              Channel number of input hitmap data
        data_in_dv          => dh_din_dv            ,  -- input                       Input data valid

        hitmap_out          => dh_hitmap_out        ,  -- output  reg [15:0]          Decoded hitmap
        hitmap_length       => dh_hitmap_length     ,  -- output  reg [ 4:0]          Actual length of the compressed input hitmap (4 to 30)
        hitmap_nbits        => dh_hitmap_nbits      ,  -- output  reg [ 4:0]          Number of bits set in the decoded hitmap. (1 to 16)
        hitmap_out_chan     => dh_hitmap_out_chan   ,  -- output  reg [ 3:0]          Channel number of output hitmap
        hitmap_out_dv       => dh_hitmap_out_dv        -- output  reg                 Output data valid
    );


    -----------------------------------------------------------------------------------
    -- Output registers. 
    -- Mask ToT bits that do not contain valid data
    -----------------------------------------------------------------------------------
    pr_dout : process (reset, clk)
    begin
        if (reset='1') then

            dout_chip_id    <= (others=>'0'); 
            dout_tag        <= (others=>'0');
            dout_ccol       <= (others=>'0');
            dout_qrow       <= (others=>'0');
            dout_hitmap     <= (others=>'0');
            dout_tot        <= (others=>'0');
            dout_eoe        <= '0';
            dout_dv         <= '0';

        elsif rising_edge(clk) then

            -- Output all of the collected fields/bits
            if (arr_state(N) = S_ADDR) then
                
                dout_chip_id    <= arr_reg_chip_id; 
                dout_tag        <= arr_reg_tag;
                dout_ccol       <= arr_reg_ccol;
                dout_qrow       <= arr_reg_qrow;
                dout_hitmap     <= arr_reg_hitmap;
                dout_dv         <= '1';
                
                -- Zero out the unused parts of the ToT bus
                case to_integer(unsigned(reg_hitmap_nbits)) is

                    when  1     =>  dout_tot    <= reg_tot(63 downto 60) & X"000000000000000";
                    when  2     =>  dout_tot    <= reg_tot(63 downto 56) & X"00000000000000";
                    when  3     =>  dout_tot    <= reg_tot(63 downto 52) & X"0000000000000";
                    when  4     =>  dout_tot    <= reg_tot(63 downto 48) & X"000000000000";
                    when  5     =>  dout_tot    <= reg_tot(63 downto 44) & X"00000000000";
                    when  6     =>  dout_tot    <= reg_tot(63 downto 40) & X"0000000000";
                    when  7     =>  dout_tot    <= reg_tot(63 downto 36) & X"000000000";
                    when  8     =>  dout_tot    <= reg_tot(63 downto 32) & X"00000000";
                    when  9     =>  dout_tot    <= reg_tot(63 downto 28) & X"0000000";
                    when 10     =>  dout_tot    <= reg_tot(63 downto 24) & X"000000";
                    when 11     =>  dout_tot    <= reg_tot(63 downto 20) & X"00000";
                    when 12     =>  dout_tot    <= reg_tot(63 downto 16) & X"0000";
                    when 13     =>  dout_tot    <= reg_tot(63 downto 12) & X"000";
                    when 14     =>  dout_tot    <= reg_tot(63 downto  8) & X"00";
                    when 15     =>  dout_tot    <= reg_tot(63 downto  4) & X"0";
                    when 16     =>  dout_tot    <= reg_tot(63 downto  0);
                    when others =>  dout_tot    <= (others=>'0');

                end case;

            else

                dout_chip_id    <= (others=>'0'); 
                dout_tag        <= (others=>'0');
                dout_ccol       <= (others=>'0');
                dout_qrow       <= (others=>'0');
                dout_hitmap     <= (others=>'0');
                dout_tot        <= (others=>'0');
                dout_eoe        <= '0';
                dout_dv         <= '0';

            end if;

        end if;

    end process;


    -----------------------------------------------------------------------------------
    -- Signal when each decoding input FIFO is getting full
    -----------------------------------------------------------------------------------
    pr_ready : process (reset, clk)
    begin
        if (reset='1') then
            arr_ready   <= (others=>'0');

        elsif rising_edge(clk) then

            for I in 0 to G_ENG-1 loop
                
                if (unsigned(fifo_ibuf_level(I)) < 256) then   
                    ready(I)         <= '1';

                elsif (unsigned(fifo_ibuf_level(I)) > 400) then    -- Back pressure? 
                    ready(I)         <= '0';

                else
                    ready(I)         <= '1';
                end if;

            end loop;

        end if;

    end process;

end rtl;

