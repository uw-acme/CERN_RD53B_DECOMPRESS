`timescale 1ns / 1ps

module hit_decoder #(ENGINES_TOTAL=1) (
    input                            clk,
    input                            reset,

    output                           ready,
    output [7:0]                     status,

    input                            reg_en_encode,  // Not implmented, assumed = 1
    input                            reg_en_tot,     // Not implmented, assumed = 1
    input                            reg_en_chip_id, // TODO: add functionality later
    input                            reg_en_eos,     // TODO: add functionality later
    
    input [63:0]                     din,
    input                            din_eoe,        // TODO: Not sure how to wire this
    input logic                      din_dv,

    output [1:0]                     dout_chip_id,   // TODO: Hardwired to 0
    output [ENGINES_TOTAL-1:0][7:0]  dout_tag,
    output                           dout_eos,       // TODO: Not sure how to wire this
    output                           dout_eoe,       // TODO: Not sure how to wire this
    output [ENGINES_TOTAL-1:0][7:0]  dout_qrow,
    output [ENGINES_TOTAL-1:0][5:0]  dout_ccol,
    output [ENGINES_TOTAL-1:0][15:0] dout_hitmap,
    output [ENGINES_TOTAL-1:0][63:0] dout_tot,
    output [ENGINES_TOTAL-1:0]       dout_dv

);

    // Used to parse the decoded stream into pieces
    logic [ENGINES_TOTAL-1:0][127:0] decoded_data_o;

    // Hardwiring chip ID for now
    assign dout_chip_id = 2'b00;

    // TODO: Driven to 0 for now, add functionality later
    assign dout_eos     = 1'b0;
    assign dout_eoe     = 1'b1;

    // TODO: Add error checking/debug
    assign status       = 8'h00;

    // Data out parsing block
    genvar i;
    generate
        for(i = 0; i < ENGINES_TOTAL; i++) begin
            // Data format for output
            //  [127:102]  [101:94]     [93:88]      [87:80]        [79:64]        [63:0]
            //  {26'h0,    tag_reg,    ccol_reg,    qrow_reg,    decoded_hitmap,  tot_reg};
            assign dout_tag[i]    = decoded_data_o[i][101:94];
            assign dout_ccol[i]   = decoded_data_o[i][93:88];
            assign dout_qrow[i]   = decoded_data_o[i][87:80];
            assign dout_hitmap[i] = decoded_data_o[i][79:64];
            assign dout_tot[i]    = decoded_data_o[i][63:0];
        end
    endgenerate

    decode_top #(.ENGINES_TOTAL(ENGINES_TOTAL)) u_decode_top(
        .clk_i(clk),
        .rst_i(reset),
        .data_raw_i(din),
        .valid_raw_i(din_dv),
        .ready_raw_o(ready),
        .valid_decode_data_io(dout_dv),
        .decoded_data_o(decoded_data_o)

    );


endmodule