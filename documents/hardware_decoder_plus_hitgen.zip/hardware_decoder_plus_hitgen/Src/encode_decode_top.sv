`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/10/2021 08:01:07 AM
// Design Name: 
// Module Name: encode_decode_top
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// Top-level module for running test_encode_decode on KC705 board. Uses pushbotton for start
// and dip switches to set hits per stream parameter on hitmaker. Uses LEDs to help with debugging
module encode_decode_top(
    input   logic           SYSCLK_P        , 
    input   logic           SYSCLK_N        ,

    input   logic           CPU_RESET       , 
    input   logic           GPIO_SW_S       , // start
    input   logic           GPIO_SW_N       , // stop
    
    input   logic           GPIO_DIP_SW0    , // for reg_hits_per_stream
    input   logic           GPIO_DIP_SW1    ,
    input   logic           GPIO_DIP_SW2    ,
    input   logic           GPIO_DIP_SW3    ,
    
    output  logic           GPIO_LED_0_LS   , 
    output  logic           GPIO_LED_1_LS   ,
    output  logic           GPIO_LED_2_LS   ,
    output  logic           GPIO_LED_3_LS   ,
    output  logic           GPIO_LED_4_LS   ,
    output  logic           GPIO_LED_5_LS   ,
    output  logic           GPIO_LED_6_LS   ,
    output  logic           GPIO_LED_7_LS   ,

    output  logic [ 6:0]    DEBUG_OUT
    );

    //  Clock/reset outputs from PLL block
    logic           clkreset_lock           ;
    logic           reset_in                ;  
    logic           reset                   ;
    logic           clk                     ;
    
    logic           blink                   ;
    logic           tick_sec                ;   // tick every 1 sec
    logic           tick_usec               ;   // tick every 1 microsecond
    logic [ 3:0]    pulse                   ;
    logic [ 3:0]    pulse_stretched         ;
    
    // for debug
    logic           decoder_dv              ;
    logic [ 7:0]    dout_errs               ;
    logic           ready                   ;
    logic           busy                    ;
    
    // for encode-decode
    logic           start, stop             ;
    logic [15:0]    hits_per_stream         ;
    logic [ 1:0]    decoder_chip_id         ;   // [ 1:0] current chip_id            
    logic [ 7:0]    decoder_tag             ;   // [ 7:0] current tag       
    logic           decoder_eos             ;   // end-of-stream            
    logic           decoder_eoe             ;   // end-of-event    Used to check incrementing tag
    logic [ 7:0]    decoder_qrow            ;   // [ 7:0]    
    logic [ 5:0]    decoder_ccol            ;   // [ 5:0]  
    logic [15:0]    decoder_hitmap          ;   // [15:0]
    logic [63:0]    decoder_tot             ;   // [63:0] ToT data packed into MSBs of bus
    logic           dout_err_dv             ;
    logic [ 7:0]    dout_err_count          ;
    
    logic [ 3:0]    switches                ;
    
    assign switches  = {GPIO_DIP_SW3, GPIO_DIP_SW2, GPIO_DIP_SW1, GPIO_DIP_SW0}  ;
    assign reset_in  = CPU_RESET                                                 ;   
    //assign uart0_txd = 1'b1                                                      ;
    
    //----------------------------------
    // Clock and reset logic for board
    //----------------------------------
    clkreset            u_clkreset       
    (         
        .reset_in   (reset_in       ),  // input
        .clk_in1_p  (SYSCLK_P       ),  // input 
        .clk_in1_n  (SYSCLK_N       ),  // input
        .clk        (clk            ),  // output
        .lock       (clkreset_lock  ),  // output
        .reset      (reset          )   // output
    );
    
    //------------------------------------
    // Debounce start
    //------------------------------------
    debounce            u_debounce_start
    (
        .clk    (clk        ),  
        .reset  (reset      ),
        .sw_in  (GPIO_SW_S  ),  // input
        .sw_out (start      )   // output
    );

    debounce            u_debounce_stop
    (
        .clk    (clk        ),  
        .reset  (reset      ),
        .sw_in  (GPIO_SW_N  ),  // input
        .sw_out (stop       )   // output
    );
    
    //------------------------------------
    // Debounce DIP switches and set hits per stream. Hits per stream = 2**([switch input] + 1)) - 1
    //------------------------------------
    set_stream_size     u_set_stream_size
    (
        .clk                (clk                ),
        .reset              (reset              ),   
        .switches           (switches           ),  // [ 3:0] input
        .hits_per_stream    (hits_per_stream    )   // [15:0] output for test_encode_decode
    );

    logic all_start;

    always_ff @(posedge clk) begin
        if (reset) begin
            all_start <= 1'b0;
        end else if (start) begin
            all_start <= 1'b1;
        end else if (stop) begin
            all_start <= 1'b0;
        end
    end
    
    //-------------------------------------
    // Encode/decode
    //-------------------------------------
    test_encode_decode  u_test_encode_decode
    (   
        .clk                    (clk                    ),            
        .reset                  (reset                  ),              

        .start                  (all_start                  ),   // Begin stream generation
        .ready                  (ready                  ),   // Normally high. Goes low when any internal FIFO is over-threshold
        .busy                   (busy                   ),   // Set low when din_dv=1 then high after last dout of an event   

        // Control parameters -- just default for now
        .reg_mode_evgen         (2'b00                  ),   // [ 1:0] Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
        .reg_seed               (32'hFFFFFFFF           ),   // [31:0] Seed to initialize the pseudo-random number generator
        .reg_hits_per_stream    (hits_per_stream        ),   
        .reg_lv_density         (5'b00100               ),   // [15:0] Parameter to set the probability of a vertical line of hits occurring. Can be zero
        .reg_lv_maxlen          (5'b00100               ),   // [ 4:0] Parameter to set the max length of a v-line of hits occurring
        .reg_cl_density         (12'h006                ),   // [11:0] Parameter to set the range of the increment in x,y from one cluster to the next.
        .reg_cl_max             (12'h010                ),   // [11:0] Parameter to set the max number of clusters+lines to generate.
        .reg_restart            (1'b0                   ),             
    
        .reg_en_encode          (1'b1                   ),   // '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
        .reg_en_tot             (1'b1                   ),   // '1' = ToT enabled, '0'= No ToT data
        .reg_mode_tot           (1'b0                   ),   // '0' = Constant (tot_value), '1' = Incrementing
        .reg_tot_value          (4'h3                   ),   // [ 3:0] ToT value for constant mode
        .reg_tag_init           (8'h05                  ),   // [ 7:0] Tag to start output stream. Subsequent tags (internal) will be 11-bit
        .reg_chip_id            (2'b01                  ),   // [ 1:0]    
        .reg_en_chip_id         (1'b0                   ),   // Enable chip ID[1:0]
        .reg_en_eos             (1'b1                   ),   // Enable min 6 zeros output to mark end of stream
    
        // Output from decoder 
        .decoder_chip_id        (decoder_chip_id        ),   // [ 1:0] current chip_id            
        .decoder_tag            (decoder_tag            ),   // [ 7:0] current tag       
        .decoder_eos            (decoder_eos            ),   // end-of-stream            
        .decoder_eoe            (decoder_eoe            ),   // end-of-event    Used to check incrementing tag
        .decoder_qrow           (decoder_qrow           ),   // [ 7:0]    
        .decoder_ccol           (decoder_ccol           ),   // [ 5:0]  
        .decoder_hitmap         (decoder_hitmap         ),   // [15:0]
        .decoder_tot            (decoder_tot            ),   // [63:0] ToT data packed into MSBs of bus
        .decoder_dv             (decoder_dv             ),   // data valid           
        
        // Output from checker
        // fail bus bits
        //----------------------------------------------------------
        // Bit    Failure type
        //  0        chip_id
        //  1        tag
        //  2        qrow
        //  3        ccol
        //  4        hitmap
        //  5        ToT
        //  6        EOS
        //  7        EOE
        //----------------------------------------------------------
        .dout_err_dv            (dout_err_dv    ),   // result valid
        .dout_errs              (dout_errs      ),   // [ 7:0] fail bus
        .dout_err_count         (dout_err_count )    // [ 7:0] result error count    
    );
    
    //------------------------------------
    // Blinky and pulse stretcher
    //------------------------------------
    blink #(4, 20)      u_blink             // G_NBITS = 4, G_INTERVAL_TICK_SLOW = 20
    (
        .reset      (reset              ),  // input
        .clk        (clk                ),  // input
        
        .flash      (blink              ),    
        .tick_sec   (tick_sec           ),  // output
        .tick_msec  (                   ),  // output, not hooked to anything
        .tick_usec  (tick_usec          ),  // output
        
        .pulse      (pulse              ),  // [G_NBITS-1:0] input 
        .stretched  (pulse_stretched    )   // [G_NBITS-1:0] output
    );


    assign DEBUG_OUT[6]     = clkreset_lock         ;
    assign DEBUG_OUT[5]     = busy                  ;
    assign DEBUG_OUT[4]     = decoder_dv            ;
    assign DEBUG_OUT[3:0]   = dout_errs[5:2]        ; // ToT, hitmap, ccol, qrow errors, respectively
        
    assign pulse            = dout_errs[5:2]        ;
    
    assign GPIO_LED_0_LS    = clkreset_lock         ;
    assign GPIO_LED_1_LS    = blink                 ;
    assign GPIO_LED_2_LS    = tick_sec              ;
    assign GPIO_LED_3_LS    = busy                  ;
    assign GPIO_LED_4_LS    = pulse_stretched[3]    ; // ToT
    assign GPIO_LED_5_LS    = pulse_stretched[2]    ; // hitmap
    assign GPIO_LED_6_LS    = pulse_stretched[1]    ; // ccol
    assign GPIO_LED_7_LS    = pulse_stretched[0]    ; // qrow

endmodule
