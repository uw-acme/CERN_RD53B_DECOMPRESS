// Tests RD53B output Aurora bus decoding
// Uses hitmaker block to generate encoded data based on inputted control parameters
// Uses hit_checker to compare decoded data to original data 

`timescale 1ns / 1ps
module test_encode_decode(
    input   logic           clk                 ,            
    input   logic           reset               ,              

    input   logic           start               ,   // Begin stream generation
    output  logic           ready               ,   // Normally high. Goes low when any internal FIFO is over-threshold
    output  logic           busy                ,   // Set low when din_dv=1 then high after last dout of an event   

    // Control parameters
    input   logic   [ 1:0]  reg_mode_evgen      ,   // Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
    input   logic   [31:0]  reg_seed            ,   // Seed to initialize the pseudo-random number generator
    input   logic   [15:0]  reg_hits_per_stream ,   
    input   logic   [ 4:0]  reg_lv_density      ,   // Parameter to set the probability of a vertical line of hits occurring. Can be zero
    input   logic   [ 4:0]  reg_lv_maxlen       ,   // Parameter to set the max length of a v-line of hits occurring
    input   logic   [11:0]  reg_cl_density      ,   // Parameter to set the range of the increment in x,y from one cluster to the next.
    input   logic   [11:0]  reg_cl_max          ,   // Parameter to set the max number of clusters+lines to generate.
    input   logic           reg_restart         ,             

    input   logic           reg_en_encode       ,   // '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
    input   logic           reg_en_tot          ,   // '1' = ToT enabled, '0'= No ToT data
    input   logic           reg_mode_tot        ,   // '0' = Constant (tot_value), '1' = Incrementing
    input   logic   [ 3:0]  reg_tot_value       ,   // ToT value for constant mode
    input   logic   [ 7:0]  reg_tag_init        ,   // Tag to start output stream. Subsequent tags (internal) will be 11-bit
    input   logic   [ 1:0]  reg_chip_id         ,       
    input   logic           reg_en_chip_id      ,   // Enable chip ID[1:0]
    input   logic           reg_en_eos          ,   // Enable min 6 zeros output to mark end of stream

    // Output from decoder 
    output  logic   [1:0]   decoder_chip_id     ,   // current chip_id            
    output  logic   [7:0]   decoder_tag         ,   // current tag       
    output  logic           decoder_eos         ,   // end-of-stream            
    output  logic           decoder_eoe         ,   // end-of-event    Used to check incrementing tag
    output  logic   [7:0]   decoder_qrow        ,      
    output  logic   [5:0]   decoder_ccol        ,     
    output  logic   [15:0]  decoder_hitmap      ,    
    output  logic   [63:0]  decoder_tot         ,   // ToT data packed into MSBs of bus
    output  logic           decoder_dv          ,   // data valid           
    
    // Output from checker
    output  logic           dout_err_dv         ,   // result valid
    output  logic   [7:0]   dout_errs           ,   // fail bus
    output  logic   [7:0]   dout_err_count          // result error count [7:0]
    );
    
    // Hitmaker output of raw event generator data, for comparison with resulting data after encoding then decoding 
    // 'Expected' data
    logic exp_hit_eos                               ;              
    logic exp_hit_eoe                               ;               
    logic           [ 7:0]  exp_hit_qrow            ;    
    logic           [ 5:0]  exp_hit_ccol            ;    
    logic           [15:0]  exp_hit_hitmap          ;    
    logic                   exp_hit_dv              ;             
    logic           [63:0]  exp_hit_tot             ;   // hitmaker ToT data
    logic           [ 6:0]  exp_hit_tot_size        ;   // hitmaker ToT size
    logic                   exp_hit_tot_dv          ;   // expected tot data valid
    
    // Encoded data
    logic           [63:0]  hitmaker_dout           ;   // Output data. 
    logic                   hitmaker_dout_eos       ;                         
    logic                   hitmaker_dout_eoe       ;                        
    logic                   hitmaker_dout_dv        ;   // Output data valid
                         
    // Decoder output of decoded hit data fields    
    logic                   decoder_ready           ;           
    logic           [ 7:0]  decoder_status          ;

    // Checker
    logic           [ 7:0]  checker_status          ;     
    logic                   checker_ready           ;

    // Combined ready signal for decoder and checker
    logic                   comb_ready              ;

    assign comb_ready = checker_ready & decoder_ready;     

    //-------------------------------------------------------------
    // Generate hit data and convert into 64-bit Aurora packets
    //-------------------------------------------------------------
    hitmaker                    u_hitmaker
    (
        .clk                    (clk                    ), // input            
        .reset                  (reset                  ), // input            

        .start                  (start                  ), // input             Begin stream generation
        .ready_out              (ready                  ), // output            Normally high. Goes low when any internal FIFO is over-threshold
        .busy                   (busy                   ), // output            Set low when din_dv=1 then high after last dout of an event   

        // Control parameters
        .reg_mode_evgen         (reg_mode_evgen         ), // input    [ 1:0]   Type of data 00 = incrementing hitmap, 01 = 3x3 clusters, 10 cluster + vertical line, 11 cluster+vert+horiz lines
        .reg_seed               (reg_seed               ), // input    [31:0]   Seed to initialize the pseudo-random number generator
        .reg_hits_per_stream    (reg_hits_per_stream    ), // input    [15:0]  
        .reg_lv_density         (reg_lv_density         ), // input    [ 4:0]   Parameter to set the probability of a vertical line of hits occurring. Can be zero
        .reg_lv_maxlen          (reg_lv_maxlen          ), // input    [ 4:0]   Parameter to set the max length of a v-line of hits occurring
        .reg_cl_density         (reg_cl_density         ), // input    [11:0]   Parameter to set the range of the increment in x,y from one cluster to the next.
        .reg_cl_max             (reg_cl_max             ), // input    [11:0]   Parameter to set the max number of clusters+lines to generate.
        .reg_restart            (reg_restart            ), // input             

        .reg_en_encode          (reg_en_encode          ), // input             '1' = Encode (Compress) din. '0' = dout is din, dout_size = 16 (5'b1000)
        .reg_en_tot             (reg_en_tot             ), // input             '1' = ToT enabled, '0'= No ToT data
        .reg_mode_tot           (reg_mode_tot           ), // input             '0' = Constant (tot_value), '1' = Incrementing
        .reg_tot_value          (reg_tot_value          ), // input    [ 3:0]   ToT value for constant mode
        .reg_tag_init           (reg_tag_init           ), // input    [ 7:0]   Tag to start output stream. Subsequent tags (internal) will be 11-bit
        .reg_chip_id            (reg_chip_id            ), // input    [ 1:0]    
        .reg_en_chip_id         (reg_en_chip_id         ), // input             Enable chip ID[1:0]
        .reg_en_eos             (reg_en_eos             ), // input             Enable min 6 zeros output to mark end of stream

        // Output of raw event generator data, for comparison with resulting data after encoding then decoding 
        .hit_dv                 (exp_hit_dv             ), // output   			expected data valid
        .hit_eos                (exp_hit_eos            ), // output             
        .hit_eoe                (exp_hit_eoe            ), // output            
        .hit_qrow               (exp_hit_qrow           ), // output   [ 7:0]   
        .hit_ccol               (exp_hit_ccol           ), // output   [ 5:0]   
        .hit_hitmap             (exp_hit_hitmap         ), // output   [15:0]   

        .hit_tot                (exp_hit_tot            ), // output   [64:0] 
        .hit_tot_size           (exp_hit_tot_size       ),
        .hit_tot_dv             (exp_hit_tot_dv         ), // output   			 expected tot data valid

        // Output of encoded data
        .ready_in               (comb_ready             ), // input              Normally high from downstream sink. Goes low when sink cannot accept data
        .dout                   (hitmaker_dout          ), // output  [ 63:0]     
        .dout_eos               (hitmaker_dout_eos      ), // output             Set for end-of-stream. Last hit in stream          
        .dout_eoe               (hitmaker_dout_eoe      ), // output             Set for end-of-event. Last hit in event           
        .dout_dv                (hitmaker_dout_dv       )  // output             Set when new dout produced            
    );
    
    //-----------------------------------------------------------
    // Hit decoder to convert 64-bit 'Aurora-formatted' words 
    // back into uncompressed, separate fields.
    //-----------------------------------------------------------
    hit_decoder                 u_hit_decoder               // default param ENGINE_NUM=1
    (
        .clk                    (clk                    ),  // input
        .reset                  (reset                  ),  // input

        .ready                  (decoder_ready          ),  // output
        .status                 (decoder_status         ),  // output [7:0]

        .reg_en_encode          (reg_en_encode          ),  // input // Not implemented, assumed = 1
        .reg_en_tot             (reg_en_tot             ),  // input // Not implemented, assumed = 1
        .reg_en_chip_id         (reg_en_chip_id         ),  // input // TODO: add functionality later
        .reg_en_eos             (reg_en_eos             ),  // input // TODO: add functionality later

        .din                    (hitmaker_dout          ),  // input [63:0] 
        .din_eoe                (hitmaker_dout_eoe      ),  // input // TODO: Not sure how to wire this
        .din_dv                 (hitmaker_dout_dv       ),  // input 

        .dout_chip_id           (decoder_chip_id        ),  // output [1:0] // TODO: Hardwired to 0
        .dout_tag               (decoder_tag            ),  // output [ENGINE_NUM-1:0][7:0]
        .dout_eos               (decoder_eos            ),  // output // TODO: Not sure how to wire this
        .dout_eoe               (decoder_eoe            ),  // output // TODO: Not sure how to wire this
        .dout_qrow              (decoder_qrow           ),  // output [ENGINE_NUM-1:0][7:0]
        .dout_ccol              (decoder_ccol           ),  // output [ENGINE_NUM-1:0][5:0]
        .dout_hitmap            (decoder_hitmap         ),  // output [ENGINE_NUM-1:0][15:0]
        .dout_tot               (decoder_tot            ),  // output [ENGINE_NUM-1:0][63:0]
        .dout_dv                (decoder_dv             )   // output [ENGINE_NUM-1:0] 

    );

    //----------------------------------------------------------
    // hit_checker. 
    // Stores generated hit data in a FIFO. Reads it out and 
    // compares expected value agains actual decoded value.
    // Expected ToT is made from tot mode register controls and 
    // expected hitmap size.
    //----------------------------------------------------------
    // checker_fail bits
    //----------------------------------------------------------
    // Bit    Failure type
    //  0        chip_id
    //  1        tag
    //  2        qrow
    //  3        ccol
    //  4        hitmap
    //  5        ToT
    //  6        EOS
    //  7        EOE
    //----------------------------------------------------------
    hit_checker                     u_hit_checker
    (
        .clk                    (clk                    ),  
        .reset                  (reset                  ),  
        .restart                (reg_restart            ),  

        // Register setup. Operating mode
        .reg_en_tot             (reg_en_tot             ), // input             '1' = ToT enabled, '0'= No ToT data
        .reg_mode_tot           (reg_mode_tot           ), // input             '0' = Constant (tot_value), '1' = Incrementing
        .reg_tot_value          (reg_tot_value          ), // input    [ 3:0]   ToT value for constant mode
        .reg_tag_init           (reg_tag_init           ), // input    [ 7:0]   Tag to start output stream. Subsequent tags (internal) will be 11-bit
        .reg_chip_id            (reg_chip_id            ), // input    [ 1:0]    
        .reg_en_chip_id         (reg_en_chip_id         ), // input             Enable chip ID[1:0]
        .reg_en_eos             (reg_en_eos             ), // input             Enable min 6 zeros output to mark end of stream

        .status                 (checker_status         ), // TBD status bits [7:0]

        // Expected data from hitmaker
        .exp_eos                (exp_hit_eos            ), // input             
        .exp_eoe                (exp_hit_eoe            ), // input            
        .exp_qrow               (exp_hit_qrow           ), // input   [ 7:0]   
        .exp_ccol               (exp_hit_ccol           ), // input   [ 5:0]   
        .exp_hitmap             (exp_hit_hitmap         ), // input   [15:0]   
        .exp_dv                 (exp_hit_dv             ), // input   expected data valid

        .exp_tot                (exp_hit_tot            ), // input   [15:0]   
        .exp_tot_size           (exp_hit_tot_size       ), // input   [6:0]
        .exp_tot_dv             (exp_hit_tot_dv         ), // input   expected data valid

        // Actual data from decoder 
        .act_chip_id            (decoder_chip_id        ), // input current chip_id [ 1:0]           
        .act_tag                (decoder_tag            ), // input current tag     [ 7:0]      
        .act_eos                (decoder_eos            ), // input end-of-stream            
        .act_eoe                (decoder_eoe            ), // input end-of-event    Used to check incrementing tag
        .act_qrow               (decoder_qrow           ), // input qrow    [ 7:0]   
        .act_ccol               (decoder_ccol           ), // input ccol    [ 5:0]   
        .act_hitmap             (decoder_hitmap         ), // input hitmap  [15:0]   
        .act_tot                (decoder_tot            ), // input tot     [63:0] ToT data packed into MSBs of bus
        .act_dv                 (decoder_dv             ), // input data valid           

        .dout_err_dv            (dout_err_dv            ), // output result valid
        .dout_errs              (dout_errs              ), // output fail bus [7:0]
        .dout_err_count         (dout_err_count         ), // output result error count [7:0]

        .ready_check_o          (checker_ready          ) // Prevents overflow of expected data
    );          

endmodule

