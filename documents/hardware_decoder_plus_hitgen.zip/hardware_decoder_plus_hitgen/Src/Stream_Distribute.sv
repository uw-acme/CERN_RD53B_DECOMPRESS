`timescale 1ns / 1ps
module stream_distribute #(
    parameter ENGINE_NUM = 5
)
(
    input                         clk_i,
    input                         rst_i,
    input        [ENGINE_NUM-1:0] ready_engine_i,
    input                         valid_raw_i,
    input        [63:0]           data_raw_i,
    input        [ENGINE_NUM-1:0] dec_eng_prog_full_i,
    output       [ENGINE_NUM-1:0] valid_stream_o,
    output logic [62:0]           data_stream_o,
    output                        ready_raw_o,
    output       [ENGINE_NUM-1:0] end_of_stream_o,
    output       [ENGINE_NUM-1:0] test_new_stream_o
);

    // Stream fifo signals
    logic                  empty_raw_data_fifo;
    logic                  full_raw_data_fifo;
    logic                  ready_raw_data_fifo;
    logic                  rd_raw_data_fifo;
    logic                  rd_raw_data_fifo_reg;
    logic [63:0]           data_o_raw_fifo;
    logic                  fifo_raw_prog_full;

    // Module control signals
    logic [9:0]            raw_data_fifo_counter;  // *** FIFO level ('count' output).  Better name would be 'raw_data_fifo_count'
    logic                  start_up_flag;
    logic                  new_stream;

    // Used to choose which engine data is being sent to
    logic [ENGINE_NUM-1:0] active_engine;
    logic [ENGINE_NUM-1:0] active_engine_reg;

    // This is a control signal that makes sure the first engine doesn't get
    // the end_of_stream bit when first stream is sent
    always_ff @(posedge clk_i) begin
        if (rst_i) begin
            start_up_flag <= 1'b0;
        end else if (new_stream) begin
            start_up_flag <= 1'b1;
        end
    end

    // Used to pipeline the data sent out
    always_ff @(posedge clk_i) begin
        if (rst_i) begin
            data_stream_o <= 0;
        end else begin
            data_stream_o <= data_o_raw_fifo[62:0];
        end
    end

    // Used to signal when the last piece of data for a stream is sent 
    assign end_of_stream_o = active_engine_reg & {(ENGINE_NUM){new_stream}} & {(ENGINE_NUM){start_up_flag}};

    // Used to signal when new data streams arrive
    assign new_stream = data_o_raw_fifo[63] & !empty_raw_data_fifo;

    assign test_new_stream_o = {ENGINE_NUM{new_stream}} & active_engine;

    // Signals when the fifo is ready to read from
    assign ready_raw_data_fifo = raw_data_fifo_counter > 0 & !empty_raw_data_fifo;

    // Chooses when to read from the fifo and is pipelined through
    assign rd_raw_data_fifo = ready_raw_data_fifo & active_engine != 0 & ~dec_eng_prog_full_i;

    // Unused for now, but will allow us to signal when we need to backpressure.
    assign ready_raw_o = !fifo_raw_prog_full;


    always_ff @(posedge clk_i) begin
        rd_raw_data_fifo_reg <= rd_raw_data_fifo;
    end

    // This might end up being an inefficent way to select the best engine
    always_comb begin
        active_engine = 0;
        for (int i = ENGINE_NUM-1; i >= 0; i--) begin
            if(ready_engine_i[i] == 1 & end_of_stream_o[i] == 0) begin
                active_engine = 1'b1 << i;
            end
        end
    end

    // Registers and locks the engine number whenever a new stream is active
    always_ff @(posedge clk_i) begin
        if(rst_i) begin
            active_engine_reg <= 0;
        end else if(new_stream) begin
            active_engine_reg <= active_engine;
        end
    end

    // Advertises when we have valid data to send
    assign valid_stream_o = active_engine_reg & {(ENGINE_NUM){rd_raw_data_fifo_reg}};

    always_ff @(posedge clk_i) begin
        if (valid_raw_i & full_raw_data_fifo) begin
            $display("Fifo Overflow in stream distribute");    
        end
    end

    // Fifo counter to keep track of raw data values as they enter and leave
    fifo_counter #(10) u_raw_stream_fifo_counter
    (
        .clk_i(clk_i),
        .rst_i(rst_i),
        .write_i(valid_raw_i),
        .read_i(rd_raw_data_fifo),
        .count(raw_data_fifo_counter)
    );

    // Storage for the raw data that comes in from data generation source
    raw_data_fifo u_raw_data_fifo (
        .clk(clk_i),
        .srst(rst_i),
        .din(data_raw_i),      // input wire [63 : 0] din
        .wr_en(valid_raw_i),
        .rd_en(rd_raw_data_fifo),
        .dout(data_o_raw_fifo),  // output wire [63 : 0] dout
        .full(full_raw_data_fifo),      // Why not have 'full' come from 'fifo_counter' ???
        .empty(empty_raw_data_fifo),    // Why not have 'empty' come from 'fifo_counter' ???
        .prog_full(fifo_raw_prog_full)
    );

endmodule