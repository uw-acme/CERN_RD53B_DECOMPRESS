module fifo_counter #(
    COUNT_WIDTH = 10
)
(
    input                          clk_i,
    input                          rst_i,
    input                          write_i,
    input                          read_i,
    output logic [COUNT_WIDTH-1:0] count
);

always_ff @(posedge clk_i) begin
    if(rst_i) begin
        count <= 0;
    end else if (write_i & read_i) begin
        count <= count;
    end else if (write_i) begin
        count <= count + 1;
    end else if (read_i) begin
        count <= count - 1;
    end
end

endmodule