
// TODO: Parameterize counter by number of engines

module engine_offset_shared #(ENGINES_TOTAL = 12) (
    input              clk_i,
    input              rst_i,
    output logic [5:0] engine_offset_counter
);

// Used to offset the engines for when they make requests from the decoder ROM
always_ff @(posedge clk_i) begin
    if(rst_i) begin
        engine_offset_counter <= 1;
    end else if(engine_offset_counter == 5) begin
        engine_offset_counter <= 0;
    end else begin
        engine_offset_counter <= engine_offset_counter + 1;
    end
end

endmodule