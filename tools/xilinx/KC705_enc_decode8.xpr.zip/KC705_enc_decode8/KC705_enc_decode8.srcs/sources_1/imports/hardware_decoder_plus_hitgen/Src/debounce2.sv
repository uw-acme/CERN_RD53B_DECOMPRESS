`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 05/15/2021 08:54:12 PM
// Design Name: 
// Module Name: debounce
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

// takes switch input, syncs to clock, and debounces 
module debounce(
    input   logic clk   ,
    input   logic reset ,
    input   logic sw_in ,
    output  reg   sw_out
    );
    
    // for metastability
    logic sw_in_d1;
    logic sw_in_d2;
    logic sw_in_d3;
    logic sw_filt;
    logic sw_filt_d1      ;

    // Debounce counter
    logic [15:0] cnt_stable;

    
    // Filter out metastability
    always_ff @(posedge clk) begin
        sw_in_d1  <= sw_in;
        sw_in_d2  <= sw_in_d1;
        sw_in_d3  <= sw_in_d2;
        
        if ((sw_in_d1 == 1'b0) & (sw_in_d2 == 1'b0) & (sw_in_d3 == 1'b0)) begin
             sw_filt    <= 1'b0;
        end 
        else if ((sw_in_d1 == 1'b1) & (sw_in_d2 == 1'b1) & (sw_in_d3 == 1'b1)) begin
             sw_filt    <= 1'b1;
        end 
        sw_filt_d1  <= sw_filt;
    end
    
    
    // Debounce. Switch output when filtered value is stable
    always_ff @(posedge clk) begin
        if (reset) begin
            sw_out     <= 0;
            cnt_stable <= 0;
        end
        else begin
            if (sw_filt_d1 != sw_filt) begin
                cnt_stable <= 0;
            end
            else if (cnt_stable < 16'h000F) begin
                cnt_stable <= cnt_stable + 1'b1;
            end
            
            if (cnt_stable == 16'h000F) begin
                sw_out <= sw_filt_d1;
            end
        end
    end

endmodule
