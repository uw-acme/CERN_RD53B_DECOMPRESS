--------------------------------------------------------------------------
--  File         : clkreset.vhd
----------------------------------------------------------------------------
--  Description  : Wrapper for clock MCMM reset logic
--                 This version is for a board with a
--                 200 MHz differential clock. 
----------------------------------------------------------------------------
library ieee;
use     ieee.std_logic_1164.all;
use     ieee.numeric_std.all;

entity clkreset is
port(
    -- Reset and clock from pads
    reset_in    : in std_logic;
    clk_in1_p   : in  std_logic;
    clk_in1_n   : in  std_logic;

    -- Reset and clock outputs to all internal logic
    clk         : out std_logic;
    lock        : out std_logic;
    reset       : out std_logic
);
end clkreset;

------------------------------------------------------------------------
-- Architecture for development board with
-- 200MHz input clock from oscillator on the board
------------------------------------------------------------------------
architecture f160 of clkreset is

signal pll_locked       : std_logic;
signal pll_locked_d1    : std_logic := '0';
signal clk_i            : std_logic;
signal cnt_reset        : unsigned(7 downto 0)  := X"00";

------------------------------------------------------------------------
-- Input differential 200 MHz
-- Output 160 MHz
------------------------------------------------------------------------
component clkgen_200to160
port (
    clk_out1    :  out std_logic;        --
    reset       :  in  std_logic := '0'; --
    locked      :  out std_logic;         --
    clk_in1_p   :  in  std_logic := '0'; --
    clk_in1_n   :  in  std_logic := '0' --
);
end component;

begin

    -- Outputs
    clk         <= clk_i;
    lock        <= pll_locked;

    ---------------------------------------------------------------------------------
    -- Clock generator. Xilinx IP clock wizard.
    -- Generates 160MHz output clock from differential 200MHz input.
    -- The 'locked' output is used to generate reset for all other FPGA logic.
    ---------------------------------------------------------------------------------
    u_clkgen160 : clkgen_200to160
    port map(
        clk_out1    => clk_i        , -- out std_logic;        
        reset       => reset_in     , -- in  std_logic := '0'; 
        locked      => pll_locked   , -- out std_logic         
        clk_in1_p   => clk_in1_p    , -- in  std_logic := '0'; 
        clk_in1_n   => clk_in1_n      -- in  std_logic := '0';
    );


    -------------------------------------------------------------------------------
    -- Keep reset output active until N cycles after PLL locked
    -------------------------------------------------------------------------------
    pr_reset : process (reset_in, pll_locked, clk_i)
    begin
        if (reset_in = '1' or pll_locked = '0') then
            reset           <= '1';
            pll_locked_d1   <= '0';
            cnt_reset       <= X"00";

        elsif rising_edge(clk_i) then

            pll_locked_d1   <= pll_locked;

            if (pll_locked_d1 = '1' and cnt_reset < X"0F") then
                cnt_reset   <= cnt_reset + 1;
            end if;

            if (cnt_reset < X"0F") then
                reset       <= '1';
            else
                reset       <= '0';
            end if;

        end if;
    end process;

end f160;

