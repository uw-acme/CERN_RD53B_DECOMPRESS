// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (win64) Build 2258646 Thu Jun 14 20:03:12 MDT 2018
// Date        : Thu Feb 10 17:07:23 2022
// Host        : RATBAG running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               D:/Work/UW-Physics/GitLab/largehadroncollider/hardware_decoder_plus_hitgen/Src/decode2/rom_hitdecode_stub.v
// Design      : rom_hitdecode
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7k325tffg900-2
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "blk_mem_gen_v8_4_1,Vivado 2018.2" *)
module rom_hitdecode(clka, addra, douta, clkb, addrb, doutb)
/* synthesis syn_black_box black_box_pad_pin="clka,addra[13:0],douta[15:0],clkb,addrb[13:0],doutb[15:0]" */;
  input clka;
  input [13:0]addra;
  output [15:0]douta;
  input clkb;
  input [13:0]addrb;
  output [15:0]doutb;
endmodule
