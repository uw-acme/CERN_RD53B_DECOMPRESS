// Copyright 1986-2018 Xilinx, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2018.2 (win64) Build 2258646 Thu Jun 14 20:03:12 MDT 2018
// Date        : Wed Mar 23 15:31:34 2022
// Host        : RATBAG running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               d:/Work/UW-Physics/Tools/Vivado18_2/KC705_enc_decode8/KC705_enc_decode8.srcs/sources_1/ip/fifogen_512x66b_bram/fifogen_512x66b_bram_stub.v
// Design      : fifogen_512x66b_bram
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7k325tffg900-2
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
(* x_core_info = "fifo_generator_v13_2_2,Vivado 2018.2" *)
module fifogen_512x66b_bram(clk, srst, din, wr_en, rd_en, dout, full, overflow, 
  empty, underflow, data_count)
/* synthesis syn_black_box black_box_pad_pin="clk,srst,din[65:0],wr_en,rd_en,dout[65:0],full,overflow,empty,underflow,data_count[9:0]" */;
  input clk;
  input srst;
  input [65:0]din;
  input wr_en;
  input rd_en;
  output [65:0]dout;
  output full;
  output overflow;
  output empty;
  output underflow;
  output [9:0]data_count;
endmodule
