vopt -64 +acc -l elaborate.log -L xil_defaultlib -L xpm -L unisims_ver -L unimacro_ver -L secureip -work xil_defaultlib xil_defaultlib.clkgen_200to160 xil_defaultlib.glbl -o clkgen_200to160_opt
