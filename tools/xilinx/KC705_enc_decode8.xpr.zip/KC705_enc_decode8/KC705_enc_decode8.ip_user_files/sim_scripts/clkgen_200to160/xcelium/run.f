-makelib xcelium_lib/xil_defaultlib -sv \
  "D:/Tools/Xilinx/Vivado/2018.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
-endlib
-makelib xcelium_lib/xpm \
  "D:/Tools/Xilinx/Vivado/2018.2/data/ip/xpm/xpm_VCOMP.vhd" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../../KC705_enc_decode8.srcs/sources_1/ip/clkgen_200to160/clkgen_200to160_clk_wiz.v" \
  "../../../../KC705_enc_decode8.srcs/sources_1/ip/clkgen_200to160/clkgen_200to160.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  glbl.v
-endlib

