onbreak {quit -force}
onerror {quit -force}

asim -t 1ps +access +r +m+clkgen_200to160 -L xil_defaultlib -L xpm -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.clkgen_200to160 xil_defaultlib.glbl

do {wave.do}

view wave
view structure

do {clkgen_200to160.udo}

run -all

endsim

quit -force
