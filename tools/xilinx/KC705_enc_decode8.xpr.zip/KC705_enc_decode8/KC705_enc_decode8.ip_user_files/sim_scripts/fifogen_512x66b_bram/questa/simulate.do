onbreak {quit -f}
onerror {quit -f}

vsim -t 1ps -lib xil_defaultlib fifogen_512x66b_bram_opt

do {wave.do}

view wave
view structure
view signals

do {fifogen_512x66b_bram.udo}

run -all

quit -force
