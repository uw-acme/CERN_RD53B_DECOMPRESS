onbreak {quit -f}
onerror {quit -f}

vsim -t 1ps -lib xil_defaultlib rom_hitdecode_opt

do {wave.do}

view wave
view structure
view signals

do {rom_hitdecode.udo}

run -all

quit -force
