onbreak {quit -force}
onerror {quit -force}

asim -t 1ps +access +r +m+fifogen_512x64b_bram -L xil_defaultlib -L xpm -L fifo_generator_v13_2_2 -L unisims_ver -L unimacro_ver -L secureip -O5 xil_defaultlib.fifogen_512x64b_bram xil_defaultlib.glbl

do {wave.do}

view wave
view structure

do {fifogen_512x64b_bram.udo}

run -all

endsim

quit -force
